<?php
include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id = $_POST['id'];
  $nombre = $_POST['nombre'];
  $fecha = $_POST['fecha'];
  $lugar = $_POST['lugar'];
  $hora = $_POST['hora'];

  $sql = "UPDATE torneo SET 
            nombre = '$nombre', 
            fecha = '$fecha', 
            lugar = '$lugar', 
            hora = '$hora' 
          WHERE id = '$id'";

  if (mysqli_query($conexion, $sql)) {
    echo '
    <script>
      alert("Torneo modificado correctamente.");
      window.location.href = "../torneos.php";
    </script>';
  } else {
    echo "Error: " . mysqli_error($conexion);
  }
}
?>
