<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Eliminar Torneo</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --accent: #38bdf8;
      --danger: #ef4444;
      --danger-hover: #dc2626;
      --danger-glow: rgba(239, 68, 68, 0.25);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #ef4444;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(239, 68, 68, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--danger);
      border: 1px solid rgba(239, 68, 68, 0.4);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--danger-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(99, 102, 241, 0.15);
      color: var(--primary);
      border-color: var(--primary);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 540px;
      margin: 0 auto;
      padding: 40px 20px;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 16px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .danger-card {
      background: var(--card-bg);
      border: 1.5px solid rgba(239, 68, 68, 0.3);
      border-radius: 24px;
      padding: 36px 30px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    }

    .card-header {
      text-align: center;
      margin-bottom: 24px;
    }

    .danger-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(239, 68, 68, 0.12);
      color: #fca5a5;
      border: 1px solid rgba(239, 68, 68, 0.3);
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 12px;
    }

    .card-header h2 {
      font-size: 24px;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .card-header p {
      font-size: 13.5px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    /* Caja de Alerta */
    .warning-box {
      background: rgba(239, 68, 68, 0.08);
      border: 1px solid rgba(239, 68, 68, 0.25);
      border-radius: 14px;
      padding: 14px 16px;
      margin-bottom: 24px;
      display: flex;
      gap: 12px;
      align-items: flex-start;
      font-size: 13px;
      color: #fca5a5;
      line-height: 1.45;
    }

    .warning-box i {
      font-size: 18px;
      color: var(--danger);
      margin-top: 2px;
      flex-shrink: 0;
    }

    .form-group {
      margin-bottom: 24px;
    }

    .form-group label {
      display: block;
      font-size: 13px;
      font-weight: 600;
      color: var(--text-muted);
      margin-bottom: 8px;
    }

    .input-wrapper {
      position: relative;
    }

    .input-wrapper i {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748b;
      font-size: 14px;
      pointer-events: none;
    }

    .input-wrapper select {
      width: 100%;
      background: var(--input-bg);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 13px 16px 13px 44px;
      border-radius: 12px;
      font-size: 14px;
      outline: none;
      appearance: none;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .input-wrapper select:focus {
      border-color: var(--border-focus);
      box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.2);
    }

    /* Acciones */
    .btn-actions {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .btn-delete {
      width: 100%;
      background: var(--danger);
      color: white;
      border: none;
      padding: 14px;
      border-radius: 12px;
      font-size: 14.5px;
      font-weight: 800;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--danger-glow);
      transition: all 0.2s ease;
    }

    .btn-delete:hover {
      background: var(--danger-hover);
      transform: translateY(-1px);
    }

    .btn-cancel {
      width: 100%;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 13px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .btn-cancel:hover {
      color: var(--text-main);
      border-color: var(--text-muted);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../torneos.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-trash-can"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <button type="button" onclick="window.history.back();" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver</span>
    </button>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel Administrador</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_admin.php">Gestión de Alumnos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../torneos.php">Torneos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Eliminar Convocatoria</span>
    </div>

    <div class="danger-card">
      <div class="card-header">
        <span class="danger-badge"><i class="fas fa-triangle-exclamation"></i> Zona Crítica</span>
        <h2>Eliminar Torneo</h2>
        <p>Baja definitiva de una convocatoria o campeonato del circuito</p>
      </div>

      <div class="warning-box">
        <i class="fas fa-circle-exclamation"></i>
        <span><strong>Aviso permanente:</strong> Al eliminar este torneo, la convocatoria se retirará del calendario general de Team Dharius y se removerán los registros vinculados. Esta acción no se puede deshacer.</span>
      </div>

      <form action="eliminarTOR_be.php" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar permanentemente este torneo?');">
        <div class="form-group">
          <label for="id_torneo">Selecciona el Torneo a Eliminar</label>
          <div class="input-wrapper">
            <i class="fas fa-trophy"></i>
            <select name="id_torneo" id="id_torneo" required>
              <option value="">-- Elige un torneo a dar de baja --</option>
              <?php
                include("../php/conexion_be.php");

                $sql = "SELECT id, nombre FROM torneo";
                $resultado = mysqli_query($conexion, $sql);

                while ($fila = mysqli_fetch_assoc($resultado)) {
                  echo "<option value='" . $fila['id'] . "'>ID #" . $fila['id'] . " — " . htmlspecialchars($fila['nombre']) . "</option>";
                }

                mysqli_close($conexion);
              ?>
            </select>
          </div>
        </div>

        <div class="btn-actions">
          <button type="submit" class="btn-delete">
            <i class="fas fa-trash-can"></i>
            <span>Confirmar Eliminación</span>
          </button>
          <button type="button" class="btn-cancel" onclick="window.history.back();">
            Cancelar Operación
          </button>
        </div>
      </form>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de gestión de torneos &bull; Team Dharius.
  </footer>

</body>
</html>