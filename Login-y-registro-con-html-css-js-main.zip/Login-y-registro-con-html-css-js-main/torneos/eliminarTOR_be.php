<?php
include("../php/conexion_be.php");

if (isset($_POST['id_torneo'])) {
    $id_torneo = $_POST['id_torneo'];

    $sql = "DELETE FROM torneo WHERE id = '$id_torneo'";

    if (mysqli_query($conexion, $sql)) {
        echo "
        <script>
            alert('Torneo eliminado con éxito.');
            window.location.href = '../torneos.php'; // Redirige a la página de búsqueda
        </script>";
    } else {
        echo "
        <script>
            alert('Error al eliminar el torneo.');
            window.location.href = 'eliminartor.php'; // Redirige a la página de búsqueda
        </script>";
    }

    mysqli_close($conexion);
}
?>
