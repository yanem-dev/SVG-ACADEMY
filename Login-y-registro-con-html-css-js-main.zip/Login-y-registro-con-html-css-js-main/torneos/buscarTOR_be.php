<?php
include("../php/conexion_be.php");

if (isset($_POST['nombre'])) {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);

    $sql = "SELECT id, nombre, fecha, lugar, hora
            FROM torneo
            WHERE nombre LIKE '%$nombre%'";

    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        echo '<table>
                <thead>
                  <tr>
                    <th>ID</th><th>Nombre</th><th>Fecha</th><th>Lugar</th><th>Hora</th>
                  </tr>
                </thead>
                <tbody>';
        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo '<tr>
                    <td>' . $fila['id'] . '</td>
                    <td>' . $fila['nombre'] . '</td>
                    <td>' . $fila['fecha'] . '</td>
                    <td>' . $fila['lugar'] . '</td>
                    <td>' . $fila['hora'] . '</td>
                   
                  </tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p style="color: red; font-weight: bold;">No se encontraron resultados.</p>';
    }

    mysqli_close($conexion);
}
?>
