<?php
include("../php/conexion_be.php");

$nombre = $_POST['nombre'];
$fecha = $_POST['fecha'];
$lugar = $_POST['lugar'];
$hora = $_POST['hora'];

$sql = "INSERT INTO torneo (nombre, fecha, lugar, hora) 
        VALUES ('$nombre', '$fecha', '$lugar', '$hora')";

if (mysqli_query($conexion, $sql)) {
    echo "<script>
        alert('Torneo registrado correctamente');
        window.location.href = '../torneos.php';
    </script>";
} else {
    echo "<script>
        alert('Error al registrar el torneo: " . mysqli_error($conexion) . "');
        window.history.back();
    </script>";
}

mysqli_close($conexion);
?>
