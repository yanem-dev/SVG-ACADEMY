<?php
include("../php/conexion_be.php");

if (isset($_POST['id_estudiante'])) {
    $id_estudiante = $_POST['id_estudiante'];

    $sql = "DELETE FROM estudiantes WHERE id = '$id_estudiante'";

    if (mysqli_query($conexion, $sql)) {
        echo "
        <script>
            alert('Estudiante eliminado con éxito.');
            window.location.href = '../estudiante.php'; // Redirige a la página de búsqueda
        </script>";
    } else {
        echo "
        <script>
            alert('Error al eliminar el estudiante.');
            window.location.href = 'eliminarestudiante.php'; // Redirige a la página de búsqueda
        </script>";
    }

    mysqli_close($conexion);
}
?>
