<?php
include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id = $_POST['id'];
  $nombreA = $_POST['nombreA'];
  $apellidosA = $_POST['apellidosA'];
  $telefonoA = $_POST['telefonoA'];
  $correoA = $_POST['correoA'];
  $edadA = $_POST['edadA'];
  $direccionA = $_POST['direccionA'];
  $emergenciaA = $_POST['emergenciaA'];
  $fechaA = $_POST['fechaA'];
  $colorC = $_POST['colorC'];
  $grado = $_POST['grado'];
  $clase = $_POST['clase'];

  $sql = "UPDATE estudiantes SET 
            nombreA = '$nombreA', 
            apellidosA = '$apellidosA', 
            telefonoA = '$telefonoA', 
            correoA = '$correoA', 
            edadA = '$edadA', 
            direccionA = '$direccionA', 
            emergenciaA = '$emergenciaA', 
            fechaA = '$fechaA', 
            colorC = '$colorC', 
            grado = '$grado', 
            clase = '$clase' 
          WHERE id = '$id'";

  if (mysqli_query($conexion, $sql)) {
    echo '
    <script>
      alert("Estudiante modificado correctamente.");
      window.location.href = "../estudiante.php";
    </script>';
  } else {
    echo "Error: " . mysqli_error($conexion);
  }
}
?>
