<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Padrón General de Estudiantes</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --emerald: #10b981;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #6366f1;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.15) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(56, 189, 248, 0.2));
      color: var(--primary);
      border: 1px solid rgba(99, 102, 241, 0.4);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--primary-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(99, 102, 241, 0.15);
      color: var(--primary);
      border-color: var(--primary);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1360px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .top-actions-bar {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      flex-wrap: wrap;
      gap: 20px;
      margin-bottom: 28px;
    }

    .top-actions-bar h1 {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .top-actions-bar p {
      font-size: 14px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    .actions-group {
      display: flex;
      gap: 12px;
      align-items: center;
      flex-wrap: wrap;
    }

    .search-wrapper {
      position: relative;
    }

    .search-wrapper i {
      position: absolute;
      left: 14px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748b;
      font-size: 13px;
    }

    .search-input {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 10px 14px 10px 38px;
      border-radius: 12px;
      font-size: 13.5px;
      outline: none;
      width: 260px;
      transition: all 0.2s ease;
    }

    .search-input:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
    }

    .btn-pdf {
      background: var(--primary);
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 12px;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--primary-glow);
      transition: all 0.2s ease;
    }

    .btn-pdf:hover {
      background: var(--primary-hover);
      transform: translateY(-2px);
    }

    /* Tabla Estilo Consola */
    .table-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }

    .table-responsive {
      overflow-x: auto;
      width: 100%;
      max-height: 680px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }

    thead {
      background: var(--card-inner);
      position: sticky;
      top: 0;
      z-index: 10;
      box-shadow: 0 1px 0 var(--border-subtle);
    }

    th {
      padding: 16px 18px;
      font-size: 11.5px;
      font-weight: 800;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--accent);
      white-space: nowrap;
    }

    td {
      padding: 14px 18px;
      font-size: 13.5px;
      color: var(--text-main);
      border-bottom: 1px solid var(--border-subtle);
      white-space: nowrap;
      vertical-align: middle;
    }

    tbody tr {
      transition: background-color 0.2s ease;
    }

    tbody tr:hover {
      background-color: rgba(99, 102, 241, 0.05);
    }

    tbody tr:last-child td {
      border-bottom: none;
    }

    .badge-id {
      background: var(--card-inner);
      border: 1px solid var(--border-subtle);
      padding: 4px 8px;
      border-radius: 6px;
      font-weight: 700;
      font-size: 12px;
      color: var(--text-muted);
    }

    .athlete-name {
      font-weight: 700;
      color: var(--text-main);
    }

    .badge-belt {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(56, 189, 248, 0.1);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.25);
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
    }

    .badge-class {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 12px;
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .top-actions-bar {
        flex-direction: column;
        align-items: flex-start;
      }
      .actions-group {
        width: 100%;
      }
      .search-input {
        width: 100%;
      }
      .btn-pdf {
        width: 100%;
        justify-content: center;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../estudiante.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-table-list"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <button onclick="window.history.back();" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver</span>
    </button>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel Administrador</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_admin.php">Gestión de Alumnos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../estudiante.php">Padrón</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Listado General</span>
    </div>

    <div class="top-actions-bar">
      <div>
        <h1>Padrón General de Atletas</h1>
        <p>Listado oficial de todos los alumnos registrados en Team Dharius.</p>
      </div>

      <div class="actions-group">
        <div class="search-wrapper">
          <i class="fas fa-magnifying-glass"></i>
          <input type="text" id="filtroTabla" class="search-input" placeholder="Filtrar por nombre, cinta..." onkeyup="filtrarEstudiantes()">
        </div>
        <button onclick="exportarPDF()" class="btn-pdf">
          <i class="fas fa-file-pdf"></i>
          <span>Descargar Padrón PDF</span>
        </button>
      </div>
    </div>

    <div class="table-card">
      <div class="table-responsive">
        <table id="tablaEstudiantes">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Apellidos</th>
              <th>Teléfono</th>
              <th>Correo</th>
              <th>Edad</th>
              <th>Dirección</th>
              <th>Emergencia</th>
              <th>Fecha Nac.</th>
              <th>Color Cinta</th>
              <th>Grado</th>
              <th>Clase</th>
            </tr>
          </thead>
          <tbody>
            <?php
              include("../php/conexion_be.php");
              $sql = "SELECT * FROM estudiantes";
              $resultado = mysqli_query($conexion, $sql);

              while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<tr>";
                echo "<td><span class='badge-id'>#" . htmlspecialchars($fila['id']) . "</span></td>";
                echo "<td class='athlete-name'>" . htmlspecialchars($fila['nombreA']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['apellidosA']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['telefonoA']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['correoA']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['edadA']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['direccionA']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['emergenciaA']) . "</td>";
                echo "<td>" . htmlspecialchars($fila['fechaA']) . "</td>";
                echo "<td><span class='badge-belt'><i class='fas fa-ribbon'></i> " . htmlspecialchars($fila['colorC']) . "</span></td>";
                echo "<td>" . htmlspecialchars($fila['grado']) . "</td>";
                echo "<td><span class='badge-class'>" . htmlspecialchars($fila['clase']) . "</span></td>";
                echo "</tr>";
              }

              mysqli_close($conexion);
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Padrón general de atletas &bull; Team Dharius.
  </footer>

  <!-- jsPDF y autoTable -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>

  <script>
    // Filtro instantáneo sin recargar la página
    function filtrarEstudiantes() {
      const input = document.getElementById("filtroTabla");
      const filtro = input.value.toUpperCase();
      const tabla = document.getElementById("tablaEstudiantes");
      const tr = tabla.getElementsByTagName("tr");

      for (let i = 1; i < tr.length; i++) {
        let textoFila = tr[i].textContent || tr[i].innerText;
        if (textoFila.toUpperCase().indexOf(filtro) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }

    async function exportarPDF() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF('l', 'pt', 'a4'); 

      doc.setFontSize(16);
      doc.setTextColor(40);
      doc.text("SVG-SPORTS - Padrón General de Estudiantes (Team Dharius)", 40, 40);
      doc.setFontSize(11);
      doc.text("Fecha de emisión: " + new Date().toLocaleDateString(), 40, 60);

      doc.autoTable({
        html: '#tablaEstudiantes',
        startY: 80,
        theme: 'grid',
        styles: {
          cellPadding: 4,
          fontSize: 8
        },
        headStyles: {
          fillColor: [99, 102, 241],
          textColor: 255
        },
        margin: { top: 80, left: 40, right: 40 },
        pageBreak: 'auto'
      });

      doc.save("padron_estudiantes_SVG_SPORTS.pdf");
    }
  </script>
</body>
</html>