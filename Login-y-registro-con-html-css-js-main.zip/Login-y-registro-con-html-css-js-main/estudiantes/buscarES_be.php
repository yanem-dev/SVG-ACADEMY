<?php
include("../php/conexion_be.php");

if (isset($_POST['nombre'])) {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);

    $sql = "SELECT id, nombreA, apellidosA, telefonoA, correoA, edadA, direccionA, emergenciaA, fechaA, colorC, grado, clase
            FROM estudiantes
            WHERE nombreA LIKE '%$nombre%'";

    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        echo '<table>
                <thead>
                  <tr>
                    <th>ID</th><th>Nombre</th><th>Apellidos</th><th>Teléfono</th><th>Correo</th><th>Edad</th>
                    <th>Dirección</th><th>Emergencia</th><th>Fecha</th><th>Color</th><th>Grado</th><th>Clase</th>
                  </tr>
                </thead>
                <tbody>';
        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo '<tr>
                    <td>' . $fila['id'] . '</td>
                    <td>' . $fila['nombreA'] . '</td>
                    <td>' . $fila['apellidosA'] . '</td>
                    <td>' . $fila['telefonoA'] . '</td>
                    <td>' . $fila['correoA'] . '</td>
                    <td>' . $fila['edadA'] . '</td>
                    <td>' . $fila['direccionA'] . '</td>
                    <td>' . $fila['emergenciaA'] . '</td>
                    <td>' . $fila['fechaA'] . '</td>
                    <td>' . $fila['colorC'] . '</td>
                    <td>' . $fila['grado'] . '</td>
                    <td>' . $fila['clase'] . '</td>
                  </tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p style="color: red; font-weight: bold;">No se encontraron resultados.</p>';
    }

    mysqli_close($conexion);
}
?>
