<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Alta de Atleta</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --emerald: #10b981;
      --emerald-glow: rgba(16, 185, 129, 0.25);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #10b981;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(16, 185, 129, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--emerald);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--emerald-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--emerald);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-return:hover {
      background: rgba(16, 185, 129, 0.15);
      color: var(--emerald);
      border-color: var(--emerald);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 860px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--emerald);
    }

    .form-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 24px;
      padding: 38px 34px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    }

    .form-header {
      margin-bottom: 30px;
      padding-bottom: 20px;
      border-bottom: 1px solid var(--border-subtle);
    }

    .form-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(16, 185, 129, 0.12);
      color: var(--emerald);
      border: 1px solid rgba(16, 185, 129, 0.3);
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 10px;
    }

    .form-header h2 {
      font-size: 26px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .form-header p {
      font-size: 14px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    /* Subtítulos de sección interna */
    .section-title {
      font-size: 12.5px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--accent);
      margin: 24px 0 16px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .section-title:first-of-type {
      margin-top: 0;
    }

    /* Retícula de campos */
    .fields-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
    }

    .field-full {
      grid-column: 1 / -1;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .form-group label {
      font-size: 12.5px;
      font-weight: 600;
      color: var(--text-muted);
    }

    .input-wrapper {
      position: relative;
    }

    .input-wrapper i {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748b;
      font-size: 14px;
      pointer-events: none;
    }

    .input-wrapper input {
      width: 100%;
      background: var(--input-bg);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 12px 16px 12px 44px;
      border-radius: 12px;
      font-size: 14px;
      outline: none;
      transition: all 0.2s ease;
    }

    .input-wrapper input:focus {
      border-color: var(--border-focus);
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.15);
    }

    /* Botones de acción */
    .btn-actions {
      display: flex;
      gap: 14px;
      margin-top: 32px;
      padding-top: 24px;
      border-top: 1px solid var(--border-subtle);
    }

    .btn-submit {
      flex: 2;
      background: var(--emerald);
      color: #062817;
      border: none;
      padding: 14px;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 800;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--emerald-glow);
      transition: all 0.2s ease;
    }

    .btn-submit:hover {
      background: #059669;
      color: white;
      transform: translateY(-1px);
    }

    .btn-cancel {
      flex: 1;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 14px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s ease;
    }

    .btn-cancel:hover {
      color: var(--text-main);
      border-color: var(--text-muted);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 680px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .form-card {
        padding: 28px 20px;
      }
      .fields-grid {
        grid-template-columns: 1fr;
      }
      .btn-actions {
        flex-direction: column;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../estudiante.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-user-plus"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <a href="../estudiante.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver al Menú</span>
    </a>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel Administrador</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_admin.php">Gestión de Alumnos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../estudiante.php">Padrón</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Alta de Alumno</span>
    </div>

    <div class="form-card">
      <div class="form-header">
        <span class="form-badge"><i class="fas fa-shield-halved"></i> Registro Oficial</span>
        <h2>Alta de Nuevo Atleta</h2>
        <p>Ingresa la ficha de matrícula y registro marcial en el padrón de Team Dharius.</p>
      </div>

      <form action="registrarES_be.php" method="POST">
        <!-- 1. Datos Personales -->
        <div class="section-title">
          <i class="fas fa-user"></i> Información Personal
        </div>
        <div class="fields-grid">
          <div class="form-group">
            <label for="nombreA">Nombre(s)</label>
            <div class="input-wrapper">
              <i class="fas fa-id-card"></i>
              <input type="text" id="nombreA" name="nombreA" placeholder="Nombre del atleta" required>
            </div>
          </div>

          <div class="form-group">
            <label for="apellidosA">Apellidos</label>
            <div class="input-wrapper">
              <i class="fas fa-signature"></i>
              <input type="text" id="apellidosA" name="apellidosA" placeholder="Apellidos completos" required>
            </div>
          </div>

          <div class="form-group">
            <label for="edadA">Edad</label>
            <div class="input-wrapper">
              <i class="fas fa-hashtag"></i>
              <input type="number" id="edadA" name="edadA" placeholder="Edad en años" min="3" max="99" required>
            </div>
          </div>

          <div class="form-group">
            <label for="fechaA">Fecha de Nacimiento</label>
            <div class="input-wrapper">
              <i class="fas fa-calendar-day"></i>
              <input type="date" id="fechaA" name="fechaA" required>
            </div>
          </div>
        </div>

        <!-- 2. Contacto y Residencia -->
        <div class="section-title">
          <i class="fas fa-address-book"></i> Contacto y Emergencia
        </div>
        <div class="fields-grid">
          <div class="form-group">
            <label for="correoA">Correo Electrónico</label>
            <div class="input-wrapper">
              <i class="fas fa-envelope"></i>
              <input type="email" id="correoA" name="correoA" placeholder="correo@ejemplo.com" required>
            </div>
          </div>

          <div class="form-group">
            <label for="telefonoA">Teléfono de Contacto</label>
            <div class="input-wrapper">
              <i class="fas fa-phone"></i>
              <input type="text" id="telefonoA" name="telefonoA" placeholder="Teléfono del atleta o tutor" required>
            </div>
          </div>

          <div class="form-group field-full">
            <label for="emergenciaA">Número de Emergencia</label>
            <div class="input-wrapper">
              <i class="fas fa-kit-medical"></i>
              <input type="text" id="emergenciaA" name="emergenciaA" placeholder="Teléfono de contacto urgente / Tutor" required>
            </div>
          </div>

          <div class="form-group field-full">
            <label for="direccionA">Dirección Particular</label>
            <div class="input-wrapper">
              <i class="fas fa-location-dot"></i>
              <input type="text" id="direccionA" name="direccionA" placeholder="Calle, número, colonia y ciudad" required>
            </div>
          </div>
        </div>

        <!-- 3. Registro Marcial y Grupo -->
        <div class="section-title">
          <i class="fas fa-medal"></i> Datos Deportivos y Nivel
        </div>
        <div class="fields-grid">
          <div class="form-group">
            <label for="colorC">Color de Cinta</label>
            <div class="input-wrapper">
              <i class="fas fa-ribbon"></i>
              <input type="text" id="colorC" name="colorC" placeholder="Blanca, Amarilla, Negra..." required>
            </div>
          </div>

          <div class="form-group">
            <label for="grado">Grado / Kup / Dan</label>
            <div class="input-wrapper">
              <i class="fas fa-award"></i>
              <input type="text" id="grado" name="grado" placeholder="Ej. 10 Kup, 1er Dan" required>
            </div>
          </div>

          <div class="form-group field-full">
            <label for="clase">Clase / Grupo Asignado</label>
            <div class="input-wrapper">
              <i class="fas fa-users-rectangle"></i>
              <input type="text" id="clase" name="clase" placeholder="Infantil / Juvenil / Adultos / Alto Rendimiento" required>
            </div>
          </div>
        </div>

        <!-- Acciones del Formulario -->
        <div class="btn-actions">
          <button type="submit" class="btn-submit">
            <i class="fas fa-floppy-disk"></i>
            <span>Completar Registro de Alumno</span>
          </button>
          <a href="../estudiante.php" class="btn-cancel">
            Cancelar
          </a>
        </div>
      </form>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Módulo de altas y matrícula &bull; Team Dharius.
  </footer>

</body>
</html>
