<?php
include("../php/conexion_be.php");
session_start();

if (!isset($_SESSION['id_estudiante'])) {
    echo "Debes iniciar sesión.";
    exit;
}

$id_estudiante = $_SESSION['id_estudiante'];
$sql = "SELECT * FROM estudiantes WHERE id = '$id_estudiante'";
$resultado = mysqli_query($conexion, $sql);
$estudiante = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Expediente del Atleta</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --emerald: #10b981;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Header Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(99, 102, 241, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1000px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .top-actions-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 30px;
    }

    .top-actions-bar h1 {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .btn-pdf {
      background: var(--primary);
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 12px;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--primary-glow);
      transition: all 0.2s ease;
    }

    .btn-pdf:hover {
      background: var(--primary-hover);
      transform: translateY(-2px);
    }

    /* Tarjeta Principal de Perfil */
    .profile-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 24px;
      padding: 32px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
      margin-bottom: 24px;
    }

    /* Hero del Atleta */
    .athlete-hero {
      display: flex;
      align-items: center;
      gap: 24px;
      padding-bottom: 28px;
      border-bottom: 1px solid var(--border-subtle);
      margin-bottom: 28px;
    }

    .avatar-wrapper {
      width: 76px;
      height: 76px;
      border-radius: 20px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(56, 189, 248, 0.2));
      border: 2px solid var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 32px;
      color: var(--accent);
      flex-shrink: 0;
    }

    .athlete-names h2 {
      font-size: 24px;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 4px;
    }

    .athlete-badges {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }

    .badge-id {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      font-size: 12px;
      font-weight: 600;
      padding: 4px 10px;
      border-radius: 6px;
    }

    .badge-rank {
      background: rgba(56, 189, 248, 0.12);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      font-size: 12px;
      font-weight: 700;
      padding: 4px 10px;
      border-radius: 6px;
    }

    /* Grid de Información */
    .info-section-title {
      font-size: 14px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--accent);
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 30px;
    }

    .info-box {
      background: var(--card-inner);
      border: 1px solid var(--border-subtle);
      border-radius: 14px;
      padding: 16px;
    }

    .info-label {
      font-size: 12px;
      color: var(--text-muted);
      font-weight: 500;
      display: block;
      margin-bottom: 4px;
    }

    .info-val {
      font-size: 15px;
      font-weight: 700;
      color: var(--text-main);
      word-break: break-word;
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    /* Tabla oculta para jsPDF AutoTable */
    #tablaEstudiantes {
      display: none;
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .athlete-hero {
        flex-direction: column;
        text-align: center;
      }
      .athlete-badges {
        justify-content: center;
      }
    }
  </style>
</head>
<body>

  <!-- Header Superior -->
  <header class="app-header">
    <a href="../modulos_alumno.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-bolt"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <button onclick="window.history.back();" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver</span>
    </button>
  </header>

  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_alumno.php">Módulo de Alumnos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Expediente</span>
    </div>

    <div class="top-actions-bar">
      <h1>Expediente del Atleta</h1>
      <button onclick="exportarPDF()" class="btn-pdf">
        <i class="fas fa-file-pdf"></i>
        <span>Descargar Ficha PDF</span>
      </button>
    </div>

    <?php if ($estudiante): ?>
      <div class="profile-card">
        <!-- Cabecera del Atleta -->
        <div class="athlete-hero">
          <div class="avatar-wrapper">
            <i class="fas fa-user-ninja"></i>
          </div>
          <div class="athlete-names">
            <h2><?php echo htmlspecialchars($estudiante['nombreA'] . " " . $estudiante['apellidosA']); ?></h2>
            <div class="athlete-badges">
              <span class="badge-id"><i class="fas fa-id-badge"></i> ID: #<?php echo htmlspecialchars($estudiante['id']); ?></span>
              <span class="badge-rank"><i class="fas fa-ribbon"></i> Cinta: <?php echo htmlspecialchars($estudiante['colorC']); ?></span>
              <span class="badge-rank"><i class="fas fa-award"></i> Grado: <?php echo htmlspecialchars($estudiante['grado']); ?></span>
            </div>
          </div>
        </div>

        <!-- 1. Datos Personales -->
        <div class="info-section-title">
          <i class="fas fa-user"></i> Información General
        </div>
        <div class="info-grid">
          <div class="info-box">
            <span class="info-label">Edad</span>
            <span class="info-val"><?php echo htmlspecialchars($estudiante['edadA']); ?> años</span>
          </div>
          <div class="info-box">
            <span class="info-label">Fecha de Ingreso</span>
            <span class="info-val"><?php echo htmlspecialchars($estudiante['fechaA']); ?></span>
          </div>
          <div class="info-box">
            <span class="info-label">Clase / Grupo</span>
            <span class="info-val"><?php echo htmlspecialchars($estudiante['clase']); ?></span>
          </div>
        </div>

        <!-- 2. Contacto y Ubicación -->
        <div class="info-section-title">
          <i class="fas fa-address-book"></i> Contacto y Residencia
        </div>
        <div class="info-grid">
          <div class="info-box">
            <span class="info-label">Correo Electrónico</span>
            <span class="info-val"><?php echo htmlspecialchars($estudiante['correoA']); ?></span>
          </div>
          <div class="info-box">
            <span class="info-label">Teléfono Personal</span>
            <span class="info-val"><?php echo htmlspecialchars($estudiante['telefonoA']); ?></span>
          </div>
          <div class="info-box">
            <span class="info-label">Contacto de Emergencia</span>
            <span class="info-val"><?php echo htmlspecialchars($estudiante['emergenciaA']); ?></span>
          </div>
          <div class="info-box" style="grid-column: 1 / -1;">
            <span class="info-label">Dirección Particular</span>
            <span class="info-val"><?php echo htmlspecialchars($estudiante['direccionA']); ?></span>
          </div>
        </div>
      </div>
    <?php else: ?>
      <div class="profile-card" style="text-align: center; padding: 48px;">
        <i class="fas fa-circle-exclamation" style="font-size: 40px; color: #f87171; margin-bottom: 12px;"></i>
        <h2>No se encontró el expediente del estudiante</h2>
      </div>
    <?php endif; ?>

    <!-- Tabla invisible para mantener compatibilidad con jsPDF sin romper scripts -->
    <table id="tablaEstudiantes">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Apellidos</th>
          <th>Teléfono</th>
          <th>Correo</th>
          <th>Edad</th>
          <th>Dirección</th>
          <th>Emergencia</th>
          <th>Fecha</th>
          <th>Color Cinta</th>
          <th>Grado</th>
          <th>Clase</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($estudiante): ?>
          <tr>
            <td><?php echo $estudiante['id']; ?></td>
            <td><?php echo $estudiante['nombreA']; ?></td>
            <td><?php echo $estudiante['apellidosA']; ?></td>
            <td><?php echo $estudiante['telefonoA']; ?></td>
            <td><?php echo $estudiante['correoA']; ?></td>
            <td><?php echo $estudiante['edadA']; ?></td>
            <td><?php echo $estudiante['direccionA']; ?></td>
            <td><?php echo $estudiante['emergenciaA']; ?></td>
            <td><?php echo $estudiante['fechaA']; ?></td>
            <td><?php echo $estudiante['colorC']; ?></td>
            <td><?php echo $estudiante['grado']; ?></td>
            <td><?php echo $estudiante['clase']; ?></td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Sistema integral de gestión deportiva &bull; Team Dharius.
  </footer>

  <!-- jsPDF y autoTable -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>

  <script>
    async function exportarPDF() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF('l', 'pt', 'a4'); 

      doc.setFontSize(16);
      doc.setTextColor(40);
      doc.text("SVG-SPORTS - Ficha del Atleta (Team Dharius)", 40, 40);
      doc.setFontSize(11);
      doc.text("Fecha de emisión: " + new Date().toLocaleDateString(), 40, 60);

      doc.autoTable({
        html: '#tablaEstudiantes',
        startY: 80,
        theme: 'grid',
        styles: {
          cellPadding: 6,
          fontSize: 8
        },
        headStyles: {
          fillColor: [99, 102, 241],
          textColor: 255
        },
        margin: { top: 80, left: 40, right: 40 },
        pageBreak: 'auto'
      });

      doc.save("ficha_atleta_<?php echo $id_estudiante; ?>.pdf");
    }
  </script>
</body>
</html>
<?php mysqli_close($conexion); ?>