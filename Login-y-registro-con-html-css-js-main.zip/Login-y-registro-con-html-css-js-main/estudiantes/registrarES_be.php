<?php
include("../php/conexion_be.php");

// Recibir datos del formulario
$nombreA     = $_POST['nombreA'];
$apellidosA  = $_POST['apellidosA'];
$telefonoA   = $_POST['telefonoA'];
$correoA     = $_POST['correoA'];
$edadA       = $_POST['edadA'];
$direccionA  = $_POST['direccionA'];
$emergenciaA = $_POST['emergenciaA'];
$fechaA      = $_POST['fechaA'];
$colorC      = $_POST['colorC'];
$grado       = $_POST['grado'];
$clase       = $_POST['clase'];

// Insertar estudiante
$sql = "INSERT INTO estudiantes 
(nombreA, apellidosA, telefonoA, correoA, edadA, direccionA, emergenciaA, fechaA, colorC, grado, clase) 
VALUES 
('$nombreA', '$apellidosA', '$telefonoA', '$correoA', '$edadA', '$direccionA', '$emergenciaA', '$fechaA', '$colorC', '$grado', '$clase')";

if (mysqli_query($conexion, $sql)) {
    // ✅ Obtener el ID del estudiante recién insertado
    $id_estudiante = mysqli_insert_id($conexion);

     echo "<script>
        alert('Estudiante registrado correctamente. ID: $id_estudiante');
        window.history.back(); // Solo vuelve atrás, sin redirigir
    </script>";
} else {
    echo "<script>
        alert('Error al registrar al estudiante: " . mysqli_error($conexion) . "');
        window.history.back();
    </script>";
}

mysqli_close($conexion);
?>
