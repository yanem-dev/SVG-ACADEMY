<?php
include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id = $_POST['id'];
  $turno = $_POST['turno'];
  $inicio = $_POST['inicio'];
  $final = $_POST['final'];
  

  $sql = "UPDATE horario SET 
            turno = '$turno', 
            inicio = '$inicio', 
            final = '$final' 
          WHERE id = '$id'";

  if (mysqli_query($conexion, $sql)) {
    echo '
    <script>
      alert("Horario modificado correctamente.");
      window.location.href = "../horarios.php";
    </script>';
  } else {
    echo "Error: " . mysqli_error($conexion);
  }
}
?>
