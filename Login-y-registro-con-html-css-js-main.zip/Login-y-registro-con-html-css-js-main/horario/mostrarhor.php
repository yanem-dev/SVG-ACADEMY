<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Horarios Programados</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Header Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(99, 102, 241, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1100px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .top-actions-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 28px;
    }

    .top-actions-bar h1 {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .btn-pdf {
      background: var(--primary);
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 12px;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--primary-glow);
      transition: all 0.2s ease;
    }

    .btn-pdf:hover {
      background: var(--primary-hover);
      transform: translateY(-2px);
    }

    /* Tabla Estilo Web App */
    .table-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }

    .table-responsive {
      overflow-x: auto;
      width: 100%;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }

    thead {
      background: var(--card-inner);
      border-bottom: 1px solid var(--border-subtle);
    }

    th {
      padding: 16px 20px;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--accent);
      white-space: nowrap;
    }

    td {
      padding: 16px 20px;
      font-size: 14px;
      color: var(--text-main);
      border-bottom: 1px solid var(--border-subtle);
      vertical-align: middle;
    }

    tbody tr {
      transition: background-color 0.2s ease;
    }

    tbody tr:hover {
      background-color: rgba(99, 102, 241, 0.05);
    }

    tbody tr:last-child td {
      border-bottom: none;
    }

    .badge-id {
      background: var(--card-inner);
      border: 1px solid var(--border-subtle);
      padding: 4px 10px;
      border-radius: 6px;
      font-weight: 700;
      font-size: 12.5px;
      color: var(--text-muted);
      display: inline-block;
    }

    .badge-turno {
      background: rgba(56, 189, 248, 0.1);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.25);
      padding: 4px 12px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 700;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .time-slot {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--text-main);
      font-weight: 600;
      font-size: 13.5px;
    }

    .time-slot i {
      color: var(--text-muted);
      font-size: 13px;
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .top-actions-bar {
        flex-direction: column;
        align-items: flex-start;
      }
      .btn-pdf {
        width: 100%;
        justify-content: center;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../modulos_alumno.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-bolt"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <button onclick="window.history.back();" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver</span>
    </button>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_alumno.php">Módulo de Alumnos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Horarios</span>
    </div>

    <div class="top-actions-bar">
      <div>
        <h1>Horarios Programados</h1>
        <p style="color: var(--text-muted); font-size: 14px; margin-top: 4px;">Consulta las franjas y turnos disponibles para las sesiones de entrenamiento.</p>
      </div>
      <button onclick="exportarPDF()" class="btn-pdf">
        <i class="fas fa-file-pdf"></i>
        <span>Descargar PDF</span>
      </button>
    </div>

    <div class="table-card">
      <div class="table-responsive">
        <table id="tablaTorneos">
          <thead>
            <tr>
              <th>ID Horario</th>
              <th>Turno / Nivel</th>
              <th>Hora de Inicio</th>
              <th>Hora de Salida</th>
            </tr>
          </thead>
          <tbody>
            <?php
              include("../php/conexion_be.php");

              $sql = "SELECT id, turno, inicio, final FROM horario";
              $resultado = mysqli_query($conexion, $sql);

              while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<tr>";
                echo "<td><span class='badge-id'>#" . htmlspecialchars($fila['id']) . "</span></td>";
                echo "<td><span class='badge-turno'><i class='fas fa-clock'></i> " . htmlspecialchars($fila['turno']) . "</span></td>";
                echo "<td><span class='time-slot'><i class='fas fa-play'></i> " . htmlspecialchars($fila['inicio']) . "</span></td>";
                echo "<td><span class='time-slot'><i class='fas fa-stop'></i> " . htmlspecialchars($fila['final']) . "</span></td>";
                echo "</tr>";
              }

              mysqli_close($conexion);
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Programación oficial de entrenamientos &bull; Team Dharius.
  </footer>

  <!-- Librerías de exportación a PDF -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>

  <script>
    async function exportarPDF() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF('l', 'pt', 'a4'); 

      doc.setFontSize(16);
      doc.setTextColor(40);
      doc.text("SVG-SPORTS - Programación Oficial de Horarios ", 40, 40);
      doc.setFontSize(11);
      doc.text("Fecha de emisión: " + new Date().toLocaleDateString(), 40, 60);

      doc.autoTable({
        html: '#tablaTorneos',
        startY: 80,
        theme: 'grid',
        styles: {
          cellPadding: 6,
          fontSize: 9
        },
        headStyles: {
          fillColor: [99, 102, 241],
          textColor: 255
        },
        margin: { top: 80, left: 40, right: 40 },
        pageBreak: 'auto'
      });

      doc.save("HORARIOS_SVG_SPORTS.pdf");
    }
  </script>
</body>
</html>