<?php
include("../php/conexion_be.php");

if (isset($_POST['turno'])) {
    $turno = mysqli_real_escape_string($conexion, $_POST['turno']);

    $sql = "SELECT id, turno, inicio, final
            FROM horario
            WHERE turno LIKE '%$turno%'";

    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        echo '<table>
                <thead>
                  <tr>
                    <th>ID</th><th>TURNO</th><th>FECHA DE INICIO</th><th>HORA DE SALIDA</th>
                  </tr>
                </thead>
                <tbody>';
        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo '<tr>
                    <td>' . $fila['id'] . '</td>
                    <td>' . $fila['turno'] . '</td>
                    <td>' . $fila['inicio'] . '</td>
                    <td>' . $fila['final'] . '</td>
                   
                  </tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p style="color: red; font-weight: bold;">No se encontraron resultados.</p>';
    }

    mysqli_close($conexion);
}
?>
