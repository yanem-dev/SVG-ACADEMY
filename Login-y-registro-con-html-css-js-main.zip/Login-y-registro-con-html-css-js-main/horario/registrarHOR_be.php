 <?php
include '../php/conexion_be.php';

$turno = $_POST['turno'];
$inicio = $_POST['inicio'];
$final = $_POST['final'];

   
    $sql = "INSERT INTO horario (turno, inicio, final)
            VALUES ('$turno', '$inicio', '$final')";

    if (mysqli_query($conexion, $sql)) {
        echo "<script>alert('Horario registrado con éxito'); window.location.href='../horarios.php';</script>";
    } else {
        echo "Error al guardar en base de datos: " . mysqli_error($conexion);
    }

mysqli_close($conexion);
?>