<?php
include("../php/conexion_be.php");

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM horario WHERE id = '$id'";

    if (mysqli_query($conexion, $sql)) {
        echo "
        <script>
            alert('Horario eliminado con éxito.');
            window.location.href = '../horarios.php'; // Redirige a la página de búsqueda
        </script>";
    } else {
        echo "
        <script>
            alert('Error al eliminar el torneo.');
            window.location.href = 'eliminarhor.php'; // Redirige a la página de búsqueda
        </script>";
    }

    mysqli_close($conexion);
}
?>
