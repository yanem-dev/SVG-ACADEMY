<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Búsqueda de Horarios</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --gold: #f59e0b;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(56, 189, 248, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(56, 189, 248, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1140px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .header-banner {
      text-align: center;
      max-width: 620px;
      margin: 0 auto 36px;
    }

    .header-banner h1 {
      font-size: 30px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .header-banner p {
      font-size: 14.5px;
      color: var(--text-muted);
      margin-top: 6px;
    }

    /* Barra de Búsqueda */
    .search-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 24px;
      max-width: 660px;
      margin: 0 auto 32px;
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.6);
    }

    .search-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .search-group label {
      font-size: 13px;
      font-weight: 700;
      color: var(--text-main);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .search-group label i {
      color: var(--accent);
    }

    .input-wrapper {
      position: relative;
    }

    .input-wrapper i {
      position: absolute;
      left: 18px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748b;
      font-size: 16px;
      pointer-events: none;
    }

    .input-wrapper input {
      width: 100%;
      background: var(--input-bg);
      border: 1.5px solid var(--border-subtle);
      color: var(--text-main);
      padding: 14px 18px 14px 48px;
      border-radius: 14px;
      font-size: 15px;
      outline: none;
      transition: all 0.25s ease;
    }

    .input-wrapper input:focus {
      border-color: var(--border-focus);
      box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
    }

    /* Contenedor Dinámico de Resultados */
    .resultados-wrapper {
      width: 100%;
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }

    /* Estilos globales para la tabla inyectada por buscarHOR_be.php */
    .resultados-wrapper table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }

    .resultados-wrapper thead {
      background: var(--card-inner);
      border-bottom: 1px solid var(--border-subtle);
    }

    .resultados-wrapper th {
      padding: 14px 18px;
      font-size: 11.5px;
      font-weight: 800;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--accent);
      white-space: nowrap;
    }

    .resultados-wrapper td {
      padding: 14px 18px;
      font-size: 13.5px;
      color: var(--text-main);
      border-bottom: 1px solid var(--border-subtle);
      vertical-align: middle;
      white-space: nowrap;
    }

    .resultados-wrapper tbody tr {
      transition: background-color 0.2s ease;
    }

    .resultados-wrapper tbody tr:hover {
      background-color: rgba(56, 189, 248, 0.04);
    }

    .resultados-wrapper tbody tr:last-child td {
      border-bottom: none;
    }

    /* Estado inicial / Sin resultados */
    .empty-search-state {
      padding: 56px 20px;
      text-align: center;
      color: var(--text-muted);
    }

    .empty-search-state i {
      font-size: 42px;
      color: #334155;
      margin-bottom: 14px;
    }

    .empty-search-state h3 {
      font-size: 18px;
      font-weight: 700;
      color: var(--text-main);
      margin-bottom: 6px;
    }

    .empty-search-state p {
      font-size: 13.5px;
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .header-banner h1 {
        font-size: 24px;
      }
      .search-card {
        padding: 18px;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../horarios.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-magnifying-glass"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <a href="../horarios.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver a Horarios</span>
    </a>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel Administrador</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_admin.php">Gestión de Alumnos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../horarios.php">Horarios</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Búsqueda</span>
    </div>

    <div class="header-banner">
      <h1>Búsqueda Rápida de Horarios</h1>
      <p>Localiza franjas y turnos de entrenamiento en tiempo real por denominación o etiqueta.</p>
    </div>

    <!-- Caja de Búsqueda -->
    <div class="search-card">
      <div class="search-group">
        <label for="busqueda"><i class="fas fa-filter"></i> Ingresa el Turno o Categoría</label>
        <div class="input-wrapper">
          <i class="fas fa-search"></i>
          <input type="text" id="busqueda" name="turno" placeholder="Ej. Matutino, Vespertino, Infantil..." autocomplete="off" autofocus>
        </div>
      </div>
    </div>

    <!-- Contenedor Dinámico de Resultados -->
    <div class="resultados-wrapper">
      <div id="tabla-resultados">
        <div class="empty-search-state">
          <i class="fas fa-keyboard"></i>
          <h3>Comienza a escribir para buscar</h3>
          <p>Las coincidencias del cronograma oficial de Team Dharius se desplegarán aquí automáticamente.</p>
        </div>
      </div>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de horarios y turnos &bull; Team Dharius.
  </footer>

  <script>
    document.getElementById('busqueda').addEventListener('input', function() {
      const valor = this.value.trim();
      const contenedor = document.getElementById('tabla-resultados');

      if (valor === "") {
        contenedor.innerHTML = `
          <div class="empty-search-state">
            <i class="fas fa-keyboard"></i>
            <h3>Comienza a escribir para buscar</h3>
            <p>Las coincidencias del cronograma oficial de Team Dharius se desplegarán aquí automáticamente.</p>
          </div>`;
        return;
      }

      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'buscarHOR_be.php', true);
      xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
      xhr.onload = function() {
        if (xhr.status === 200) {
          contenedor.innerHTML = xhr.responseText;
        }
      };
      xhr.send('turno=' + encodeURIComponent(valor));
    });
  </script>
</body>
</html>