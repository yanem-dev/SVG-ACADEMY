<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Registrar Horario</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --emerald: #10b981;
      --emerald-glow: rgba(16, 185, 129, 0.25);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(56, 189, 248, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(56, 189, 248, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 620px;
      margin: 0 auto;
      padding: 40px 20px;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 16px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .form-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 24px;
      padding: 38px 32px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    }

    .form-header {
      margin-bottom: 28px;
      padding-bottom: 18px;
      border-bottom: 1px solid var(--border-subtle);
      text-align: center;
    }

    .badge-header {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(56, 189, 248, 0.12);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 10px;
    }

    .form-header h2 {
      font-size: 24px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .form-header p {
      font-size: 13.5px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    .form-fields {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .form-group label {
      font-size: 13px;
      font-weight: 600;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .input-wrapper {
      position: relative;
    }

    .input-wrapper i {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748b;
      font-size: 14px;
      pointer-events: none;
    }

    .input-wrapper input {
      width: 100%;
      background: var(--input-bg);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 13px 16px 13px 44px;
      border-radius: 12px;
      font-size: 14px;
      outline: none;
      transition: all 0.2s ease;
    }

    .input-wrapper input:focus {
      border-color: var(--border-focus);
      box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
    }

    .time-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    /* Acciones */
    .btn-actions {
      display: flex;
      gap: 12px;
      margin-top: 30px;
      padding-top: 22px;
      border-top: 1px solid var(--border-subtle);
    }

    .btn-submit {
      flex: 2;
      background: var(--accent);
      color: #042f2e;
      border: none;
      padding: 14px;
      border-radius: 12px;
      font-size: 14.5px;
      font-weight: 800;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--accent-glow);
      transition: all 0.2s ease;
    }

    .btn-submit:hover {
      background: #0284c7;
      color: #ffffff;
      transform: translateY(-1px);
    }

    .btn-cancel {
      flex: 1;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 14px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s ease;
    }

    .btn-cancel:hover {
      color: var(--text-main);
      border-color: var(--text-muted);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 600px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .form-card {
        padding: 28px 20px;
      }
      .time-grid {
        grid-template-columns: 1fr;
      }
      .btn-actions {
        flex-direction: column;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../horarios.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-calendar-plus"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <a href="../horarios.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver a Horarios</span>
    </a>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel Administrador</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_admin.php">Gestión de Alumnos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../horarios.php">Horarios</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Nuevo Turno</span>
    </div>

    <div class="form-card">
      <div class="form-header">
        <span class="badge-header"><i class="fas fa-clock"></i> Cronograma Oficial</span>
        <h2>Registrar Franja Horaria</h2>
        <p>Establece un nuevo turno y franja de entrenamiento para el dojo.</p>
      </div>

      <form action="registrarHOR_be.php" method="POST" enctype="multipart/form-data">
        <div class="form-fields">
          <div class="form-group">
            <label for="turno"><i class="fas fa-tag"></i> Turno / Denominación</label>
            <div class="input-wrapper">
              <i class="fas fa-graduation-cap"></i>
              <input type="text" id="turno" name="turno" placeholder="Ej. Matutino Infantil, Vespertino Avanzados" required>
            </div>
          </div>

          <div class="time-grid">
            <div class="form-group">
              <label for="inicio"><i class="fas fa-play"></i> Hora de Inicio</label>
              <div class="input-wrapper">
                <i class="fas fa-clock"></i>
                <input type="text" id="inicio" name="inicio" placeholder="Ej. 08:00 AM o 16:00" required>
              </div>
            </div>

            <div class="form-group">
              <label for="final"><i class="fas fa-stop"></i> Hora de Salida</label>
              <div class="input-wrapper">
                <i class="fas fa-flag-checkered"></i>
                <input type="text" id="final" name="final" placeholder="Ej. 09:30 AM o 17:30" required>
              </div>
            </div>
          </div>
        </div>

        <div class="btn-actions">
          <button type="submit" class="btn-submit">
            <i class="fas fa-floppy-disk"></i>
            <span>Guardar Horario</span>
          </button>
          <a href="../horarios.php" class="btn-cancel">
            Cancelar
          </a>
        </div>
      </form>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de horarios y turnos &bull; Team Dharius.
  </footer>

</body>
</html>