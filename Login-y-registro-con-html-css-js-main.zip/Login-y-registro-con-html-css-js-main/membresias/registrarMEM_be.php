 <?php
include '../php/conexion_be.php';

$tipo = $_POST['tipo'];
$fecha = $_POST['fecha'];
$precio = $_POST['precio'];

   
    $sql = "INSERT INTO membresia (tipo, fecha, precio)
            VALUES ('$tipo', '$fecha', '$precio')";

    if (mysqli_query($conexion, $sql)) {
        echo "<script>alert('Membresia registrada con éxito'); window.location.href='../membresia.php';</script>";
    } else {
        echo "Error al guardar en base de datos: " . mysqli_error($conexion);
    }

mysqli_close($conexion);
?>