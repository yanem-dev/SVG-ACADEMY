<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Padrón de Membresías</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --accent: #38bdf8;
      --emerald: #10b981;
      --emerald-hover: #059669;
      --emerald-glow: rgba(16, 185, 129, 0.25);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #10b981;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(16, 185, 129, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex; flex-direction: column;
    }

    .app-header {
      background: rgba(17, 24, 39, 0.85); backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle); padding: 16px 32px;
      display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100;
    }
    .brand-logo { display: flex; align-items: center; gap: 12px; text-decoration: none; }
    .brand-icon {
      width: 40px; height: 40px; background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--emerald); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 12px;
      display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 0 15px var(--emerald-glow);
    }
    .brand-title { font-size: 20px; font-weight: 800; color: var(--text-main); }
    .brand-title .highlight { color: var(--emerald); }

    .btn-return {
      background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 8px 18px; border-radius: 10px; font-size: 13.5px; font-weight: 600;
      text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease; cursor: pointer;
    }
    .btn-return:hover { background: rgba(16, 185, 129, 0.15); color: var(--emerald); border-color: var(--emerald); }

    .dashboard-container { width: 100%; max-width: 1140px; margin: 0 auto; padding: 40px 24px; flex: 1; }
    .page-indicator { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-muted); margin-bottom: 12px; }
    .page-indicator a { color: var(--text-muted); text-decoration: none; }
    .page-indicator a:hover { color: var(--emerald); }

    .top-actions-bar {
      display: flex; justify-content: space-between; align-items: flex-end;
      flex-wrap: wrap; gap: 20px; margin-bottom: 28px;
    }
    .top-actions-bar h1 { font-size: 28px; font-weight: 800; letter-spacing: -0.02em; }
    .top-actions-bar p { font-size: 14px; color: var(--text-muted); margin-top: 4px; }

    .actions-group { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
    .search-wrapper { position: relative; }
    .search-wrapper i { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #64748b; font-size: 13px; }
    .search-input {
      background: var(--card-bg); border: 1px solid var(--border-subtle); color: var(--text-main);
      padding: 10px 14px 10px 38px; border-radius: 12px; font-size: 13.5px; outline: none; width: 260px;
    }
    .search-input:focus { border-color: var(--emerald); box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.15); }

    .btn-pdf {
      background: var(--emerald); color: #042f2e; border: none; padding: 10px 20px;
      border-radius: 12px; font-size: 13.5px; font-weight: 700; cursor: pointer;
      display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 4px 14px var(--emerald-glow);
    }
    .btn-pdf:hover { background: var(--emerald-hover); color: #ffffff; transform: translateY(-2px); }

    .table-card {
      background: var(--card-bg); border: 1px solid var(--border-subtle);
      border-radius: 20px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }
    .table-responsive { overflow-x: auto; width: 100%; max-height: 680px; }
    table { width: 100%; border-collapse: collapse; text-align: left; }
    thead { background: var(--card-inner); position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 0 var(--border-subtle); }
    th {
      padding: 16px 18px; font-size: 11.5px; font-weight: 800; letter-spacing: 0.05em;
      text-transform: uppercase; color: var(--emerald); white-space: nowrap;
    }
    td {
      padding: 14px 18px; font-size: 13.5px; color: var(--text-main);
      border-bottom: 1px solid var(--border-subtle); vertical-align: middle; white-space: nowrap;
    }
    tbody tr:hover { background-color: rgba(16, 185, 129, 0.04); }
    tbody tr:last-child td { border-bottom: none; }

    .badge-id {
      background: var(--card-inner); border: 1px solid var(--border-subtle);
      padding: 4px 8px; border-radius: 6px; font-weight: 700; font-size: 12px; color: var(--text-muted);
    }
    .plan-title { font-weight: 700; color: var(--text-main); }
    .badge-weeks {
      display: inline-flex; align-items: center; gap: 6px;
      background: rgba(56, 189, 248, 0.12); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.25);
      padding: 3px 10px; border-radius: 6px; font-size: 12px; font-weight: 700;
    }
    .price-tag { font-weight: 800; color: var(--emerald); }

    .app-footer { border-top: 1px solid var(--border-subtle); padding: 24px; text-align: center; font-size: 12.5px; color: var(--text-muted); background: var(--bg-dark); }
  </style>
</head>
<body>

  <header class="app-header">
    <a href="../membresia.php" class="brand-logo">
      <div class="brand-icon"><i class="fas fa-table-list"></i></div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>
    <button onclick="window.history.back();" class="btn-return">
      <i class="fas fa-chevron-left"></i><span>Volver</span>
    </button>
  </header>

  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_adminIII.php">Ventas y Membresías</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../membresia.php">Membresías</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Catálogo de Planes</span>
    </div>

    <div class="top-actions-bar">
      <div>
        <h1>Lista de Membresías Registradas</h1>
        <p>Catálogo consolidado de suscripciones, duración en semanas y aranceles oficiales.</p>
      </div>

      <div class="actions-group">
        <div class="search-wrapper">
          <i class="fas fa-magnifying-glass"></i>
          <input type="text" id="filtroTabla" class="search-input" placeholder="Filtrar por periodicidad..." onkeyup="filtrarMembresias()">
        </div>
        <button onclick="exportarPDF()" class="btn-pdf">
          <i class="fas fa-file-pdf"></i>
          <span>Crear reporte de membresías</span>
        </button>
      </div>
    </div>

    <div class="table-card">
      <div class="table-responsive">
        <table id="tablaProductos">
          <thead>
            <tr>
              <th>ID de Membresía</th>
              <th>Tipo / Plan</th>
              <th>Duración (Semanas)</th>
              <th>Precio</th>
            </tr>
          </thead>
          <tbody>
            <?php
              include("../php/conexion_be.php");
              $sql = "SELECT id,tipo,fecha,precio FROM membresia";
              $resultado = mysqli_query($conexion, $sql);

              while ($fila = mysqli_fetch_assoc($resultado)) {
            ?>
              <tr>
                <td><span class="badge-id">#<?= htmlspecialchars($fila['id']) ?></span></td>
                <td class="plan-title"><?= htmlspecialchars($fila['tipo']) ?></td>
                <td>
                  <span class="badge-weeks">
                    <i class="fas fa-clock"></i> <?= htmlspecialchars($fila['fecha']) ?> semanas
                  </span>
                </td>
                <td class="price-tag">$<?= number_format(floatval($fila['precio']), 2) ?></td>
              </tr>
            <?php
              }
              mysqli_close($conexion);
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de gestión de membresías &bull; Team Dharius.
  </footer>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>

  <script>
    function filtrarMembresias() {
      const input = document.getElementById("filtroTabla");
      const filtro = input.value.toUpperCase();
      const tabla = document.getElementById("tablaProductos");
      const tr = tabla.getElementsByTagName("tr");

      for (let i = 1; i < tr.length; i++) {
        let textoFila = tr[i].textContent || tr[i].innerText;
        if (textoFila.toUpperCase().indexOf(filtro) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }

    async function exportarPDF() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF('l', 'pt', 'a4');

      doc.setFontSize(16);
      doc.setTextColor(40);
      doc.text("LISTA DE MEMBRESIAS REGISTRADAS - TEAM DHARIUS", 40, 40);
      doc.setFontSize(11);
      doc.text("FECHA DE EMISIÓN: " + new Date().toLocaleDateString(), 40, 60);

      doc.autoTable({
        html: '#tablaProductos',
        startY: 80,
        theme: 'grid',
        styles: { cellPadding: 5, fontSize: 8.5 },
        headStyles: { fillColor: [16, 185, 129], textColor: [4, 47, 46] },
        margin: { top: 80, left: 40, right: 40 },
        pageBreak: 'auto'
      });

      doc.save("MEMBRESIAS_SVG_SPORTS.pdf");
    }
  </script>
</body>
</html>