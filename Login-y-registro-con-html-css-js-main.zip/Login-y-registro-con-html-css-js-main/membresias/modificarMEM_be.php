<?php
include("../php/conexion_be.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $id = $_POST['id'];

    $updates = [];

   

    if (!empty($_POST['tipo'])) {
        $tipo = mysqli_real_escape_string($conexion, $_POST['tipo']);
        $updates[] = "tipo = '$tipo'";
    }

    if (!empty($_POST['fecha'])) {
        $fecha = (float)$_POST['fecha'];
        $updates[] = "fecha = '$fecha'";
    }

    if (!empty($_POST['precio'])) {
        $precio = (float)$_POST['precio'];
        $updates[] = "precio = '$precio'";
    }

    }

    if (!empty($updates)) {
        $updates_sql = implode(", ", $updates);

        $sql = "UPDATE membresia SET $updates_sql WHERE id = '$id'";

        if (mysqli_query($conexion, $sql)) {
            echo "<script>alert('Membresia actualizada correctamente'); window.location.href = '../membresia.php';</script>";
        } else {
            echo "Error al actualizar: " . mysqli_error($conexion);
        }
    } else {
        echo "<script>alert('No se recibieron datos nuevos para actualizar.'); window.history.back();</script>";
    }

mysqli_close($conexion);
?>
