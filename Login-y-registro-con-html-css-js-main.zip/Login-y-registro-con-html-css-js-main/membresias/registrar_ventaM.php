<?php
include("../php/conexion_be.php");
session_start();

if (!isset($_SESSION['id_estudiante'])) {
    echo "No has iniciado sesión.";
    exit;
}

$id_alumno = $_SESSION['id_estudiante'];

$datos = json_decode(file_get_contents("php://input"), true);
$id_membresia = $datos['id_membresia'] ?? null;

if (!$id_membresia) {
    echo "ID de membresía inválido.";
    exit;
}


$verificar = mysqli_query($conexion, "SELECT * FROM membresiap WHERE id_alumno = '$id_alumno' AND estado = 'Activo'");
if (mysqli_num_rows($verificar) > 0) {
    echo "Ya tienes una membresía activa.";
    exit;
}


$resultado = mysqli_query($conexion, "SELECT precio FROM membresia WHERE id = '$id_membresia'");
if (!$resultado || mysqli_num_rows($resultado) === 0) {
    echo "Membresía no encontrada.";
    exit;
}

$fila = mysqli_fetch_assoc($resultado);
$precio = $fila['precio'];

$fecha_pago = date('Y-m-d');
$estado = 'Activo';


$sql = "INSERT INTO membresiap (id_alumno, id_membresia, subtotal, fecha_pago, estado) 
        VALUES ('$id_alumno', '$id_membresia', '$precio', '$fecha_pago', '$estado')";

if (mysqli_query($conexion, $sql)) {
    echo "Membresía registrada exitosamente.";
} else {
    echo "Error al registrar membresía: " . mysqli_error($conexion);
}
?>
