<?php
include("../php/conexion_be.php");

if (isset($_POST['tipo'])) {
    $tipo = mysqli_real_escape_string($conexion, $_POST['tipo']);

    $sql = "SELECT id, tipo, fecha, precio
            FROM membresia
            WHERE tipo LIKE '%$tipo%'";

    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        echo '<table>
                <thead>
                  <tr>
                    <th>ID</th><th>TIPO</th><th>Fecha</th><th>Precio</th>
                  </tr>
                </thead>
                <tbody>';
        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo '<tr>
                    <td>' . $fila['id'] . '</td>
                    <td>' . $fila['tipo'] . '</td>
                    <td>' . $fila['fecha'] . '</td>
                    <td>' . $fila['precio'] . '</td>
                   
                  </tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p style="color: red; font-weight: bold;">No se encontraron resultados.</p>';
    }

    mysqli_close($conexion);
}
?>
