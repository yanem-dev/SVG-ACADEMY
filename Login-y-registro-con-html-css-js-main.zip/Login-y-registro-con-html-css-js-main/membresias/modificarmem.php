<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Modificar Membresía</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --emerald: #10b981;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #6366f1;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(16, 185, 129, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex; flex-direction: column;
    }

    .app-header {
      background: rgba(17, 24, 39, 0.85); backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle); padding: 16px 32px;
      display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100;
    }
    .brand-logo { display: flex; align-items: center; gap: 12px; text-decoration: none; }
    .brand-icon {
      width: 40px; height: 40px; background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(16, 185, 129, 0.2));
      color: var(--primary); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 12px;
      display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 0 15px var(--primary-glow);
    }
    .brand-title { font-size: 20px; font-weight: 800; color: var(--text-main); }
    .brand-title .highlight { color: var(--accent); }

    .btn-return {
      background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 8px 18px; border-radius: 10px; font-size: 13.5px; font-weight: 600;
      text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease; cursor: pointer;
    }
    .btn-return:hover { background: rgba(99, 102, 241, 0.15); color: var(--primary); border-color: var(--primary); }

    .dashboard-container { width: 100%; max-width: 680px; margin: 0 auto; padding: 40px 20px; flex: 1; }
    .page-indicator { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-muted); margin-bottom: 16px; }
    .page-indicator a { color: var(--text-muted); text-decoration: none; }
    .page-indicator a:hover { color: var(--accent); }

    .form-card {
      background: var(--card-bg); border: 1px solid var(--border-subtle);
      border-radius: 24px; padding: 38px 34px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    }

    .form-header { margin-bottom: 26px; padding-bottom: 18px; border-bottom: 1px solid var(--border-subtle); text-align: center; }
    .badge-header {
      display: inline-flex; align-items: center; gap: 6px; background: rgba(99, 102, 241, 0.12);
      color: #818cf8; border: 1px solid rgba(99, 102, 241, 0.3); padding: 4px 12px;
      border-radius: 9999px; font-size: 11px; font-weight: 800; text-transform: uppercase; margin-bottom: 10px;
    }
    .form-header h2 { font-size: 24px; font-weight: 800; letter-spacing: -0.02em; }
    .form-header p { font-size: 13.5px; color: var(--text-muted); margin-top: 4px; }

    .selector-box {
      background: var(--card-inner); border: 1px solid var(--border-subtle);
      border-radius: 16px; padding: 20px; margin-bottom: 24px;
      display: grid; grid-template-columns: 1fr 1fr; gap: 18px; align-items: center;
    }
    .preview-mem { display: flex; flex-direction: column; gap: 4px; }
    .preview-label { font-size: 11.5px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; }
    .preview-name {
      font-size: 15px; font-weight: 700; color: var(--accent); background: rgba(56, 189, 248, 0.08);
      border: 1px dashed rgba(56, 189, 248, 0.3); padding: 8px 14px; border-radius: 10px;
      display: inline-block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }

    .fields-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 18px; }
    .form-group label { font-size: 13px; font-weight: 600; color: var(--text-muted); display: flex; align-items: center; gap: 6px; }

    .input-wrapper { position: relative; }
    .input-wrapper i {
      position: absolute; left: 16px; top: 50%; transform: translateY(-50%);
      color: #64748b; font-size: 14px; pointer-events: none;
    }
    .input-wrapper input, .input-wrapper select {
      width: 100%; background: var(--input-bg); border: 1px solid var(--border-subtle);
      color: var(--text-main); padding: 12px 16px 12px 44px; border-radius: 12px;
      font-size: 14px; outline: none; transition: all 0.2s ease;
    }
    .input-wrapper select { appearance: none; cursor: pointer; }
    .input-wrapper input:focus, .input-wrapper select:focus {
      border-color: var(--border-focus); box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
    }

    .btn-actions { display: flex; gap: 12px; margin-top: 28px; padding-top: 22px; border-top: 1px solid var(--border-subtle); }
    .btn-submit {
      flex: 2; background: var(--primary); color: #ffffff; border: none; padding: 14px;
      border-radius: 12px; font-size: 14.5px; font-weight: 700; cursor: pointer;
      display: inline-flex; align-items: center; justify-content: center; gap: 8px;
      box-shadow: 0 4px 14px var(--primary-glow); transition: all 0.2s ease;
    }
    .btn-submit:hover { background: var(--primary-hover); transform: translateY(-1px); }
    .btn-cancel {
      flex: 1; background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 14px; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer;
      display: inline-flex; align-items: center; justify-content: center; transition: all 0.2s ease;
    }
    .btn-cancel:hover { color: var(--text-main); border-color: var(--text-muted); }

    .app-footer { border-top: 1px solid var(--border-subtle); padding: 24px; text-align: center; font-size: 12.5px; color: var(--text-muted); background: var(--bg-dark); }
    @media (max-width: 640px) { .selector-box, .fields-grid { grid-template-columns: 1fr; } .btn-actions { flex-direction: column; } }
  </style>
</head>
<body>

  <header class="app-header">
    <a href="../membresia.php" class="brand-logo">
      <div class="brand-icon"><i class="fas fa-pen-to-square"></i></div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>
    <button type="button" onclick="window.history.back();" class="btn-return">
      <i class="fas fa-chevron-left"></i><span>Volver</span>
    </button>
  </header>

  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_adminIII.php">Ventas y Membresías</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../membresia.php">Membresías</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Modificar</span>
    </div>

    <div class="form-card">
      <div class="form-header">
        <span class="badge-header"><i class="fas fa-arrows-rotate"></i> Actualización Arancelaria</span>
        <h2>Modificar Registro de Membresía</h2>
        <p>Selecciona el ID del plan para reajustar tarifas, periodicidad o duración en semanas.</p>
      </div>

      <form action="modificarMEM_be.php" method="POST">
        <!-- Selector de ID y Previsualización -->
        <div class="selector-box">
          <div class="form-group" style="margin-bottom: 0;">
            <label for="idMembresias"><i class="fas fa-hashtag"></i> ID del Plan</label>
            <div class="input-wrapper">
              <i class="fas fa-id-badge"></i>
              <select name="id" id="idMembresias" onchange="mostrarNombre()" required>
                <option value="">-- Elige un ID --</option>
                <?php
                  include("../php/conexion_be.php");
                  $sql = "SELECT id, tipo FROM membresia";
                  $resultado = mysqli_query($conexion, $sql);
                  $nombresMembresias = [];

                  while ($fila = mysqli_fetch_assoc($resultado)) {
                    echo "<option value='" . $fila['id'] . "'>ID #" . $fila['id'] . "</option>";
                    $nombresMembresias[$fila['id']] = $fila['tipo'];
                  }
                  mysqli_close($conexion);
                ?>
              </select>
            </div>
          </div>

          <div class="preview-mem">
            <span class="preview-label">Plan Seleccionado</span>
            <span class="preview-name" id="nombreMembresia">---</span>
          </div>
        </div>

        <div class="form-group">
          <label for="tipo"><i class="fas fa-layer-group"></i> Periodicidad / Tipo</label>
          <div class="input-wrapper">
            <i class="fas fa-calendar-check"></i>
            <select name="tipo" id="tipo" required>
              <option value="" disabled selected>-- Elige el tipo --</option>
              <option value="Semanal">Semanal</option>
              <option value="Mensual">Mensual</option>
              <option value="Trimestral">Trimestral</option>
              <option value="Anual">Anual</option>
            </select>
          </div>
        </div>

        <div class="fields-grid">
          <div class="form-group" style="margin-bottom: 0;">
            <label for="fecha"><i class="fas fa-clock"></i> Duración (semanas)</label>
            <div class="input-wrapper">
              <i class="fas fa-hashtag"></i>
              <input type="number" name="fecha" id="fecha" min="1" placeholder="Semanas vigentes">
            </div>
          </div>

          <div class="form-group" style="margin-bottom: 0;">
            <label for="precio"><i class="fas fa-dollar-sign"></i> Precio ($)</label>
            <div class="input-wrapper">
              <i class="fas fa-coins"></i>
              <input type="number" name="precio" id="precio" step="0.01" placeholder="Nuevo costo">
            </div>
          </div>
        </div>

        <div class="btn-actions">
          <button type="submit" class="btn-submit">
            <i class="fas fa-arrows-rotate"></i><span>Actualizar Membresía</span>
          </button>
          <button type="button" onclick="window.history.back();" class="btn-cancel">
            Cancelar
          </button>
        </div>
      </form>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de gestión de membresías &bull; Team Dharius.
  </footer>

  <script>
    const nombres = <?php echo json_encode($nombresMembresias); ?>;

    function mostrarNombre() {
      const idSeleccionado = document.getElementById("idMembresias").value;
      const nombreSpan = document.getElementById("nombreMembresia");
      nombreSpan.textContent = nombres[idSeleccionado] || "---";
    }
  </script>
</body>
</html>