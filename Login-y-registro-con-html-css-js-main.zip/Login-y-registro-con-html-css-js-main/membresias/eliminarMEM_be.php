<?php
include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];

 
    $sql = "DELETE FROM membresia WHERE id = '$id'";

    if (mysqli_query($conexion, $sql)) {
        echo '
        <script>
            alert("Membresia eliminada correctamente.");
            window.location = "../membresia.php";
        </script>
        ';
    } else {
        echo '
        <script>
            alert("Error al eliminar la membresia.");
            window.location = "eliminarmem.php";
        </script>
        ';
    }

    mysqli_close($conexion);
}
?>
