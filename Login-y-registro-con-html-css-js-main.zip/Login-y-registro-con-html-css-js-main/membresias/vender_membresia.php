<?php
include("../php/conexion_be.php");
session_start();

if (!isset($_SESSION['id_estudiante'])) {
    echo "Debes iniciar sesión.";
    exit;
}

$id_estudiante =$_SESSION['id_estudiante'];

$verificar = mysqli_query($conexion, "SELECT * FROM membresiap WHERE id_alumno = '$id_estudiante' AND estado = 'Activo'");
$tiene_activa = mysqli_num_rows($verificar) > 0;

$sql = "SELECT * FROM membresia";
$resultado = mysqli_query($conexion,$sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-REDSPORT | Adquisición de Membresías</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --accent: #38bdf8;
      --gold: #f59e0b;
      --gold-hover: #d97706;
      --gold-glow: rgba(245, 158, 11, 0.25);
      --emerald: #10b981;
      --emerald-glow: rgba(16, 185, 129, 0.2);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #f59e0b;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(245, 158, 11, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--gold-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--gold);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(245, 158, 11, 0.15);
      color: var(--gold);
      border-color: var(--gold);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 40px 24px 120px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--gold);
    }

    .header-banner {
      text-align: center;
      max-width: 680px;
      margin: 0 auto 40px;
    }

    .header-banner h1 {
      font-size: 32px;
      font-weight: 800;
      letter-spacing: -0.02em;
      margin-bottom: 8px;
    }

    .header-banner p {
      font-size: 15px;
      color: var(--text-muted);
      line-height: 1.5;
    }

    /* Banner cuando ya cuenta con membresía activa */
    .active-plan-banner {
      background: rgba(16, 185, 129, 0.08);
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 24px;
      padding: 40px 28px;
      max-width: 640px;
      margin: 0 auto;
      text-align: center;
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.6);
    }

    .active-plan-banner i {
      font-size: 50px;
      color: var(--emerald);
      margin-bottom: 16px;
      display: block;
    }

    .active-plan-banner h3 {
      font-size: 22px;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 8px;
    }

    .active-plan-banner p {
      font-size: 14px;
      color: var(--text-muted);
      margin-bottom: 24px;
      line-height: 1.6;
    }

    /* Grid de Membresías */
    .products-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 26px;
      align-items: stretch;
    }

    .product {
      background: var(--card-bg);
      border: 1.5px solid var(--border-subtle);
      border-radius: 24px;
      padding: 32px 26px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      cursor: pointer;
      transition: all 0.25s ease;
      position: relative;
      overflow: hidden;
    }

    .product::before {
      content: "";
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 3px;
      background: transparent;
      transition: background 0.25s ease;
    }

    .product:hover {
      transform: translateY(-4px);
      border-color: rgba(245, 158, 11, 0.5);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.7);
    }

    .product:hover::before {
      background: var(--gold);
    }

    .product.seleccionada {
      border-color: var(--gold);
      background: linear-gradient(180deg, rgba(245, 158, 11, 0.08) 0%, var(--card-bg) 100%);
      box-shadow: 0 0 30px var(--gold-glow);
    }

    .product.seleccionada::before {
      background: var(--gold);
    }

    .plan-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(245, 158, 11, 0.12);
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.3);
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 16px;
      align-self: flex-start;
    }

    .product-title {
      font-size: 22px;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 6px;
    }

    .product-price {
      font-size: 36px;
      font-weight: 800;
      color: var(--gold);
      margin: 16px 0 22px;
      display: flex;
      align-items: baseline;
      gap: 4px;
    }

    .product-price span {
      font-size: 13px;
      color: var(--text-muted);
      font-weight: 600;
    }

    .plan-features {
      list-style: none;
      border-top: 1px solid var(--border-subtle);
      padding-top: 18px;
      margin-bottom: 24px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .plan-features li {
      font-size: 13px;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .plan-features li i {
      color: var(--emerald);
      font-size: 13px;
    }

    .btn-select-visual {
      width: 100%;
      background: var(--card-inner);
      color: var(--text-main);
      border: 1px solid var(--border-subtle);
      padding: 12px;
      border-radius: 12px;
      font-size: 13.5px;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .product:hover .btn-select-visual {
      background: rgba(245, 158, 11, 0.15);
      border-color: var(--gold);
      color: var(--gold);
    }

    .product.seleccionada .btn-select-visual {
      background: var(--gold);
      color: #1a1200;
      border-color: var(--gold);
      font-weight: 800;
    }

    /* Barra Sticky Inferior de Pago */
    .sticky-checkout-bar {
      position: fixed;
      bottom: 24px;
      left: 50%;
      transform: translateX(-50%) translateY(140%);
      width: 90%;
      max-width: 620px;
      background: rgba(17, 24, 39, 0.95);
      backdrop-filter: blur(16px);
      border: 1px solid var(--gold);
      border-radius: 20px;
      padding: 16px 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.8), 0 0 20px var(--gold-glow);
      transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
      z-index: 900;
    }

    .sticky-checkout-bar.active {
      transform: translateX(-50%) translateY(0);
    }

    .summary-text h4 {
      font-size: 15px;
      font-weight: 800;
      color: var(--text-main);
    }

    .summary-text span {
      font-size: 13.5px;
      color: var(--gold);
      font-weight: 700;
    }

    .btn-confirm {
      background: var(--gold);
      color: #1a1200;
      border: none;
      padding: 12px 24px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 800;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--gold-glow);
      transition: all 0.2s ease;
    }

    .btn-confirm:hover {
      background: var(--gold-hover);
      color: #ffffff;
      transform: translateY(-1px);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header { padding: 16px; }
      .dashboard-container { padding: 24px 16px 140px; }
      .header-banner h1 { font-size: 24px; }
      .sticky-checkout-bar { flex-direction: column; gap: 12px; text-align: center; }
      .btn-confirm { width: 100%; justify-content: center; }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../bienvenidaAlumnos.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-crown"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-REDSPORT</span></span>
    </a>

    <a href="../bienvenidaAlumnos.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver a Mi Panel</span>
    </a>
  </header>

  <!-- Contenedor Principal -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Adquirir Membresía</span>
    </div>

    <div class="header-banner">
      <h1>Planes y Suscripciones Oficiales</h1>
      <p>Selecciona tu cuota de afiliación deportiva para activar tu acceso a entrenamientos y torneos del circuito.</p>
    </div>

    <?php if ($tiene_activa): ?>
      <!-- Caso en que ya tiene membresía activa -->
      <div class="active-plan-banner">
        <i class="fas fa-shield-halved"></i>
        <h3>¡Tu membresía se encuentra activa!</h3>
        <p>Actualmente dispones de una cuota vigente registrada en la plataforma. Podrás adquirir o renovar un nuevo plan una vez concluido tu ciclo actual.</p>
        <a href="../bienvenidaAlumnos.php" class="btn-confirm" style="text-decoration: none;">
          <i class="fas fa-house"></i>
          <span>Volver al Menú Principal</span>
        </a>
      </div>
    <?php else: ?>
      <!-- Grid de selección de planes -->
      <div class="products-container">
        <?php while ($row = mysqli_fetch_assoc($resultado)): ?>
          <div class="product" onclick="seleccionarMembresia(<?= $row['id']; ?>, '<?= addslashes($row['tipo']); ?>', <?=$row['precio']; ?>)">
            <div>
              <span class="plan-badge"><i class="fas fa-bolt"></i> Afiliación Oficial</span>
              <div class="product-title"><?= htmlspecialchars($row['tipo']); ?></div>

              <div class="product-price">
                $<?= number_format($row['precio'], 2); ?>
                <span>/ ciclo</span>
              </div>

              <ul class="plan-features">
                <li><i class="fas fa-check"></i> Acceso a sesiones y turnos</li>
                <li><i class="fas fa-check"></i> Registro oficial de atleta</li>
                <li><i class="fas fa-check"></i> Comprobante digital inmediato</li>
              </ul>
            </div>

            <div class="btn-select-visual">
              <i class="fas fa-circle-check"></i>
              <span>Seleccionar Plan</span>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php endif; ?>
  </main>

  <!-- Barra Sticky de Confirmación de Pago -->
  <?php if (!$tiene_activa): ?>
    <div class="sticky-checkout-bar" id="stickyCheckout">
      <div class="summary-text">
        <h4 id="nombrePlanSeleccionado">Plan Seleccionado</h4>
        <span id="precioPlanSeleccionado">$0.00 MXN</span>
      </div>
      <button class="btn-confirm" id="confirmarCompra" onclick="confirmarCompra()">
        <i class="fas fa-arrow-right"></i>
        <span>Confirmar Membresía</span>
      </button>
    </div>
  <?php endif; ?>

  <footer class="app-footer">
    SVG-REDSPORT &bull; Módulo de Afiliaciones y Membresías Deportivas
  </footer>

  <script>
    const { jsPDF } = window.jspdf;
    let seleccionadaId = null;
    let tipoSeleccionado = '';
    let precioSeleccionado = 0;

    function seleccionarMembresia(id, tipo, precio) {
      document.querySelectorAll('.product').forEach(p => p.classList.remove('seleccionada'));

      const productos = document.querySelectorAll('.product');
      productos.forEach(p => {
        if (p.getAttribute('onclick') && p.getAttribute('onclick').includes(`(${id},`)) {
          p.classList.add('seleccionada');
        }
      });

      seleccionadaId = id;
      tipoSeleccionado = tipo;
      precioSeleccionado = precio;

      // Actualizar y desplegar barra inferior
      const stickyBar = document.getElementById('stickyCheckout');
      const txtNombre = document.getElementById('nombrePlanSeleccionado');
      const txtPrecio = document.getElementById('precioPlanSeleccionado');

      if (stickyBar) {
        txtNombre.textContent = `Membresía ${tipo}`;
        txtPrecio.textContent = `$${parseFloat(precio).toFixed(2)} MXN`;
        stickyBar.classList.add('active');
      }
    }

    function confirmarCompra() {
      if (!seleccionadaId) return;

      const btn = document.getElementById('confirmarCompra');
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';

      fetch("registrar_ventaM.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id_membresia: seleccionadaId })
      })
      .then(res => {
        if (!res.ok) {
          throw new Error("Estado HTTP " + res.status);
        }
        return res.text();
      })
      .then(msg => {
        alert(msg);
        if (msg.toLowerCase().includes("exitosamente") || msg.toLowerCase().includes("éxito")) {
          const fechaCompra = new Date().toLocaleDateString();
          try {
            generarPDFTicket(tipoSeleccionado, precioSeleccionado, fechaCompra);
          } catch (e) {
            console.error("Error al generar PDF:", e);
          }
          setTimeout(() => {
            window.location.href = "../bienvenidaAlumnos.php";
          }, 1200);
        } else {
          btn.disabled = false;
          btn.innerHTML = '<i class="fas fa-arrow-right"></i> Confirmar Membresía';
        }
      })
      .catch(err => {
        alert("Error de comunicación: " + err.message);
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-arrow-right"></i> Confirmar Membresía';
      });
    }

    function generarPDFTicket(tipo, precio, fecha) {
      const doc = new jsPDF({ unit: 'pt', format: [400, 300] });
      doc.setFontSize(13);
      doc.text("SVG-REDSPORT", 200, 35, { align: 'center' });
      doc.setFontSize(10);
      doc.text("Comprobante Oficial de Adquisición", 200, 52, { align: 'center' });
      doc.line(35, 65, 365, 65);
      doc.text(`Membresía: ${tipo}`, 45, 95);
      doc.text(`Monto:      $${parseFloat(precio).toFixed(2)} MXN`, 45, 118);
      doc.text(`Fecha:      ${fecha}`, 45, 140);
      doc.text(`Estado:     Activo / Confirmado`, 45, 162);
      doc.line(35, 180, 365, 180);
      doc.setFontSize(9);
      doc.text("¡Afiliación confirmada exitosamente!", 200, 205, { align: 'center' });
      doc.save(`Ticket_Membresia_${tipo}_${Date.now()}.pdf`);
    }
  </script>
</body>
</html>
<?php mysqli_close($conexion); ?>