<?php
include("../php/conexion_be.php");
session_start();

header('Content-Type: application/json'); 

if (!isset($_SESSION['id_estudiante'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "No has iniciado sesión."]);
    exit;
}

$id_estudiante = $_SESSION['id_estudiante'];
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Datos inválidos."]);
    exit;
}

$query = "INSERT INTO ventap (id_producto, id_alumno, subtotal) VALUES (?, ?, ?)";
$stmt = mysqli_prepare($conexion, $query);

if ($stmt === false) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Error al preparar la consulta de venta."]);
    exit;
}

foreach ($data as $producto) {
    $id_producto = $producto['id'];
    $cantidad = $producto['cantidad'];
    $subtotal = $producto['precio'] * $cantidad;

    mysqli_stmt_bind_param($stmt, "iis", $id_producto, $id_estudiante, $subtotal);

    if (!mysqli_stmt_execute($stmt)) {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Error al registrar la venta."]);
        exit;
    }

    $update = "UPDATE productos SET stockP = stockP - ? WHERE id_producto = ?";
    $update_stmt = mysqli_prepare($conexion, $update);

    if ($update_stmt === false) {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Error al preparar la actualización de stock."]);
        exit;
    }

    mysqli_stmt_bind_param($update_stmt, "ii", $cantidad, $id_producto);

    if (!mysqli_stmt_execute($update_stmt)) {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Error al actualizar el stock."]);
        exit;
    }

    mysqli_stmt_close($update_stmt);
}

mysqli_stmt_close($stmt);
mysqli_close($conexion);

echo json_encode(["success" => true, "message" => "Compra registrada con éxito."]);
?>
