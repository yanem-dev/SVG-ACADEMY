<?php
include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_producto = $_POST['id_producto'];

    $sql_imagen = "SELECT imagenP FROM productos WHERE id_producto = '$id_producto'";
    $resultado_imagen = mysqli_query($conexion, $sql_imagen);
    $fila_imagen = mysqli_fetch_assoc($resultado_imagen);

    if ($fila_imagen) {
        $ruta_imagen = "uploads/" . $fila_imagen['imagenP'];
        if (file_exists($ruta_imagen)) {
            unlink($ruta_imagen); 
        }
    }

 
    $sql = "DELETE FROM productos WHERE id_producto = '$id_producto'";

    if (mysqli_query($conexion, $sql)) {
        echo '
        <script>
            alert("Producto eliminado correctamente.");
            window.location = "../ventas.php";
        </script>
        ';
    } else {
        echo '
        <script>
            alert("Error al eliminar el producto.");
            window.location = "eliminarproductos.php";
        </script>
        ';
    }

    mysqli_close($conexion);
}
?>
