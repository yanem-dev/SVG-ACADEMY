<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Checkout y Carrito</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.25);
      --emerald: #10b981;
      --emerald-glow: rgba(16, 185, 129, 0.25);
      --danger: #ef4444;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(56, 189, 248, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(56, 189, 248, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-return:hover {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1140px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .header-banner {
      margin-bottom: 32px;
    }

    .header-banner h1 {
      font-size: 30px;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .header-banner p {
      font-size: 14px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    /* Layout Dos Columnas para Checkout */
    .checkout-grid {
      display: grid;
      grid-template-columns: 1fr 340px;
      gap: 28px;
      align-items: flex-start;
    }

    .cart-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.5);
    }

    .table-responsive {
      overflow-x: auto;
      width: 100%;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }

    thead {
      background: var(--card-inner);
      border-bottom: 1px solid var(--border-subtle);
    }

    th {
      padding: 16px 20px;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--accent);
    }

    td {
      padding: 18px 20px;
      font-size: 14px;
      color: var(--text-main);
      border-bottom: 1px solid var(--border-subtle);
      vertical-align: middle;
    }

    .product-cell {
      font-weight: 700;
      color: var(--text-main);
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .product-icon {
      width: 36px;
      height: 36px;
      border-radius: 8px;
      background: rgba(56, 189, 248, 0.12);
      color: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 15px;
    }

    /* Controles de Cantidad (+ / -) */
    .qty-controls {
      display: inline-flex;
      align-items: center;
      background: var(--input-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 8px;
      overflow: hidden;
    }

    .qty-btn {
      background: transparent;
      border: none;
      color: var(--text-muted);
      width: 28px;
      height: 28px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s ease;
    }

    .qty-btn:hover {
      background: var(--card-inner);
      color: var(--text-main);
    }

    .qty-num {
      padding: 0 8px;
      font-weight: 700;
      font-size: 13px;
    }

    .btn-delete {
      background: transparent;
      border: none;
      color: #64748b;
      cursor: pointer;
      font-size: 14px;
      transition: color 0.2s ease;
    }

    .btn-delete:hover {
      color: var(--danger);
    }

    /* Resumen de Pago (Sidebar) */
    .summary-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 26px 24px;
      position: sticky;
      top: 96px;
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.5);
    }

    .summary-card h3 {
      font-size: 18px;
      font-weight: 800;
      margin-bottom: 20px;
      padding-bottom: 14px;
      border-bottom: 1px solid var(--border-subtle);
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .summary-card h3 i {
      color: var(--emerald);
    }

    .summary-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 12px;
      font-size: 13.5px;
      color: var(--text-muted);
    }

    .summary-row.total {
      margin-top: 20px;
      padding-top: 16px;
      border-top: 1px dashed var(--border-subtle);
      font-size: 18px;
      font-weight: 800;
      color: var(--text-main);
    }

    .summary-row.total .price-tag {
      color: var(--accent);
      font-size: 22px;
    }

    .btn-checkout {
      width: 100%;
      background: var(--emerald);
      color: #062817;
      border: none;
      padding: 14px;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 800;
      cursor: pointer;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 10px;
      margin-top: 24px;
      box-shadow: 0 4px 16px var(--emerald-glow);
      transition: all 0.2s ease;
    }

    .btn-checkout:hover {
      background: #059669;
      color: white;
      transform: translateY(-2px);
    }

    .btn-continue {
      width: 100%;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 12px;
      border-radius: 12px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
      margin-top: 10px;
      transition: all 0.2s ease;
    }

    .btn-continue:hover {
      color: var(--text-main);
      border-color: var(--text-muted);
    }

    /* Estado Carrito Vacío */
    .empty-cart {
      display: none;
      text-align: center;
      padding: 50px 20px;
    }

    .empty-cart i {
      font-size: 48px;
      color: #475569;
      margin-bottom: 16px;
    }

    .empty-cart h3 {
      font-size: 20px;
      font-weight: 800;
      margin-bottom: 8px;
    }

    .empty-cart p {
      color: var(--text-muted);
      font-size: 14px;
      margin-bottom: 24px;
    }

    /* Modal de Recibo / Ticket */
    .modal {
      display: none;
      position: fixed;
      z-index: 9999;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(8px);
      justify-content: center;
      align-items: center;
      padding: 20px;
    }

    .modal-content {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 32px;
      border-radius: 24px;
      width: 100%;
      max-width: 480px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.8);
      text-align: center;
      animation: popIn 0.25s ease-out;
    }

    @keyframes popIn {
      from { opacity: 0; transform: scale(0.92); }
      to { opacity: 1; transform: scale(1); }
    }

    .ticket-badge {
      width: 52px;
      height: 52px;
      border-radius: 16px;
      background: rgba(16, 185, 129, 0.15);
      color: var(--emerald);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      margin-bottom: 16px;
    }

    .modal-content h2 {
      font-size: 22px;
      font-weight: 800;
      margin-bottom: 6px;
    }

    .modal-content p.subtitle {
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 24px;
    }

    .ticket-box {
      background: var(--input-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 14px;
      padding: 16px;
      text-align: left;
      font-size: 13px;
      margin-bottom: 24px;
    }

    .ticket-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
    }

    .ticket-total {
      border-top: 1px dashed var(--border-subtle);
      padding-top: 10px;
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
      font-weight: 800;
      font-size: 15px;
      color: var(--accent);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 860px) {
      .checkout-grid {
        grid-template-columns: 1fr;
      }
      .summary-card {
        position: static;
      }
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="catalogo.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-cart-shopping"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <a href="catalogo.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Regresar al Catálogo</span>
    </a>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_alumnosIII.php">Tienda</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Carrito de Compras</span>
    </div>

    <div class="header-banner">
      <h1>Resumen de tu Carrito</h1>
      <p>Verifica tu equipamiento seleccionado antes de confirmar la compra oficial.</p>
    </div>

    <!-- Contenido cuando hay productos -->
    <div class="checkout-grid" id="checkoutGrid">
      <div class="cart-card">
        <div class="table-responsive">
          <table id="tablaCarrito">
            <thead>
              <tr>
                <th>Artículo</th>
                <th>Precio Unit.</th>
                <th>Cantidad</th>
                <th>Subtotal</th>
                <th></th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
      </div>

      <!-- Resumen Lateral -->
      <aside class="summary-card">
        <h3><i class="fas fa-receipt"></i> Resumen del Pedido</h3>
        <div class="summary-row">
          <span>Artículos totales</span>
          <strong id="summaryCount">0</strong>
        </div>
        <div class="summary-row">
          <span>Sede de entrega</span>
          <span>Team Dharius</span>
        </div>
        <div class="summary-row">
          <span>Método de pago</span>
          <span>Recepción / Caja</span>
        </div>
        <div class="summary-row total">
          <span>Total a pagar</span>
          <span class="price-tag" id="totalCarrito">$0.00</span>
        </div>

        <button class="btn-checkout" onclick="finalizarCompra()">
          <i class="fas fa-circle-check"></i>
          <span>Confirmar Compra</span>
        </button>
        <a href="catalogo.php" class="btn-continue">
          <i class="fas fa-plus"></i>
          <span>Agregar más artículos</span>
        </a>
      </aside>
    </div>

    <!-- Contenido cuando el carrito está vacío -->
    <div class="cart-card empty-cart" id="emptyCartView">
      <i class="fas fa-cart-arrow-down"></i>
      <h3>Tu carrito está vacío</h3>
      <p>Aún no has agregado indumentaria ni artículos técnicos a tu orden.</p>
      <a href="catalogo.php" class="btn-checkout" style="display: inline-flex; width: auto; padding: 12px 24px; text-decoration: none;">
        <i class="fas fa-store"></i>
        <span>Ir a la Tienda</span>
      </a>
    </div>
  </main>

  <!-- Modal de Ticket y Confirmación -->
  <div id="ticketModal" class="modal" onclick="cerrarModalClick(event)">
    <div class="modal-content">
      <div class="ticket-badge">
        <i class="fas fa-check"></i>
      </div>
      <h2>¡Pedido Registrado!</h2>
      <p class="subtitle">Presenta este comprobante en recepción de Team Dharius para recoger tu pedido.</p>

      <div class="ticket-box" id="ticketContenido"></div>

      <button class="btn-checkout" style="width: 100%; margin-top: 0;" onclick="cerrarModal()">
        <span>Continuar al Panel</span>
        <i class="fas fa-arrow-right"></i>
      </button>
    </div>
  </div>

  <footer class="app-footer">
    SVG-SPORTS &bull; Checkout seguro &bull; Team Dharius.
  </footer>

  <script>
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

    function renderCarrito() {
      const tabla = document.querySelector('#tablaCarrito tbody');
      const totalCarrito = document.getElementById('totalCarrito');
      const summaryCount = document.getElementById('summaryCount');
      const checkoutGrid = document.getElementById('checkoutGrid');
      const emptyCartView = document.getElementById('emptyCartView');

      if (carrito.length === 0) {
        checkoutGrid.style.display = "none";
        emptyCartView.style.display = "block";
        return;
      }

      checkoutGrid.style.display = "grid";
      emptyCartView.style.display = "none";
      tabla.innerHTML = "";

      let total = 0;
      let totalArticulos = 0;

      carrito.forEach((producto, index) => {
        const subtotal = producto.precio * producto.cantidad;
        total += subtotal;
        totalArticulos += producto.cantidad;

        tabla.innerHTML += `
          <tr>
            <td>
              <div class="product-cell">
                <div class="product-icon"><i class="fas fa-box"></i></div>
                <span>${producto.nombre}</span>
              </div>
            </td>
            <td>$${producto.precio.toFixed(2)}</td>
            <td>
              <div class="qty-controls">
                <button type="button" class="qty-btn" onclick="ajustarCantidad(${index}, -1)">
                  <i class="fas fa-minus"></i>
                </button>
                <span class="qty-num">${producto.cantidad}</span>
                <button type="button" class="qty-btn" onclick="ajustarCantidad(${index}, 1)">
                  <i class="fas fa-plus"></i>
                </button>
              </div>
            </td>
            <td style="font-weight: 700; color: var(--accent);">$${subtotal.toFixed(2)}</td>
            <td>
              <button type="button" class="btn-delete" title="Quitar producto" onclick="eliminarProducto(${index})">
                <i class="fas fa-trash-can"></i>
              </button>
            </td>
          </tr>`;
      });

      totalCarrito.textContent = `$${total.toFixed(2)}`;
      summaryCount.textContent = totalArticulos;
    }

    function ajustarCantidad(index, cambio) {
      carrito[index].cantidad += cambio;
      if (carrito[index].cantidad <= 0) {
        carrito.splice(index, 1);
      }
      localStorage.setItem('carrito', JSON.stringify(carrito));
      renderCarrito();
    }

    function eliminarProducto(index) {
      carrito.splice(index, 1);
      localStorage.setItem('carrito', JSON.stringify(carrito));
      renderCarrito();
    }

    function finalizarCompra() {
      if (carrito.length === 0) {
        alert("Tu carrito está vacío");
        return;
      }

      mostrarTicketYDescargarPDF();

      fetch("registrar_venta.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(carrito)
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          localStorage.removeItem('carrito');
          carrito = [];
        } else {
          alert("Error: " + data.message);
        }
      })
      .catch(() => {
        alert("Error de comunicación con el servidor");
      });
    }

    function mostrarTicketYDescargarPDF() {
      const modal = document.getElementById('ticketModal');
      const ticketContenido = document.getElementById('ticketContenido');
      modal.style.display = "flex";

      let total = 0;
      let ticketHtml = `
        <div style="font-size:11.5px; color:var(--text-muted); margin-bottom:12px; border-bottom:1px solid var(--border-subtle); padding-bottom:8px;">
          <span>SVG-SPORTS / Team Dharius</span><br>
          <span>Fecha: ${new Date().toLocaleString()}</span>
        </div>`;

      carrito.forEach(producto => {
        const subtotal = producto.precio * producto.cantidad;
        total += subtotal;
        ticketHtml += `
          <div class="ticket-item">
            <span>${producto.cantidad}x ${producto.nombre}</span>
            <strong>$${subtotal.toFixed(2)}</strong>
          </div>`;
      });

      ticketHtml += `
        <div class="ticket-total">
          <span>Total Pagado:</span>
          <span>$${total.toFixed(2)}</span>
        </div>`;

      ticketContenido.innerHTML = ticketHtml;

      // Generar y descargar PDF
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text("SVG-SPORTS - Ticket de Compra (Team Dharius)", 20, 20);
      doc.setFontSize(11);
      doc.text(`Fecha: ${new Date().toLocaleString()}`, 20, 28);
      doc.text("------------------------------------------------------------", 20, 34);

      let y = 42;
      carrito.forEach(producto => {
        const subtotal = producto.precio * producto.cantidad;
        doc.text(`${producto.nombre} - $${producto.precio.toFixed(2)} x ${producto.cantidad} = $${subtotal.toFixed(2)}`, 20, y);
        y += 8;
      });

      doc.text("------------------------------------------------------------", 20, y + 4);
      doc.setFontSize(13);
      doc.text(`Total Liquidado: $${total.toFixed(2)}`, 20, y + 14);

      doc.save(`Ticket_SVG_SPORTS_${Date.now()}.pdf`);
    }

    function cerrarModal() {
      document.getElementById('ticketModal').style.display = "none";
      window.location.href = "../bienvenidaAlumnos.php"; 
    }

    function cerrarModalClick(e) {
      const modalContent = document.querySelector('.modal-content');
      if (!modalContent.contains(e.target)) {
        cerrarModal();
      }
    }

    renderCarrito();
  </script>
</body>
</html>