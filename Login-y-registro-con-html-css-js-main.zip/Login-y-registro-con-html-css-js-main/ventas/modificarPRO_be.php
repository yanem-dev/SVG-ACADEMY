<?php
include("../php/conexion_be.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $id_producto = $_POST['id_producto'];

    $updates = [];

    if (!empty($_POST['nombreP'])) {
        $nombreP = mysqli_real_escape_string($conexion, $_POST['nombreP']);
        $updates[] = "nombreP = '$nombreP'";
    }

    if (!empty($_POST['descripcionP'])) {
        $descripcionP = mysqli_real_escape_string($conexion, $_POST['descripcionP']);
        $updates[] = "descripcionP = '$descripcionP'";
    }

    if (!empty($_POST['categoriaP'])) {
        $categoriaP = mysqli_real_escape_string($conexion, $_POST['categoriaP']);
        $updates[] = "categoriaP = '$categoriaP'";
    }

    if (!empty($_POST['precioP'])) {
        $precioP = (float)$_POST['precioP'];
        $updates[] = "precioP = '$precioP'";
    }

    if (!empty($_POST['stockP'])) {
        $stockP = (int)$_POST['stockP'];
        $updates[] = "stockP = '$stockP'";
    }

    if (isset($_FILES['imagenP']) && $_FILES['imagenP']['error'] == 0) {
        $nombre_imagen = $_FILES['imagenP']['name'];
        $ruta_temporal = $_FILES['imagenP']['tmp_name'];
        $ruta_destino = "uploads/" . $nombre_imagen; 

        
        if (move_uploaded_file($ruta_temporal, $ruta_destino)) {
            $updates[] = "imagenP = '$nombre_imagen'";
        } else {
            echo "Error al subir la imagen.";
            exit();
        }
    }

    if (!empty($updates)) {
        $updates_sql = implode(", ", $updates);

        $sql = "UPDATE productos SET $updates_sql WHERE id_producto = '$id_producto'";

        if (mysqli_query($conexion, $sql)) {
            echo "<script>alert('Producto actualizado correctamente'); window.location.href = '../ventas.php';</script>";
        } else {
            echo "Error al actualizar: " . mysqli_error($conexion);
        }
    } else {
        echo "<script>alert('No se recibieron datos nuevos para actualizar.'); window.history.back();</script>";
    }

} else {
    echo "Acceso no permitido.";
}

mysqli_close($conexion);
?>
