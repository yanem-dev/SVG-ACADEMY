<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Catálogo de Productos</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --accent: #38bdf8;
      --gold: #f59e0b;
      --gold-hover: #d97706;
      --gold-glow: rgba(245, 158, 11, 0.25);
      --emerald: #10b981;
      --danger: #ef4444;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #f59e0b;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(245, 158, 11, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--gold-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--gold);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(245, 158, 11, 0.15);
      color: var(--gold);
      border-color: var(--gold);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1360px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--gold);
    }

    .top-actions-bar {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      flex-wrap: wrap;
      gap: 20px;
      margin-bottom: 28px;
    }

    .top-actions-bar h1 {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .top-actions-bar p {
      font-size: 14px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    .actions-group {
      display: flex;
      gap: 12px;
      align-items: center;
      flex-wrap: wrap;
    }

    .search-wrapper {
      position: relative;
    }

    .search-wrapper i {
      position: absolute;
      left: 14px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748b;
      font-size: 13px;
    }

    .search-input {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 10px 14px 10px 38px;
      border-radius: 12px;
      font-size: 13.5px;
      outline: none;
      width: 260px;
      transition: all 0.2s ease;
    }

    .search-input:focus {
      border-color: var(--gold);
      box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.15);
    }

    .btn-pdf {
      background: var(--gold);
      color: #1a1200;
      border: none;
      padding: 10px 20px;
      border-radius: 12px;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--gold-glow);
      transition: all 0.2s ease;
    }

    .btn-pdf:hover {
      background: var(--gold-hover);
      color: #ffffff;
      transform: translateY(-2px);
    }

    /* Tabla Estilo Consola */
    .table-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }

    .table-responsive {
      overflow-x: auto;
      width: 100%;
      max-height: 680px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }

    thead {
      background: var(--card-inner);
      position: sticky;
      top: 0;
      z-index: 10;
      box-shadow: 0 1px 0 var(--border-subtle);
    }

    th {
      padding: 16px 18px;
      font-size: 11.5px;
      font-weight: 800;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--gold);
      white-space: nowrap;
    }

    td {
      padding: 14px 18px;
      font-size: 13.5px;
      color: var(--text-main);
      border-bottom: 1px solid var(--border-subtle);
      vertical-align: middle;
    }

    tbody tr {
      transition: background-color 0.2s ease;
    }

    tbody tr:hover {
      background-color: rgba(245, 158, 11, 0.04);
    }

    tbody tr:last-child td {
      border-bottom: none;
    }

    .badge-id {
      background: var(--card-inner);
      border: 1px solid var(--border-subtle);
      padding: 4px 8px;
      border-radius: 6px;
      font-weight: 700;
      font-size: 12px;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .product-title {
      font-weight: 700;
      color: var(--text-main);
    }

    .desc-cell {
      max-width: 280px;
      color: var(--text-muted);
      font-size: 13px;
      line-height: 1.45;
    }

    .badge-category {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(99, 102, 241, 0.12);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.25);
      padding: 3px 10px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 700;
      white-space: nowrap;
    }

    .price-tag {
      font-weight: 800;
      color: var(--emerald);
      white-space: nowrap;
    }

    .stock-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 3px 10px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 700;
      white-space: nowrap;
    }

    .stock-in {
      background: rgba(16, 185, 129, 0.12);
      color: var(--emerald);
      border: 1px solid rgba(16, 185, 129, 0.3);
    }

    .stock-low {
      background: rgba(239, 68, 68, 0.12);
      color: #f87171;
      border: 1px solid rgba(239, 68, 68, 0.3);
    }

    .thumb-wrapper img {
      width: 52px;
      height: 52px;
      object-fit: cover;
      border-radius: 10px;
      border: 1px solid var(--border-subtle);
      background: var(--card-inner);
      display: block;
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .top-actions-bar {
        flex-direction: column;
        align-items: flex-start;
      }
      .actions-group {
        width: 100%;
      }
      .search-input {
        width: 100%;
      }
      .btn-pdf {
        width: 100%;
        justify-content: center;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../ventas.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-boxes-stacked"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <button onclick="window.history.back();" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver</span>
    </button>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel Administrador</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_adminIII.php">Ventas y Membresías</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../ventas.php">Inventario</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Catálogo de Productos</span>
    </div>

    <div class="top-actions-bar">
      <div>
        <h1>Inventario Oficial de la Tienda</h1>
        <p>Catálogo consolidado de kimonos, protecciones, cinturones y accesorios de Team Dharius.</p>
      </div>

      <div class="actions-group">
        <div class="search-wrapper">
          <i class="fas fa-magnifying-glass"></i>
          <input type="text" id="filtroTabla" class="search-input" placeholder="Filtrar por artículo o categoría..." onkeyup="filtrarProductos()">
        </div>
        <button onclick="exportarPDF()" class="btn-pdf">
          <i class="fas fa-file-pdf"></i>
          <span>Crear reporte de inventario</span>
        </button>
      </div>
    </div>

    <div class="table-card">
      <div class="table-responsive">
        <table id="tablaProductos">
          <thead>
            <tr>
              <th>ID Producto</th>
              <th>Nombre</th>
              <th>Descripción</th>
              <th>Categoría</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Imagen</th>
            </tr>
          </thead>
          <tbody>
            <?php
              include("../php/conexion_be.php");

              $sql = "SELECT id_producto, nombreP, descripcionP, categoriaP, precioP, stockP, imagenP FROM productos";
              $resultado = mysqli_query($conexion, $sql);

              while ($fila = mysqli_fetch_assoc($resultado)) {
                $stockVal = intval($fila['stockP']);
                $stockClass = ($stockVal <= 3) ? 'stock-low' : 'stock-in';
            ?>
              <tr>
                <td><span class="badge-id">#<?= htmlspecialchars($fila['id_producto']) ?></span></td>
                <td class="product-title"><?= htmlspecialchars($fila['nombreP']) ?></td>
                <td class="desc-cell"><?= htmlspecialchars($fila['descripcionP']) ?></td>
                <td>
                  <span class="badge-category">
                    <i class="fas fa-tag"></i> <?= htmlspecialchars($fila['categoriaP']) ?>
                  </span>
                </td>
                <td class="price-tag">$<?= number_format(floatval($fila['precioP']), 2) ?></td>
                <td>
                  <span class="stock-badge <?= $stockClass ?>">
                    <i class="fas fa-boxes-packing"></i> <?= $stockVal ?> unids.
                  </span>
                </td>
                <td class="thumb-wrapper">
                  <img src="uploads/<?= htmlspecialchars($fila['imagenP']) ?>" alt="<?= htmlspecialchars($fila['nombreP']) ?>" onerror="this.src='https://via.placeholder.com/52?text=Item';">
                </td>
              </tr>
            <?php
              }
              mysqli_close($conexion);
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de tienda y facturación &bull; Team Dharius.
  </footer>

  <!-- jsPDF y autoTable -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>

  <script>
    function filtrarProductos() {
      const input = document.getElementById("filtroTabla");
      const filtro = input.value.toUpperCase();
      const tabla = document.getElementById("tablaProductos");
      const tr = tabla.getElementsByTagName("tr");

      for (let i = 1; i < tr.length; i++) {
        let textoFila = tr[i].textContent || tr[i].innerText;
        if (textoFila.toUpperCase().indexOf(filtro) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }

    async function exportarPDF() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF('l', 'pt', 'a4');

      doc.setFontSize(16);
      doc.setTextColor(40);
      doc.text("LISTA DE PRODUCTOS REGISTRADOS - TEAM DHARIUS", 40, 40);
      doc.setFontSize(11);
      doc.text("FECHA DE EMISIÓN: " + new Date().toLocaleDateString(), 40, 60);

      const rows = Array.from(document.querySelectorAll("#tablaProductos tbody tr"));
      const headers = ["ID", "Nombre", "Descripción", "Categoría", "Precio", "Stock"];
      const data = [];

      for (let row of rows) {
        const cells = row.querySelectorAll("td");
        const filaTexto = [
          cells[0].innerText.replace("#", ""),
          cells[1].innerText,
          cells[2].innerText,
          cells[3].innerText,
          cells[4].innerText,
          cells[5].innerText
        ];
        data.push(filaTexto);
      }

      doc.autoTable({
        head: [headers],
        body: data,
        startY: 80,
        theme: 'grid',
        styles: { fontSize: 8.5, cellPadding: 5 },
        headStyles: { fillColor: [245, 158, 11], textColor: [26, 18, 0] },
        margin: { top: 80, left: 40, right: 40 }
      });

      let y = doc.previousAutoTable.finalY + 30;
      doc.setFontSize(13);
      doc.setTextColor(40);
      doc.text("Catálogo Fotográfico de Productos:", 40, y);
      y += 15;

      for (let row of rows) {
        const nombre = row.cells[1].innerText;
        const imgElem = row.cells[6].querySelector("img");
        const imgSrc = imgElem ? imgElem.src : null;

        if (imgSrc) {
          try {
            const imgData = await toDataURL(imgSrc);
            doc.addImage(imgData, 'JPEG', 40, y, 45, 45);
            doc.setFontSize(10);
            doc.text(nombre + " (" + row.cells[4].innerText + ")", 95, y + 25);
            y += 55;

            if (y > 510) {
              doc.addPage();
              y = 40;
            }
          } catch (e) {
            console.warn("No se pudo adjuntar la imagen de:", nombre, e);
          }
        }
      }

      doc.save("PRODUCTOS_SVG_SPORTS.pdf");
    }

    function toDataURL(url) {
      return fetch(url)
        .then(response => response.blob())
        .then(blob => new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        }));
    }
  </script>
</body>
</html>