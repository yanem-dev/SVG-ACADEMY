<?php
include '../php/conexion_be.php';

$nombreP = $_POST['nombreP'];
$descripcionP = $_POST['descripcionP'];
$categoriaP = $_POST['categoriaP'];
$precioP = $_POST['precioP'];
$stockP = $_POST['stockP'];

$imagenNombre = $_FILES['imagenP']['name'];
$imagenTmp = $_FILES['imagenP']['tmp_name'];
$carpetaDestino = "uploads/" . basename($imagenNombre);

if (move_uploaded_file($imagenTmp, $carpetaDestino)) {
   
    $sql = "INSERT INTO productos (nombreP, descripcionP, categoriaP, precioP, stockP, imagenP)
            VALUES ('$nombreP', '$descripcionP', '$categoriaP', '$precioP', '$stockP', '$imagenNombre')";

    if (mysqli_query($conexion, $sql)) {
        echo "<script>alert('Producto registrado con éxito'); window.location.href='../ventas.php';</script>";
    } else {
        echo "Error al guardar en base de datos: " . mysqli_error($conexion);
    }
} else {
    echo "Error al subir la imagen.";
}

mysqli_close($conexion);
?>
