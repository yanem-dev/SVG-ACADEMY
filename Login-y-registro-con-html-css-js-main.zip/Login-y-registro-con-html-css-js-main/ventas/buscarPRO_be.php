<?php
include("../php/conexion_be.php");

if (isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];

    $sql = "SELECT id_producto, nombreP, descripcionP,categoriaP,precioP, stockP, imagenP 
            FROM productos 
            WHERE nombreP LIKE '%$nombre%'";

    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        echo '<table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Categoria</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Imagen</th>
                  </tr>
                </thead>
              <tbody>';

        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo "<tr>
                    <td>{$fila['id_producto']}</td>
                    <td>{$fila['nombreP']}</td>
                    <td>{$fila['descripcionP']}</td>
                     <td>{$fila['categoriaP']}</td>
                    <td>\${$fila['precioP']}</td>
                    <td>{$fila['stockP']}</td>
                    <td><img src='uploads/{$fila['imagenP']}' alt='Imagen del producto' class='product-image'></td>
                  </tr>";
        }

        echo '</tbody></table>';
    } else {
        echo "<p style='text-align:center; color: #e74c3c;'>No se encontraron productos.</p>";
    }

    mysqli_close($conexion);
}
?>
