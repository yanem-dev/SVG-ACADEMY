<?php
include("../php/conexion_be.php");

$sql = "SELECT * FROM productos";
$resultado = mysqli_query($conexion,$sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Tienda Oficial y Equipamiento</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.25);
      --emerald: #10b981;
      --emerald-glow: rgba(16, 185, 129, 0.25);
      --gold: #f59e0b;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(56, 189, 248, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Top Navigation Bar */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(56, 189, 248, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 14px;
    }

    .btn-cart-nav {
      background: rgba(16, 185, 129, 0.15);
      color: #34d399;
      border: 1px solid rgba(16, 185, 129, 0.3);
      padding: 8px 18px;
      border-radius: 12px;
      font-size: 13.5px;
      font-weight: 700;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      position: relative;
    }

    .btn-cart-nav:hover {
      background: var(--emerald);
      color: #062817;
      box-shadow: 0 0 16px var(--emerald-glow);
    }

    .cart-counter {
      background: #ef4444;
      color: white;
      font-size: 11px;
      font-weight: 800;
      padding: 2px 7px;
      border-radius: 9999px;
      min-width: 20px;
      text-align: center;
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 16px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-return:hover {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .header-banner {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 36px;
    }

    .header-banner h1 {
      font-size: 30px;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .header-banner p {
      font-size: 14px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    /* Vitrina de Productos (E-commerce Grid) */
    .products-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
      gap: 24px;
    }

    .product-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      transition: all 0.28s ease;
      position: relative;
    }

    .product-card:hover {
      transform: translateY(-4px);
      border-color: var(--border-focus);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.6);
    }

    .product-media {
      position: relative;
      height: 220px;
      background: #0f172a;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .product-media img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.3s ease;
    }

    .product-card:hover .product-media img {
      transform: scale(1.05);
    }

    .badge-official {
      position: absolute;
      top: 12px;
      right: 12px;
      background: rgba(15, 23, 42, 0.8);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: var(--accent);
      font-size: 10.5px;
      font-weight: 800;
      letter-spacing: 0.05em;
      padding: 4px 10px;
      border-radius: 9999px;
      text-transform: uppercase;
    }

    .product-body {
      padding: 22px 20px;
      display: flex;
      flex-direction: column;
      flex: 1;
      justify-content: space-between;
    }

    .product-title {
      font-size: 17px;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 6px;
    }

    .product-desc {
      font-size: 13px;
      color: var(--text-muted);
      line-height: 1.5;
      margin-bottom: 18px;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .product-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding-top: 16px;
      border-top: 1px solid var(--border-subtle);
    }

    .price-box {
      display: flex;
      flex-direction: column;
    }

    .price-label {
      font-size: 11px;
      font-weight: 600;
      color: var(--text-muted);
      text-transform: uppercase;
    }

    .price-amount {
      font-size: 20px;
      font-weight: 800;
      color: var(--accent);
    }

    .btn-add-cart {
      background: var(--primary);
      color: white;
      border: none;
      padding: 10px 16px;
      border-radius: 12px;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-add-cart:hover {
      background: var(--primary-hover);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(99, 102, 241, 0.4);
    }

    /* Toast Notification (Feedback moderno) */
    .toast-notification {
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: #10b981;
      color: #062817;
      font-weight: 700;
      font-size: 13.5px;
      padding: 14px 22px;
      border-radius: 14px;
      box-shadow: 0 10px 25px -5px rgba(16, 185, 129, 0.4);
      display: flex;
      align-items: center;
      gap: 10px;
      z-index: 1000;
      opacity: 0;
      transform: translateY(20px);
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      pointer-events: none;
    }

    .toast-notification.show {
      opacity: 1;
      transform: translateY(0);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .header-banner h1 {
        font-size: 24px;
      }
      .products-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../modulos_alumnosIII.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-bag-shopping"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <div class="header-actions">
      <a href="carrito.php" class="btn-cart-nav">
        <i class="fas fa-cart-shopping"></i>
        <span>Mi Carrito</span>
        <span class="cart-counter" id="cartCount">0</span>
      </a>

      <a href="../bienvenidaAlumnos.php" class="btn-return">
        <i class="fas fa-chevron-left"></i>
        <span>Salir</span>
      </a>
    </div>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_alumnosIII.php">Tienda y Membresías</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Catálogo</span>
    </div>

    <div class="header-banner">
      <div>
        <h1>Equipamiento e Indumentaria</h1>
        <p>Uniformes reglamentarios, protecciones y accesorios con garantía oficial Team Dharius.</p>
      </div>
    </div>

    <!-- Catálogo de Productos -->
    <div class="products-grid">
      <?php while ($row = mysqli_fetch_assoc($resultado)): ?>
        <div class="product-card">
          <div class="product-media">
            <span class="badge-official">Oficial</span>
            <img src="uploads/<?php echo htmlspecialchars($row['imagenP']); ?>" alt="<?php echo htmlspecialchars($row['nombreP']); ?>" onerror="this.src='https://placehold.co/400x300/1e293b/94a3b8?text=SVG-SPORTS';">
          </div>

          <div class="product-body">
            <div>
              <h3 class="product-title"><?php echo htmlspecialchars($row['nombreP']); ?></h3>
              <p class="product-desc"><?php echo htmlspecialchars($row['descripcionP']); ?></p>
            </div>

            <div class="product-footer">
              <div class="price-box">
                <span class="price-label">Precio</span>
                <span class="price-amount">$<?php echo number_format($row['precioP'], 2); ?></span>
              </div>

              <button class="btn-add-cart" onclick="agregarAlCarrito(<?php echo $row['id_producto']; ?>, '<?php echo addslashes($row['nombreP']); ?>', <?php echo$row['precioP']; ?>)">
                <i class="fas fa-plus"></i>
                <span>Añadir</span>
              </button>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </main>

  <!-- Toast Notification Flotante -->
  <div id="toast" class="toast-notification">
    <i class="fas fa-circle-check"></i>
    <span id="toastMsg">Producto agregado al carrito</span>
  </div>

  <footer class="app-footer">
    SVG-SPORTS &bull; Tienda oficial de la academia &bull; Team Dharius.
  </footer>

  <script>
    function actualizarContador() {
      let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
      let totalItems = carrito.reduce((acc, item) => acc + (item.cantidad || 1), 0);
      const counter = document.getElementById('cartCount');
      if (counter) {
        counter.textContent = totalItems;
      }
    }

    function mostrarToast(mensaje) {
      const toast = document.getElementById('toast');
      const toastMsg = document.getElementById('toastMsg');
      toastMsg.textContent = mensaje;
      toast.classList.add('show');
      setTimeout(() => {
        toast.classList.remove('show');
      }, 2500);
    }

    function agregarAlCarrito(id, nombre, precio) {
      let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
      let producto = carrito.find(p => p.id === id);
      if (producto) {
        producto.cantidad++;
      } else {
        carrito.push({ id, nombre, precio, cantidad: 1 });
      }
      localStorage.setItem('carrito', JSON.stringify(carrito));
      actualizarContador();
      mostrarToast(`"${nombre}" añadido al carrito`);
    }

    document.addEventListener("DOMContentLoaded", actualizarContador);
  </script>
</body>
</html>
<?php mysqli_close($conexion); ?>