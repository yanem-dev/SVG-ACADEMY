<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Registrar Producto</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --accent: #38bdf8;
      --gold: #f59e0b;
      --gold-hover: #d97706;
      --gold-glow: rgba(245, 158, 11, 0.25);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #f59e0b;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(245, 158, 11, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex; flex-direction: column;
    }

    .app-header {
      background: rgba(17, 24, 39, 0.85); backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle); padding: 16px 32px;
      display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100;
    }
    .brand-logo { display: flex; align-items: center; gap: 12px; text-decoration: none; }
    .brand-icon {
      width: 40px; height: 40px; background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--gold); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 12px;
      display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 0 15px var(--gold-glow);
    }
    .brand-title { font-size: 20px; font-weight: 800; color: var(--text-main); }
    .brand-title .highlight { color: var(--gold); }

    .btn-return {
      background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 8px 18px; border-radius: 10px; font-size: 13.5px; font-weight: 600;
      text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease;
    }
    .btn-return:hover { background: rgba(245, 158, 11, 0.15); color: var(--gold); border-color: var(--gold); }

    .dashboard-container { width: 100%; max-width: 680px; margin: 0 auto; padding: 40px 20px; flex: 1; }
    .page-indicator { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-muted); margin-bottom: 16px; }
    .page-indicator a { color: var(--text-muted); text-decoration: none; }
    .page-indicator a:hover { color: var(--gold); }

    .form-card {
      background: var(--card-bg); border: 1px solid var(--border-subtle);
      border-radius: 24px; padding: 38px 34px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    }

    .form-header { margin-bottom: 26px; padding-bottom: 18px; border-bottom: 1px solid var(--border-subtle); text-align: center; }
    .badge-header {
      display: inline-flex; align-items: center; gap: 6px; background: rgba(245, 158, 11, 0.12);
      color: var(--gold); border: 1px solid rgba(245, 158, 11, 0.3); padding: 4px 12px;
      border-radius: 9999px; font-size: 11px; font-weight: 800; text-transform: uppercase; margin-bottom: 10px;
    }
    .form-header h2 { font-size: 24px; font-weight: 800; letter-spacing: -0.02em; }
    .form-header p { font-size: 13.5px; color: var(--text-muted); margin-top: 4px; }

    .fields-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 18px; }
    .form-group label { font-size: 13px; font-weight: 600; color: var(--text-muted); display: flex; align-items: center; gap: 6px; }

    .input-wrapper { position: relative; }
    .input-wrapper i {
      position: absolute; left: 16px; top: 50%; transform: translateY(-50%);
      color: #64748b; font-size: 14px; pointer-events: none;
    }
    .input-wrapper input, .input-wrapper select, textarea {
      width: 100%; background: var(--input-bg); border: 1px solid var(--border-subtle);
      color: var(--text-main); padding: 12px 16px 12px 44px; border-radius: 12px;
      font-size: 14px; outline: none; transition: all 0.2s ease;
    }
    textarea { padding-left: 16px; resize: vertical; min-height: 90px; }
    .input-wrapper select { appearance: none; cursor: pointer; }
    .input-wrapper input:focus, .input-wrapper select:focus, textarea:focus {
      border-color: var(--border-focus); box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.15);
    }

    /* Input de archivo estilizado */
    .file-upload-box {
      border: 1.5px dashed var(--border-subtle); border-radius: 14px;
      padding: 20px; text-align: center; background: var(--card-inner); cursor: pointer; transition: all 0.2s ease;
    }
    .file-upload-box:hover { border-color: var(--gold); }
    .file-upload-box input[type="file"] { display: none; }
    .file-upload-label { font-size: 13px; color: var(--text-muted); cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 6px; }
    .file-upload-label i { font-size: 24px; color: var(--gold); }

    .btn-actions { display: flex; gap: 12px; margin-top: 28px; padding-top: 22px; border-top: 1px solid var(--border-subtle); }
    .btn-submit {
      flex: 2; background: var(--gold); color: #1a1200; border: none; padding: 14px;
      border-radius: 12px; font-size: 14.5px; font-weight: 800; cursor: pointer;
      display: inline-flex; align-items: center; justify-content: center; gap: 8px;
      box-shadow: 0 4px 14px var(--gold-glow); transition: all 0.2s ease;
    }
    .btn-submit:hover { background: var(--gold-hover); color: #ffffff; transform: translateY(-1px); }
    .btn-cancel {
      flex: 1; background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 14px; border-radius: 12px; font-size: 14px; font-weight: 600; text-decoration: none;
      display: inline-flex; align-items: center; justify-content: center; transition: all 0.2s ease;
    }
    .btn-cancel:hover { color: var(--text-main); border-color: var(--text-muted); }

    .app-footer { border-top: 1px solid var(--border-subtle); padding: 24px; text-align: center; font-size: 12.5px; color: var(--text-muted); background: var(--bg-dark); }
    @media (max-width: 640px) { .fields-grid { grid-template-columns: 1fr; } .btn-actions { flex-direction: column; } }
  </style>
</head>
<body>

  <header class="app-header">
    <a href="../ventas.php" class="brand-logo">
      <div class="brand-icon"><i class="fas fa-boxes-stacked"></i></div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>
    <a href="../ventas.php" class="btn-return">
      <i class="fas fa-chevron-left"></i><span>Volver</span>
    </a>
  </header>

  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_adminIII.php">Ventas y Membresías</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../ventas.php">Inventario</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Registrar</span>
    </div>

    <div class="form-card">
      <div class="form-header">
        <span class="badge-header"><i class="fas fa-tag"></i> Catálogo Oficial</span>
        <h2>Registrar Nuevo Producto</h2>
        <p>Añade un artículo al inventario de la tienda oficial de Team Dharius.</p>
      </div>

      <form action="registrarPRO_be.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
          <label for="nombreP"><i class="fas fa-box"></i> Nombre del Producto</label>
          <div class="input-wrapper">
            <i class="fas fa-tag"></i>
            <input type="text" id="nombreP" name="nombreP" placeholder="Ej. Kimono Oficial Team Dharius" required>
          </div>
        </div>

        <div class="form-group">
          <label for="categoriaP"><i class="fas fa-layer-group"></i> Categoría</label>
          <div class="input-wrapper">
            <i class="fas fa-list"></i>
            <select name="categoriaP" id="categoriaP" required>
              <option value="" disabled selected>-- Selecciona una categoría --</option>
              <option value="Kimonos">Kimonos</option>
              <option value="Cintas">Cintas</option>
              <option value="Protecciones">Protecciones</option>
              <option value="Accesorios">Accesorios</option>
            </select>
          </div>
        </div>

        <div class="fields-grid">
          <div class="form-group" style="margin-bottom: 0;">
            <label for="precioP"><i class="fas fa-dollar-sign"></i> Precio ($)</label>
            <div class="input-wrapper">
              <i class="fas fa-coins"></i>
              <input type="number" id="precioP" name="precioP" step="0.01" placeholder="Ej. 850.00" required>
            </div>
          </div>

          <div class="form-group" style="margin-bottom: 0;">
            <label for="stockP"><i class="fas fa-warehouse"></i> Cantidad en Stock</label>
            <div class="input-wrapper">
              <i class="fas fa-boxes-packing"></i>
              <input type="number" id="stockP" name="stockP" placeholder="Ej. 15" required>
            </div>
          </div>
        </div>

        <div class="form-group">
          <label for="descripcionP"><i class="fas fa-align-left"></i> Descripción del Producto</label>
          <textarea id="descripcionP" name="descripcionP" rows="3" placeholder="Detalles de talla, material, especificaciones técnicas..." required></textarea>
        </div>

        <div class="form-group">
          <label><i class="fas fa-image"></i> Fotografía del Artículo</label>
          <div class="file-upload-box" onclick="document.getElementById('imagenP').click();">
            <input type="file" id="imagenP" name="imagenP" accept="image/*" required onchange="actualizarNombreArchivo(this)">
            <label class="file-upload-label">
              <i class="fas fa-cloud-arrow-up"></i>
              <span id="labelArchivo">Haz clic para subir imagen (PNG, JPG o WEBP)</span>
            </label>
          </div>
        </div>

        <div class="btn-actions">
          <button type="submit" class="btn-submit">
            <i class="fas fa-floppy-disk"></i><span>Guardar Producto</span>
          </button>
          <a href="../ventas.php" class="btn-cancel">
            Cancelar
          </a>
        </div>
      </form>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de tienda y facturación &bull; Team Dharius.
  </footer>

  <script>
    function actualizarNombreArchivo(input) {
      if (input.files && input.files[0]) {
        document.getElementById('labelArchivo').textContent = input.files[0].name;
      }
    }
  </script>
</body>
</html>