<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Portal Deportivo | Acceso</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #334155;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 24px;
      color: var(--text-main);
    }

    .app-card {
      background: var(--card-bg);
      width: 100%;
      max-width: 460px;
      border-radius: 24px;
      padding: 42px 32px;
      border: 1px solid var(--border-subtle);
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
      text-align: center;
      position: relative;
    }

    .brand-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(99, 102, 241, 0.12);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.2);
      padding: 6px 14px;
      border-radius: 9999px;
      font-size: 12.5px;
      font-weight: 600;
      letter-spacing: 0.03em;
      margin-bottom: 22px;
    }

    .header-text h1 {
      font-size: 26px;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 8px;
      letter-spacing: -0.02em;
    }

    .header-text p {
      font-size: 14.5px;
      color: var(--text-muted);
      line-height: 1.5;
      margin-bottom: 30px;
    }

    .role-grid {
      display: flex;
      flex-direction: column;
      gap: 14px;
    }

    .role-grid form {
      width: 100%;
    }

    .role-card {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 18px 20px;
      background: var(--card-inner);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
      cursor: pointer;
      transition: all 0.25s ease;
      text-align: left;
    }

    .role-card:hover {
      border-color: var(--primary);
      transform: translateY(-2px);
      box-shadow: 0 8px 24px var(--primary-glow);
    }

    .role-info {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .icon-wrapper {
      width: 46px;
      height: 46px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      flex-shrink: 0;
      transition: all 0.2s ease;
    }

    /* Iconos diferenciados */
    .role-card.student .icon-wrapper {
      background: rgba(99, 102, 241, 0.15);
      color: #818cf8;
    }

    .role-card.admin .icon-wrapper {
      background: rgba(148, 163, 184, 0.1);
      color: #94a3b8;
    }

    .role-card:hover .icon-wrapper {
      background: var(--primary);
      color: #ffffff;
    }

    .role-text .role-title {
      font-size: 15.5px;
      font-weight: 700;
      color: var(--text-main);
      display: block;
      margin-bottom: 2px;
    }

    .role-text .role-desc {
      font-size: 12.5px;
      color: var(--text-muted);
      display: block;
    }

    .arrow-icon {
      color: #475569;
      font-size: 13px;
      transition: transform 0.2s ease, color 0.2s ease;
    }

    .role-card:hover .arrow-icon {
      transform: translateX(4px);
      color: var(--accent);
    }

    .footer-support {
      margin-top: 28px;
      padding-top: 20px;
      border-top: 1px solid var(--border-subtle);
      font-size: 12.5px;
      color: var(--text-muted);
    }

    .footer-support a {
      color: var(--accent);
      text-decoration: none;
      font-weight: 600;
    }

    .footer-support a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="app-card">
    <div class="brand-badge">
      <i class="fas fa-cube"></i> SVG-REDSPORT
    
    </div>

    <div class="header-text">
      <h1>Portal de Acceso</h1>
      <p>Elige tu perfil para ingresar a la consola de trabajo</p>
    </div>

    <div class="role-grid">
      <!-- Acceso Alumno -->
      <form action="alumno.php" method="GET">
        <button type="submit" class="role-card student">
          <div class="role-info">
            <div class="icon-wrapper">
              <i class="fas fa-graduation-cap"></i>
            </div>
            <div class="role-text">
              <span class="role-title">Ingreso de Atletas</span>
              <span class="role-desc">Mis datos.</span>
            </div>
          </div>
          <i class="fas fa-chevron-right arrow-icon"></i>
        </button>
      </form>

      <!-- Acceso Administrador -->
      <form action="inicio.php" method="GET">
        <button type="submit" class="role-card admin">
          <div class="role-info">
            <div class="icon-wrapper">
              <i class="fas fa-user-shield"></i>
            </div>
            <div class="role-text">
              <span class="role-title">Gestión Operadora / Admin</span>
              <span class="role-desc">Panel de control</span>
            </div>
          </div>
          <i class="fas fa-chevron-right arrow-icon"></i>
        </button>
      </form>
    </div>

    <div class="footer-support">
      ¿Problemas de acceso? <a href="#">Centro de ayuda</a>
    </div>
  </div>

</body>
</html>