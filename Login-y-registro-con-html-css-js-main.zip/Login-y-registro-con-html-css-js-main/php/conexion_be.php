<?php
$conexion = mysqli_connect("localhost","root","","login_java_mysql");

    

?>