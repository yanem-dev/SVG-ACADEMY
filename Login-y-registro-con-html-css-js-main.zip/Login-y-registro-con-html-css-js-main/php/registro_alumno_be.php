<?php
include 'conexion_be.php';

$id_estudiante = $_POST['id_estudiante'];
$nombre        = $_POST['nombre'];
$correo        = $_POST['correo'];
$usuario       = $_POST['usuario'];
$contrasena    = $_POST['contrasena'];

// Validación: verificar que correo y nombre existen en estudiantes
$verificar = mysqli_query($conexion, "SELECT * FROM estudiantes WHERE id = '$id_estudiante' AND correoA = '$correo' AND nombreA = '$nombre'");
if (mysqli_num_rows($verificar) == 0) {
    echo '
    <script>
        alert("Los datos seleccionados no coinciden con ningún estudiante registrado.");
        window.location = "../alumno.php";
    </script>';
    exit();
}
// Validar duplicados
$verificar_correo = mysqli_query($conexion, "SELECT * FROM login_alumnos WHERE correo = '$correo'");
if (mysqli_num_rows($verificar_correo) > 0) {
    echo '
    <script>
        alert("Este correo ya tiene una cuenta.");
        window.location = "../alumno.php";
    </script>';
    exit();
}

$verificar_usuario = mysqli_query($conexion, "SELECT * FROM login_alumnos WHERE usuario = '$usuario'");
if (mysqli_num_rows($verificar_usuario) > 0) {
    echo '
    <script>
        alert("Este usuario ya existe.");
        window.location = "../alumno.php";
    </script>';
    exit();
}

// Insertar en login_alumnos
$query = "INSERT INTO login_alumnos (id_estudiante, nombre, correo, usuario, contrasena)
          VALUES ('$id_estudiante', '$nombre', '$correo', '$usuario', '$contrasena')";

$ejecutar = mysqli_query($conexion, $query);

if ($ejecutar) {
    echo '
    <script>
        alert("Alumno registrado correctamente.");
        window.location = "../alumno.php";
    </script>';
} else {
    echo '
    <script>
        alert("Error al registrar al alumno.");
        window.location = "../alumno.php";
    </script>';
}

mysqli_close($conexion);
?>
