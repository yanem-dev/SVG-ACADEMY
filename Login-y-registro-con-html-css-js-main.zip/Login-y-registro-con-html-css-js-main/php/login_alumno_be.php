<?php
session_start();
include 'conexion_be.php';

$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];

$validar_login = mysqli_query($conexion, "SELECT * FROM login_alumnos WHERE correo='$correo' AND contrasena='$contrasena'");

if (mysqli_num_rows($validar_login) > 0) {
    $datos_usuario = mysqli_fetch_assoc($validar_login);
    
    // Guarda el id_estudiante en la sesión
    $_SESSION['id_estudiante'] = $datos_usuario['id_estudiante'];

    header("Location: ../bienvenidaAlumnos.php");
    exit;
} else {
    echo '
    <script>
        alert("USUARIO NO EXISTE, VERIFIQUE LOS DATOS.");
        window.location = "../alumno.php";
    </script>';
    exit;
}
?>
