<?php
include("php/conexion_be.php");
session_start();

if (!isset($_SESSION['id_estudiante'])) {
    http_response_code(401);
    echo "No has iniciado sesión.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Módulo de Alumnos</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --gold: #f59e0b;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Header Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-return:hover {
      background: rgba(99, 102, 241, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1140px;
      margin: 0 auto;
      padding: 44px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .header-banner h1 {
      font-size: 30px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .header-banner p {
      font-size: 14.5px;
      color: var(--text-muted);
      margin-top: 6px;
      margin-bottom: 36px;
    }

    /* Grid de Accesos */
    .cards-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 24px;
    }

    .card-item {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 32px 26px;
      text-decoration: none;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 230px;
      transition: all 0.25s ease;
      position: relative;
    }

    .card-item:hover {
      transform: translateY(-4px);
      border-color: var(--border-focus);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.6);
    }

    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 20px;
    }

    .card-icon {
      width: 52px;
      height: 52px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      transition: transform 0.2s ease;
    }

    .card-profile .card-icon {
      background: rgba(99, 102, 241, 0.15);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
    }

    .card-schedule .card-icon {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .card-tournaments .card-icon {
      background: rgba(245, 158, 11, 0.15);
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.3);
    }

    .card-item:hover .card-icon {
      transform: scale(1.08);
    }

    .status-tag {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.05em;
      padding: 4px 10px;
      border-radius: 6px;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
    }

    .card-content h3 {
      font-size: 18px;
      font-weight: 700;
      color: var(--text-main);
      margin-bottom: 8px;
    }

    .card-content p {
      font-size: 13.5px;
      color: var(--text-muted);
      line-height: 1.5;
    }

    .card-action {
      margin-top: 24px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      font-weight: 600;
      color: var(--text-muted);
      transition: all 0.2s ease;
    }

    .card-item:hover .card-action {
      color: var(--accent);
      gap: 12px;
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 30px 16px;
      }
      .header-banner h1 {
        font-size: 24px;
      }
      .cards-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="bienvenidaAlumnos.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-bolt"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <a href="bienvenidaAlumnos.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver al Panel</span>
    </a>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Módulo de Alumnos</span>
    </div>

    <div class="header-banner">
      <h1>Gestión Académica del Atleta</h1>
      <p>Consulta tu expediente personal, sesiones programadas y competiciones oficiales.</p>
    </div>

    <div class="cards-grid">
      <!-- 1. Información de Alumnos -->
      <a href="estudiantes/mostrar_un_estudiante.php" class="card-item card-profile">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-id-card-clip"></i>
          </div>
          <span class="status-tag">PERFIL</span>
        </div>
        <div class="card-content">
          <h3>Información del Alumno</h3>
          <p>Visualiza tus datos personales registrados, tutor asignado, nivel deportivo y estado de tu matrícula.</p>
        </div>
        <div class="card-action">
          <span>Ver expediente</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- 2. Horarios -->
      <a href="horario/mostrarhor.php" class="card-item card-schedule">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-calendar-days"></i>
          </div>
          <span class="status-tag">HORARIOS</span>
        </div>
        <div class="card-content">
          <h3>Horarios y Entrenamientos</h3>
          <p>Revisa la programación de tus sesiones semanales, turnos de tatami/pista e instructores a cargo.</p>
        </div>
        <div class="card-action">
          <span>Ver calendario</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- 3. Torneos -->
      <a href="torneos/mostrartor.php" class="card-item card-tournaments">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-trophy"></i>
          </div>
          <span class="status-tag">COMPETICIÓN</span>
        </div>
        <div class="card-content">
          <h3>Torneos y Eventos</h3>
          <p>Inscripciones activas a eventos oficiales de Team Dharius, fechas de pesaje, llaves y clasificaciones.</p>
        </div>
        <div class="card-action">
          <span>Ver torneos</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Sistema integral de gestión deportiva &bull; 
  </footer>

</body>
</html>