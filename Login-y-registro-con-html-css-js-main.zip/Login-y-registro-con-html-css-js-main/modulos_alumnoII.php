<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-REDSPORT | Salud y Rendimiento del Atleta</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --emerald: #10b981;
      --emerald-hover: #059669;
      --emerald-glow: rgba(16, 185, 129, 0.25);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #10b981;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(16, 185, 129, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--emerald);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--emerald-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--emerald);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(16, 185, 129, 0.15);
      color: var(--emerald);
      border-color: var(--emerald);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1080px;
      margin: 0 auto;
      padding: 44px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--emerald);
    }

    .header-banner h1 {
      font-size: 30px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .header-banner p {
      font-size: 14.5px;
      color: var(--text-muted);
      margin-top: 6px;
      margin-bottom: 36px;
    }

    /* Grid de Módulos (2 Columnas Equilibradas) */
    .modules-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
      gap: 26px;
    }

    .module-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 22px;
      padding: 34px 30px;
      text-decoration: none;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 260px;
      transition: all 0.28s ease;
      position: relative;
      overflow: hidden;
    }

    .module-card::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: transparent;
      transition: background 0.3s ease;
    }

    .module-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.7);
    }

    /* Variantes */
    .card-health:hover::before { background: var(--emerald); }
    .card-health:hover { border-color: var(--emerald); }

    .card-progress:hover::before { background: var(--accent); }
    .card-progress:hover { border-color: var(--accent); }

    .module-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 22px;
    }

    .module-icon {
      width: 56px;
      height: 56px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      transition: transform 0.25s ease;
    }

    .card-health .module-icon {
      background: rgba(16, 185, 129, 0.15);
      color: var(--emerald);
      border: 1px solid rgba(16, 185, 129, 0.3);
    }

    .card-progress .module-icon {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .module-card:hover .module-icon {
      transform: scale(1.08);
    }

    .tag-badge {
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 0.05em;
      padding: 4px 10px;
      border-radius: 6px;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
    }

    .card-health .tag-badge {
      color: #34d399;
      background: rgba(16, 185, 129, 0.1);
      border-color: rgba(16, 185, 129, 0.25);
    }

    .card-progress .tag-badge {
      color: #7dd3fc;
      background: rgba(56, 189, 248, 0.1);
      border-color: rgba(56, 189, 248, 0.25);
    }

    .module-info h3 {
      font-size: 20px;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 8px;
    }

    .module-info p {
      font-size: 13.5px;
      color: var(--text-muted);
      line-height: 1.55;
    }

    .module-action {
      margin-top: 26px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13.5px;
      font-weight: 700;
      color: var(--text-muted);
      transition: all 0.2s ease;
    }

    .module-card:hover .module-action {
      gap: 12px;
    }

    .card-health:hover .module-action { color: var(--emerald); }
    .card-progress:hover .module-action { color: var(--accent); }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 30px 16px;
      }
      .header-banner h1 {
        font-size: 24px;
      }
      .modules-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="bienvenidaAlumnos.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-heart-pulse"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-REDSPORT</span></span>
    </a>

    <!-- Retorno exclusivo al portal del alumno -->
    <a href="bienvenidaAlumnos.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver a Mi Panel</span>
    </a>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Salud y Progreso</span>
    </div>

    <div class="header-banner">
      <h1>Mi Condición Física y Progreso</h1>
      <p>Consulta tu estado de salud, evolución biométrica, cálculo de IMC y el registro oficial de tus grados marciales.</p>
    </div>

    <div class="modules-grid">
      <!-- 1. Ficha Médica Personal del Alumno -->
      <a href="salud/mostrar_un_sal.php" class="module-card card-health">
        <div class="module-top">
          <div class="module-icon">
            <i class="fas fa-stethoscope"></i>
          </div>
          <span class="tag-badge">MI FICHA MÉDICA</span>
        </div>
        <div class="module-info">
          <h3>Ficha Médica y Biometría</h3>
          <p>Consulta tus valoraciones antropométricas recientes, peso, estatura, cálculo automático de IMC y tipo de sangre.</p>
        </div>
        <div class="module-action">
          <span>Ver mi expediente de salud</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- 2. Historial de Grados Personal del Alumno -->
      <a href="progreso/mostrar_un_hp.php" class="module-card card-progress">
        <div class="module-top">
          <div class="module-icon">
            <i class="fas fa-chart-line"></i>
          </div>
          <span class="tag-badge">MIS GRADOS Y LOGROS</span>
        </div>
        <div class="module-info">
          <h3>Historial y Progreso</h3>
          <p>Revisa tu avance marcial, cinturones acreditados, exámenes aprobados y las competiciones oficiales disputadas.</p>
        </div>
        <div class="module-action">
          <span>Ver mi historial deportivo</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>
    </div>
  </main>

  <footer class="app-footer">
    SVG-REDSPORT &bull; Portal del Atleta &bull; Plataforma Deportiva Integral
  </footer>

</body>
</html>