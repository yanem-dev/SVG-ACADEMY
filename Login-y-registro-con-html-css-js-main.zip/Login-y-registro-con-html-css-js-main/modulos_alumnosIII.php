<?php
include("php/conexion_be.php");
session_start();

if (!isset($_SESSION['id_estudiante'])) {
    http_response_code(401);
    echo "No has iniciado sesión.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Tienda y Membresías</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.25);
      --gold: #f59e0b;
      --gold-glow: rgba(245, 158, 11, 0.25);
      --emerald: #10b981;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(56, 189, 248, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(245, 158, 11, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Top Navigation Bar */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(56, 189, 248, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-return:hover {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border-color: var(--accent);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 980px;
      margin: 0 auto;
      padding: 44px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .header-banner {
      margin-bottom: 36px;
    }

    .store-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(56, 189, 248, 0.12);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 12px;
    }

    .header-banner h1 {
      font-size: 30px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .header-banner p {
      font-size: 14.5px;
      color: var(--text-muted);
      margin-top: 6px;
    }

    /* Tarjetas Comerciales */
    .cards-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 24px;
      margin-bottom: 36px;
    }

    .store-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 34px 28px;
      text-decoration: none;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 250px;
      transition: all 0.28s ease;
      position: relative;
      overflow: hidden;
    }

    .store-card::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: transparent;
      transition: background 0.3s ease;
    }

    .card-products:hover::before {
      background: var(--accent);
    }

    .card-memberships:hover::before {
      background: var(--gold);
    }

    .store-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.6);
    }

    .card-products:hover {
      border-color: var(--accent);
    }

    .card-memberships:hover {
      border-color: var(--gold);
    }

    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 20px;
    }

    .card-icon {
      width: 54px;
      height: 54px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      transition: transform 0.25s ease;
    }

    .card-products .card-icon {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .card-memberships .card-icon {
      background: rgba(245, 158, 11, 0.15);
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.3);
    }

    .store-card:hover .card-icon {
      transform: scale(1.08);
    }

    .promo-tag {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.05em;
      padding: 4px 10px;
      border-radius: 6px;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
    }

    .card-products .promo-tag {
      color: var(--accent);
      background: rgba(56, 189, 248, 0.1);
      border-color: rgba(56, 189, 248, 0.25);
    }

    .card-memberships .promo-tag {
      color: var(--gold);
      background: rgba(245, 158, 11, 0.1);
      border-color: rgba(245, 158, 11, 0.25);
    }

    .card-content h3 {
      font-size: 20px;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 8px;
    }

    .card-content p {
      font-size: 13.5px;
      color: var(--text-muted);
      line-height: 1.5;
    }

    .card-action {
      margin-top: 24px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13.5px;
      font-weight: 700;
      transition: all 0.2s ease;
    }

    .card-products .card-action {
      color: var(--accent);
    }

    .card-memberships .card-action {
      color: var(--gold);
    }

    .store-card:hover .card-action {
      gap: 12px;
    }

    /* Trust Signals / Propuesta de Valor Comercial */
    .trust-bar {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      padding: 20px;
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
    }

    .trust-item {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .trust-item i {
      font-size: 20px;
      color: var(--emerald);
    }

    .trust-item h4 {
      font-size: 13px;
      font-weight: 700;
      color: var(--text-main);
    }

    .trust-item p {
      font-size: 11.5px;
      color: var(--text-muted);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 30px 16px;
      }
      .header-banner h1 {
        font-size: 24px;
      }
      .cards-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="bienvenidaAlumnos.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-bag-shopping"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-REDSPORT</span></span>
    </a>

    <a href="bienvenidaAlumnos.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver al Panel</span>
    </a>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Módulo de Ventas</span>
    </div>

    <div class="header-banner">
      <div class="store-badge">
        <i class="fas fa-store"></i> Tienda Oficial &bull; 
      </div>
      <h1>Equipamiento y Membresías</h1>
      <p>Adquiere la indumentaria oficial de combate, complementos y asegura tu continuidad en la academia.</p>
    </div>

    <!-- Accesos de Conversión -->
    <div class="cards-grid">
      <!-- 1. Venta de Productos -->
      <a href="ventas/catalogo.php" class="store-card card-products">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-shirt"></i>
          </div>
          <span class="promo-tag">EQUIPAMIENTO</span>
        </div>
        <div class="card-content">
          <h3>Catálogo de Productos</h3>
          <p>Uniformes oficiales y mas.</p>
        </div>
        <div class="card-action">
          <span>Ver catálogo y ordenar</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- 2. Venta de Membresías -->
      <a href="membresias/vender_membresia.php" class="store-card card-memberships">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-id-card"></i>
          </div>
          <span class="promo-tag">PLANES Y CUOTAS</span>
        </div>
        <div class="card-content">
          <h3>Membresías y Mensualidades</h3>
          <p>Renueva tu plan de entrenamiento, turnos ilimitados, pases trimestrales y promociones por temporada.</p>
        </div>
        <div class="card-action">
          <span>Adquirir o renovar plan</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>
    </div>

    <!-- Señales de Confianza (Paradigma de Ventas) -->
    <div class="trust-bar">
      <div class="trust-item">
        <i class="fas fa-circle-check"></i>
        <div>
          <h4>Artículos Certificados</h4>
          <p>Avalados para uso en torneos</p>
        </div>
      </div>
      <div class="trust-item">
        <i class="fas fa-cash-register"></i>
        <div>
          <h4>Registro Inmediato</h4>
          <p>Liquidación directa en recepción</p>
        </div>
      </div>
      <div class="trust-item">
        <i class="fas fa-handshake"></i>
        <div>
          <h4>Garantía</h4>
          <p>Control interno de inventario</p>
        </div>
      </div>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Tienda oficial y control comercial &bull; 
  </footer>

</body>
</html>