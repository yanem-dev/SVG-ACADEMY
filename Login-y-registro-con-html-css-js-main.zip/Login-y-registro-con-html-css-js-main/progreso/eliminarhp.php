<?php
include("../php/conexion_be.php");

$registro = null;
if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  $sql_detalle = "SELECT hp.id, e.nombreA, hp.cinturones, hp.examenes, hp.torneos
                  FROM historialprogreso hp
                  INNER JOIN estudiantes e ON hp.id_A = e.id
                  WHERE hp.id = $id";
  $result_detalle = mysqli_query($conexion, $sql_detalle);
  $registro = mysqli_fetch_assoc($result_detalle);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Eliminar Progreso Deportivo</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --accent: #38bdf8;
      --danger: #ef4444;
      --danger-hover: #dc2626;
      --danger-glow: rgba(239, 68, 68, 0.25);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #ef4444;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(239, 68, 68, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex; flex-direction: column;
    }

    .app-header {
      background: rgba(17, 24, 39, 0.85); backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle); padding: 16px 32px;
      display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100;
    }
    .brand-logo { display: flex; align-items: center; gap: 12px; text-decoration: none; }
    .brand-icon {
      width: 40px; height: 40px; background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 12px;
      display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 0 15px var(--danger-glow);
    }
    .brand-title { font-size: 20px; font-weight: 800; color: var(--text-main); }
    .brand-title .highlight { color: var(--accent); }

    .btn-return {
      background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 8px 18px; border-radius: 10px; font-size: 13.5px; font-weight: 600;
      text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease;
    }
    .btn-return:hover { background: rgba(99, 102, 241, 0.15); color: var(--accent); border-color: var(--accent); }

    .dashboard-container { width: 100%; max-width: 580px; margin: 0 auto; padding: 40px 20px; flex: 1; display: flex; flex-direction: column; justify-content: center; }
    .page-indicator { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-muted); margin-bottom: 16px; }
    .page-indicator a { color: var(--text-muted); text-decoration: none; }
    .page-indicator a:hover { color: var(--accent); }

    .danger-card {
      background: var(--card-bg); border: 1.5px solid rgba(239, 68, 68, 0.3);
      border-radius: 24px; padding: 36px 30px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    }

    .card-header { text-align: center; margin-bottom: 24px; }
    .danger-badge {
      display: inline-flex; align-items: center; gap: 6px; background: rgba(239, 68, 68, 0.12);
      color: #fca5a5; border: 1px solid rgba(239, 68, 68, 0.3); padding: 4px 12px;
      border-radius: 9999px; font-size: 11px; font-weight: 800; text-transform: uppercase; margin-bottom: 12px;
    }
    .card-header h2 { font-size: 24px; font-weight: 800; letter-spacing: -0.02em; }
    .card-header p { font-size: 13.5px; color: var(--text-muted); margin-top: 4px; }

    .form-group { margin-bottom: 20px; }
    .form-group label { display: block; font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 8px; }

    .input-wrapper { position: relative; }
    .input-wrapper i {
      position: absolute; left: 16px; top: 50%; transform: translateY(-50%);
      color: #64748b; font-size: 14px; pointer-events: none;
    }
    .input-wrapper select {
      width: 100%; background: var(--input-bg); border: 1px solid var(--border-subtle);
      color: var(--text-main); padding: 13px 16px 13px 44px; border-radius: 12px;
      font-size: 14px; outline: none; appearance: none; cursor: pointer; transition: all 0.2s ease;
    }
    .input-wrapper select:focus { border-color: var(--border-focus); box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.2); }

    .detalle-box {
      margin: 20px 0; background: var(--card-inner); padding: 20px;
      border-radius: 14px; border: 1px solid var(--border-subtle); display: flex; flex-direction: column; gap: 8px;
    }
    .detalle-row { display: flex; justify-content: space-between; font-size: 13.5px; }
    .detalle-label { color: var(--text-muted); }
    .detalle-value { font-weight: 700; color: var(--text-main); }

    .btn-actions { display: flex; flex-direction: column; gap: 12px; }
    .btn-delete {
      width: 100%; background: var(--danger); color: white; border: none; padding: 14px;
      border-radius: 12px; font-size: 14.5px; font-weight: 800; cursor: pointer;
      display: inline-flex; align-items: center; justify-content: center; gap: 8px;
      box-shadow: 0 4px 14px var(--danger-glow); transition: all 0.2s ease;
    }
    .btn-delete:hover { background: var(--danger-hover); transform: translateY(-1px); }
    .btn-cancel {
      width: 100%; background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 13px; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer;
    }
    .btn-cancel:hover { color: var(--text-main); }

    .app-footer { border-top: 1px solid var(--border-subtle); padding: 24px; text-align: center; font-size: 12.5px; color: var(--text-muted); background: var(--bg-dark); }
  </style>
</head>
<body>

  <header class="app-header">
    <a href="../progreso.php" class="brand-logo">
      <div class="brand-icon"><i class="fas fa-trash-can"></i></div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>
    <button type="button" onclick="window.location.href='../progreso.php';" class="btn-return">
      <i class="fas fa-chevron-left"></i><span>Volver</span>
    </button>
  </header>

  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_adminII.php">Salud y Rendimiento</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../progreso.php">Progreso</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Eliminar</span>
    </div>

    <div class="danger-card">
      <div class="card-header">
        <span class="danger-badge"><i class="fas fa-triangle-exclamation"></i> Zona Crítica</span>
        <h2>Eliminar Progreso</h2>
        <p>Selecciona un expediente para confirmar su remoción definitiva</p>
      </div>

      <form method="GET">
        <div class="form-group">
          <label for="id">Seleccionar Expediente Deportivo:</label>
          <div class="input-wrapper">
            <i class="fas fa-trophy"></i>
            <select name="id" id="id" onchange="this.form.submit()" required>
              <option value="">-- Elige un registro a eliminar --</option>
              <?php
                $sql = "SELECT hp.id, e.nombreA FROM historialprogreso hp
                        INNER JOIN estudiantes e ON hp.id_A = e.id";
                $resultado = mysqli_query($conexion, $sql);
                while ($fila = mysqli_fetch_assoc($resultado)) {
                  $selected = isset($_GET['id']) && $_GET['id'] == $fila['id'] ? 'selected' : '';
                  echo "<option value='" . $fila['id'] . "' $selected>ID #" . $fila['id'] . " — " . htmlspecialchars($fila['nombreA']) . "</option>";
                }
              ?>
            </select>
          </div>
        </div>
      </form>

      <?php if ($registro): ?>
        <form action="eliminarHP_be.php" method="POST" style="margin-top: 10px;" onsubmit="return confirm('¿Confirmas la eliminación permanente del progreso deportivo de este estudiante?');">
          <input type="hidden" name="id" value="<?= $registro['id'] ?>">

          <div class="detalle-box">
            <div class="detalle-row">
              <span class="detalle-label">Estudiante:</span>
              <span class="detalle-value"><?= htmlspecialchars($registro['nombreA']) ?></span>
            </div>
            <div class="detalle-row">
              <span class="detalle-label">Cinturones obtenidos:</span>
              <span class="detalle-value"><?= htmlspecialchars($registro['cinturones']) ?></span>
            </div>
            <div class="detalle-row">
              <span class="detalle-label">Exámenes aprobados:</span>
              <span class="detalle-value"><?= htmlspecialchars($registro['examenes']) ?></span>
            </div>
            <div class="detalle-row">
              <span class="detalle-label">Torneos registrados:</span>
              <span class="detalle-value"><?= htmlspecialchars($registro['torneos']) ?></span>
            </div>
          </div>

          <div class="btn-actions">
            <button type="submit" class="btn-delete">
              <i class="fas fa-trash-can"></i><span>Confirmar Baja Definitiva</span>
            </button>
            <button type="button" onclick="window.location.href='../progreso.php';" class="btn-cancel">
              Cancelar Operación
            </button>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de salud y rendimiento atlético &bull; Team Dharius.
  </footer>
</body>
</html>