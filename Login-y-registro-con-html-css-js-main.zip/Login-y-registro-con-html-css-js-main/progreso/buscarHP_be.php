<?php
include("../php/conexion_be.php");

if (isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];

    $sql = "SELECT hp.id, e.nombreA, hp.cinturones, hp.examenes, hp.torneos
            FROM historialprogreso hp
            INNER JOIN estudiantes e ON hp.id_A = e.id
            WHERE e.nombreA LIKE '%$nombre%'";

    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        echo '<table>';
        echo '<thead><tr><th>ID</th><th>Nombre</th><th>Cinturones</th><th>Exámenes</th><th>Torneos</th></tr></thead>';
        echo '<tbody>';
        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo "<tr>";
            echo "<td>" . $fila['id'] . "</td>";
            echo "<td>" . $fila['nombreA'] . "</td>";
            echo "<td>" . $fila['cinturones'] . "</td>";
            echo "<td>" . $fila['examenes'] . "</td>";
            echo "<td>" . $fila['torneos'] . "</td>";
            echo "</tr>";
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo "<p class='no-results'>No se encontraron resultados.</p>";
    }

    mysqli_close($conexion);
}
?>

