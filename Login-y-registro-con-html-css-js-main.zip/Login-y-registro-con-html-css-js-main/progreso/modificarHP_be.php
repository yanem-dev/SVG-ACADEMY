<?php
include("../php/conexion_be.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_A = mysqli_real_escape_string($conexion, $_POST['id_A']);
    $cinturones = mysqli_real_escape_string($conexion, $_POST['cinturones']);
    $examenes = mysqli_real_escape_string($conexion, $_POST['examenes']);
    $torneos_array = $_POST['torneos'];

    
    $torneos = implode(', ', array_map(function($t) use ($conexion) {
        return mysqli_real_escape_string($conexion, $t);
    }, $torneos_array));


    $verificar = "SELECT id FROM historialprogreso WHERE id_A = '$id_A'";
    $resultado = mysqli_query($conexion, $verificar);

    if (mysqli_num_rows($resultado) > 0) {
 
        $sql = "UPDATE historialprogreso 
                SET cinturones = '$cinturones', 
                    examenes = '$examenes', 
                    torneos = '$torneos' 
                WHERE id_A = '$id_A'";

        if (mysqli_query($conexion, $sql)) {
            echo '
            <script>
                alert("Progreso modificado correctamente.");
                window.location = "../progreso.php";
            </script>
            ';
        } else {
            echo '
            <script>
                alert("Error al modificar el progreso: ' . mysqli_error($conexion) . '");
                window.location = "modificarhp.php";
            </script>
            ';
        }

    } else {
        echo '
        <script>
            alert("No existe un progreso registrado para este alumno.");
            window.location = "modificarhp.php";
        </script>
        ';
    }

    mysqli_close($conexion);
}
?>
