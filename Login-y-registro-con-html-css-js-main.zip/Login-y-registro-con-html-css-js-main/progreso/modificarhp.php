<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Modificar Progreso Deportivo</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #6366f1;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex; flex-direction: column;
    }

    .app-header {
      background: rgba(17, 24, 39, 0.85); backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle); padding: 16px 32px;
      display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100;
    }
    .brand-logo { display: flex; align-items: center; gap: 12px; text-decoration: none; }
    .brand-icon {
      width: 40px; height: 40px; background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(56, 189, 248, 0.2));
      color: var(--primary); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 12px;
      display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 0 15px var(--primary-glow);
    }
    .brand-title { font-size: 20px; font-weight: 800; color: var(--text-main); }
    .brand-title .highlight { color: var(--accent); }

    .btn-return {
      background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 8px 18px; border-radius: 10px; font-size: 13.5px; font-weight: 600;
      text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease;
    }
    .btn-return:hover { background: rgba(99, 102, 241, 0.15); color: var(--primary); border-color: var(--primary); }

    .dashboard-container { width: 100%; max-width: 680px; margin: 0 auto; padding: 40px 20px; flex: 1; }
    .page-indicator { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-muted); margin-bottom: 16px; }
    .page-indicator a { color: var(--text-muted); text-decoration: none; }
    .page-indicator a:hover { color: var(--accent); }

    .form-card {
      background: var(--card-bg); border: 1px solid var(--border-subtle);
      border-radius: 24px; padding: 38px 34px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    }

    .form-header { margin-bottom: 26px; padding-bottom: 18px; border-bottom: 1px solid var(--border-subtle); text-align: center; }
    .badge-header {
      display: inline-flex; align-items: center; gap: 6px; background: rgba(99, 102, 241, 0.12);
      color: #818cf8; border: 1px solid rgba(99, 102, 241, 0.3); padding: 4px 12px;
      border-radius: 9999px; font-size: 11px; font-weight: 800; text-transform: uppercase; margin-bottom: 10px;
    }
    .form-header h2 { font-size: 24px; font-weight: 800; letter-spacing: -0.02em; }
    .form-header p { font-size: 13.5px; color: var(--text-muted); margin-top: 4px; }

    .fields-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 18px; }
    .form-group label { font-size: 13px; font-weight: 600; color: var(--text-muted); display: flex; align-items: center; gap: 6px; }

    .input-wrapper { position: relative; }
    .input-wrapper i {
      position: absolute; left: 16px; top: 50%; transform: translateY(-50%);
      color: #64748b; font-size: 14px; pointer-events: none;
    }
    .input-wrapper input, .input-wrapper select {
      width: 100%; background: var(--input-bg); border: 1px solid var(--border-subtle);
      color: var(--text-main); padding: 12px 16px 12px 44px; border-radius: 12px;
      font-size: 14px; outline: none; transition: all 0.2s ease;
    }
    .input-wrapper select { appearance: none; cursor: pointer; }
    .input-wrapper input:focus, .input-wrapper select:focus {
      border-color: var(--border-focus); box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
    }

    select[multiple] {
      appearance: none;
      padding: 12px !important;
      background: var(--input-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 12px;
      color: var(--text-main);
      font-size: 13.5px;
      min-height: 130px;
    }
    select[multiple] option {
      padding: 8px 12px; border-radius: 6px; margin-bottom: 4px;
    }
    select[multiple] option:checked {
      background: rgba(99, 102, 241, 0.25) linear-gradient(0deg, rgba(99, 102, 241, 0.25) 0%, rgba(99, 102, 241, 0.25) 100%);
      color: #818cf8; font-weight: 700;
    }

    small.hint-text {
      font-size: 12px; color: var(--text-muted); display: flex; align-items: center; gap: 6px; margin-top: 4px;
    }

    .btn-actions { display: flex; gap: 12px; margin-top: 28px; padding-top: 22px; border-top: 1px solid var(--border-subtle); }
    .btn-submit {
      flex: 2; background: var(--primary); color: #ffffff; border: none; padding: 14px;
      border-radius: 12px; font-size: 14.5px; font-weight: 700; cursor: pointer;
      display: inline-flex; align-items: center; justify-content: center; gap: 8px;
      box-shadow: 0 4px 14px var(--primary-glow); transition: all 0.2s ease;
    }
    .btn-submit:hover { background: var(--primary-hover); transform: translateY(-1px); }
    .btn-cancel {
      flex: 1; background: var(--card-inner); color: var(--text-muted); border: 1px solid var(--border-subtle);
      padding: 14px; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer;
      display: inline-flex; align-items: center; justify-content: center; transition: all 0.2s ease;
    }
    .btn-cancel:hover { color: var(--text-main); border-color: var(--text-muted); }

    .app-footer { border-top: 1px solid var(--border-subtle); padding: 24px; text-align: center; font-size: 12.5px; color: var(--text-muted); background: var(--bg-dark); }
    @media (max-width: 640px) { .fields-grid { grid-template-columns: 1fr; } .btn-actions { flex-direction: column; } }
  </style>
</head>
<body>

  <header class="app-header">
    <a href="../progreso.php" class="brand-logo">
      <div class="brand-icon"><i class="fas fa-pen-to-square"></i></div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>
    <a href="../progreso.php" class="btn-return">
      <i class="fas fa-chevron-left"></i><span>Volver</span>
    </a>
  </header>

  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenida.php">Panel</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_adminII.php">Salud y Rendimiento</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../progreso.php">Progreso</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Modificar</span>
    </div>

    <div class="form-card">
      <div class="form-header">
        <span class="badge-header"><i class="fas fa-arrows-rotate"></i> Actualización de Expediente</span>
        <h2>Modificar Progreso Deportivo</h2>
        <p>Ajusta el recuento de cinturones, exámenes aprobados o actualiza la lista de torneos del atleta.</p>
      </div>

      <form action="modificarHP_be.php" method="POST">
        <div class="form-group">
          <label for="id_A"><i class="fas fa-user"></i> Alumno</label>
          <div class="input-wrapper">
            <i class="fas fa-id-card"></i>
            <select name="id_A" id="id_A" required>
              <option value="">-- Selecciona el alumno a actualizar --</option>
              <?php
                include("../php/conexion_be.php");
                $sql = "SELECT id, nombreA FROM estudiantes";
                $resultado = mysqli_query($conexion, $sql);
                while ($fila = mysqli_fetch_assoc($resultado)) {
                  echo "<option value='" . $fila['id'] . "'>ID #" . $fila['id'] . " — " . htmlspecialchars($fila['nombreA']) . "</option>";
                }
              ?>
            </select>
          </div>
        </div>

        <div class="fields-grid">
          <div class="form-group" style="margin-bottom: 0;">
            <label for="cinturones"><i class="fas fa-ribbon"></i> Cantidad de Cinturones</label>
            <div class="input-wrapper">
              <i class="fas fa-medal"></i>
              <input type="number" name="cinturones" id="cinturones" min="0" placeholder="Número de cinturones" required>
            </div>
          </div>

          <div class="form-group" style="margin-bottom: 0;">
            <label for="examenes"><i class="fas fa-file-signature"></i> Cantidad de Exámenes</label>
            <div class="input-wrapper">
              <i class="fas fa-graduation-cap"></i>
              <input type="number" name="examenes" id="examenes" min="0" placeholder="Exámenes aprobados" required>
            </div>
          </div>
        </div>

        <div class="form-group">
          <label for="torneos"><i class="fas fa-shield-halved"></i> Participación en Torneos</label>
          <select name="torneos[]" id="torneos" multiple required size="5">
            <?php
              $sql_torneo = "SELECT nombre FROM torneo ORDER BY nombre ASC";
              $result_torneo = mysqli_query($conexion, $sql_torneo);
              while ($torneo = mysqli_fetch_assoc($result_torneo)) {
                echo "<option value='" . htmlspecialchars($torneo['nombre']) . "'>" . htmlspecialchars($torneo['nombre']) . "</option>";
              }
              mysqli_close($conexion);
            ?>
          </select>
          <small class="hint-text"><i class="fas fa-circle-info"></i> Mantén presionado Ctrl (Windows) o Cmd (Mac) para seleccionar torneos.</small>
        </div>

        <div class="btn-actions">
          <button type="submit" class="btn-submit">
            <i class="fas fa-arrows-rotate"></i><span>Actualizar Progreso</span>
          </button>
          <button type="button" onclick="window.location.href='../progreso.php';" class="btn-cancel">
            Cancelar
          </button>
        </div>
      </form>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de salud y rendimiento atlético &bull; Team Dharius.
  </footer>
</body>
</html>