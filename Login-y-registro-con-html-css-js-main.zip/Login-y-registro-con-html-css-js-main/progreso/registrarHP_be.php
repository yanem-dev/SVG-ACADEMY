<?php

include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_A = mysqli_real_escape_string($conexion, $_POST['id_A']);
    $cinturones = mysqli_real_escape_string($conexion, $_POST['cinturones']);
    $examenes = mysqli_real_escape_string($conexion, $_POST['examenes']);
    $torneos_array = $_POST['torneos'];

    // ✅ Verificar si ya existe un registro para ese alumno
    $verificar_sql = "SELECT id FROM historialprogreso WHERE id_A = '$id_A'";
    $verificar_resultado = mysqli_query($conexion, $verificar_sql);

    if (mysqli_num_rows($verificar_resultado) > 0) {
        echo '
        <script>
            alert("Este alumno ya tiene un registro de progreso. No se puede registrar nuevamente.");
            window.location = "registrarhp.php";
        </script>
        ';
    } else {
        if (!empty($torneos_array)) {
            $torneos = implode(', ', array_map(function($t) use ($conexion) {
                return mysqli_real_escape_string($conexion, $t);
            }, $torneos_array));

            $sql = "INSERT INTO historialprogreso (id_A, cinturones, examenes, torneos)
                    VALUES ('$id_A', '$cinturones', '$examenes', '$torneos')";

            if (mysqli_query($conexion, $sql)) {
                echo '
                <script>
                    alert("Progreso registrado correctamente");
                    window.location = "../progreso.php";
                </script>
                ';
            } else {
                echo '
                <script>
                    alert("Error al registrar el progreso: ' . mysqli_error($conexion) . '");
                    window.location = "registrarhp.php";
                </script>
                ';
            }
        } else {
            echo '
            <script>
                alert("Debes seleccionar al menos un torneo.");
                window.location = "registrarhp.php";
            </script>
            ';
        }
    }

    mysqli_close($conexion);
}
?>
 