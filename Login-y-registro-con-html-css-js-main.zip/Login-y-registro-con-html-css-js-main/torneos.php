<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Control de Torneos y Competiciones</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --gold: #f59e0b;
      --gold-hover: #d97706;
      --gold-glow: rgba(245, 158, 11, 0.25);
      --emerald: #10b981;
      --danger: #ef4444;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #f59e0b;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(245, 158, 11, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(99, 102, 241, 0.2));
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.4);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--gold-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--gold);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(245, 158, 11, 0.15);
      color: var(--gold);
      border-color: var(--gold);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1140px;
      margin: 0 auto;
      padding: 44px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--gold);
    }

    .header-banner h1 {
      font-size: 30px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .header-banner p {
      font-size: 14.5px;
      color: var(--text-muted);
      margin-top: 6px;
      margin-bottom: 36px;
    }

    /* Grid de Acciones CRUD */
    .crud-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(310px, 1fr));
      gap: 22px;
    }

    .crud-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 28px 24px;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 200px;
      transition: all 0.25s ease;
      position: relative;
      text-align: left;
    }

    .crud-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.7);
    }

    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 18px;
    }

    .card-icon {
      width: 50px;
      height: 50px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      transition: transform 0.2s ease;
    }

    .crud-card:hover .card-icon {
      transform: scale(1.08);
    }

    /* Variantes por Acción */
    .card-create .card-icon {
      background: rgba(245, 158, 11, 0.15);
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.3);
    }
    .card-create:hover { border-color: var(--gold); }

    .card-edit .card-icon {
      background: rgba(99, 102, 241, 0.15);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
    }
    .card-edit:hover { border-color: var(--primary); }

    .card-list .card-icon {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
    }
    .card-list:hover { border-color: var(--accent); }

    .card-search .card-icon {
      background: rgba(16, 185, 129, 0.15);
      color: var(--emerald);
      border: 1px solid rgba(16, 185, 129, 0.3);
    }
    .card-search:hover { border-color: var(--emerald); }

    .card-delete .card-icon {
      background: rgba(239, 68, 68, 0.15);
      color: var(--danger);
      border: 1px solid rgba(239, 68, 68, 0.3);
    }
    .card-delete:hover { 
      border-color: var(--danger);
      box-shadow: 0 20px 40px -15px rgba(239, 68, 68, 0.3);
    }

    .status-tag {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.05em;
      padding: 4px 10px;
      border-radius: 6px;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
    }

    .card-delete .status-tag {
      color: #fca5a5;
      background: rgba(239, 68, 68, 0.1);
      border-color: rgba(239, 68, 68, 0.3);
    }

    .card-body h3 {
      font-size: 18px;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 6px;
    }

    .card-body p {
      font-size: 13px;
      color: var(--text-muted);
      line-height: 1.5;
    }

    .card-action {
      margin-top: 20px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      font-weight: 700;
      color: var(--text-muted);
      transition: all 0.2s ease;
    }

    .crud-card:hover .card-action {
      gap: 12px;
      color: var(--text-main);
    }

    .card-create:hover .card-action { color: var(--gold); }
    .card-edit:hover .card-action { color: #818cf8; }
    .card-list:hover .card-action { color: var(--accent); }
    .card-search:hover .card-action { color: var(--emerald); }
    .card-delete:hover .card-action { color: var(--danger); }

    /* Toast Notification Flotante */
    .toast-notification {
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: rgba(17, 24, 39, 0.95);
      border: 1px solid var(--gold);
      color: var(--text-main);
      font-size: 13.5px;
      font-weight: 600;
      padding: 14px 22px;
      border-radius: 14px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6), 0 0 15px var(--gold-glow);
      display: flex;
      align-items: center;
      gap: 10px;
      z-index: 1000;
      opacity: 0;
      transform: translateY(20px);
      transition: all 0.25s ease;
      pointer-events: none;
    }

    .toast-notification.show {
      opacity: 1;
      transform: translateY(0);
    }

    .toast-notification i {
      color: var(--gold);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 30px 16px;
      }
      .header-banner h1 {
        font-size: 24px;
      }
      .crud-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="modulos_admin.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-trophy"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <button onclick="redirectWithToast('modulos_admin.php')" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver a Módulos</span>
    </button>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="bienvenida.php">Panel Administrador</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="modulos_admin.php">Gestión de Alumnos</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Torneos y Competencias</span>
    </div>

    <div class="header-banner">
      <h1>Consola de Torneos y Eventos</h1>
      <p>Administra las convocatorias oficiales, sedes, fechas de pesaje y encuentros competitivos.</p>
    </div>

    <div class="crud-grid">
      <!-- 1. Registrar Torneo -->
      <div class="crud-card card-create" onclick="redirectWithToast('torneos/registrartor.php')">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-award"></i>
          </div>
          <span class="status-tag">CONVOCATORIA</span>
        </div>
        <div class="card-body">
          <h3>Registrar Torneo</h3>
          <p>Publica una nueva convocatoria con nombre del torneo, sede, fecha programada y hora de inicio.</p>
        </div>
        <div class="card-action">
          <span>Crear torneo</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </div>

      <!-- 2. Actualizar Torneo -->
      <div class="crud-card card-edit" onclick="redirectWithToast('torneos/modificartor.php')">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-pen-to-square"></i>
          </div>
          <span class="status-tag">EDICIÓN</span>
        </div>
        <div class="card-body">
          <h3>Actualizar Torneo</h3>
          <p>Modifica fechas, actualiza la sede asignada o reprograma los horarios de la competencia.</p>
        </div>
        <div class="card-action">
          <span>Editar evento</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </div>

      <!-- 3. Mostrar Torneos -->
      <div class="crud-card card-list" onclick="redirectWithToast('torneos/mostrartor.php')">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-table-list"></i>
          </div>
          <span class="status-tag">CALENDARIO</span>
        </div>
        <div class="card-body">
          <h3>Mostrar Torneos</h3>
          <p>Consulta el circuito general de eventos programados y genera el listado oficial en formato PDF.</p>
        </div>
        <div class="card-action">
          <span>Ver calendario</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </div>

      <!-- 4. Buscar Torneos -->
      <div class="crud-card card-search" onclick="redirectWithToast('torneos/buscartor.php')">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-magnifying-glass"></i>
          </div>
          <span class="status-tag">BÚSQUEDA</span>
        </div>
        <div class="card-body">
          <h3>Buscar Torneos</h3>
          <p>Encuentra competiciones específicas por nombre o sede en tiempo real dentro del padrón oficial.</p>
        </div>
        <div class="card-action">
          <span>Buscar evento</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </div>

      <!-- 5. Eliminar Torneo (Zona Crítica) -->
      <div class="crud-card card-delete" onclick="redirectWithToast('torneos/eliminartor.php')">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-trash-can"></i>
          </div>
          <span class="status-tag">ZONA CRÍTICA</span>
        </div>
        <div class="card-body">
          <h3>Eliminar Torneo</h3>
          <p>Cancela o retira convocatorias pasadas o suspendidas. Requiere confirmación del administrador.</p>
        </div>
        <div class="card-action">
          <span>Eliminar evento</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </div>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de gestión de torneos &bull; 
  </footer>

  <!-- Toast Notification Flotante -->
  <div id="toast" class="toast-notification">
    <i class="fas fa-circle-notch fa-spin"></i>
    <span id="toastMsg">Accediendo a la sección...</span>
  </div>

  <script>
    function redirectWithToast(url) {
      const toast = document.getElementById('toast');
      toast.classList.add('show');
      setTimeout(() => {
        window.location.href = url;
      }, 300); 
    }
  </script>
</body>
</html>