<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Panel de Control Administrativo</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --emerald: #10b981;
      --emerald-glow: rgba(16, 185, 129, 0.2);
      --gold: #f59e0b;
      --gold-glow: rgba(245, 158, 11, 0.2);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #6366f1;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.15) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Top Navigation Bar */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(56, 189, 248, 0.2));
      color: var(--primary);
      border: 1px solid rgba(99, 102, 241, 0.4);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--primary-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .status-badge {
      display: flex;
      align-items: center;
      gap: 8px;
      background: rgba(99, 102, 241, 0.12);
      border: 1px solid rgba(99, 102, 241, 0.3);
      color: #818cf8;
      font-size: 12px;
      font-weight: 700;
      padding: 6px 14px;
      border-radius: 9999px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .status-dot {
      width: 8px;
      height: 8px;
      background: #818cf8;
      border-radius: 50%;
      box-shadow: 0 0 8px #818cf8;
    }

    .btn-exit {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 16px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-exit:hover {
      background: rgba(239, 68, 68, 0.15);
      color: #f87171;
      border-color: rgba(239, 68, 68, 0.3);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1180px;
      margin: 0 auto;
      padding: 48px 24px;
      flex: 1;
    }

    .welcome-banner {
      margin-bottom: 40px;
    }

    .admin-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(99, 102, 241, 0.12);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 12px;
    }

    .welcome-banner h1 {
      font-size: 32px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .welcome-banner p {
      font-size: 15px;
      color: var(--text-muted);
      margin-top: 6px;
    }

    /* Grid de Módulos Administrativos */
    .modules-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 24px;
    }

    .module-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 32px 28px;
      text-decoration: none;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 250px;
      transition: all 0.28s ease;
      position: relative;
      overflow: hidden;
    }

    .module-card::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: transparent;
      transition: background 0.3s ease;
    }

    .module-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.7);
    }

    /* Variantes de color por módulo */
    .card-students:hover::before { background: var(--primary); }
    .card-students:hover { border-color: var(--primary); }

    .card-health:hover::before { background: var(--emerald); }
    .card-health:hover { border-color: var(--emerald); }

    .card-sales:hover::before { background: var(--gold); }
    .card-sales:hover { border-color: var(--gold); }

    .module-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 20px;
    }

    .module-icon {
      width: 54px;
      height: 54px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      transition: all 0.25s ease;
    }

    .card-students .module-icon {
      background: rgba(99, 102, 241, 0.15);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
    }

    .card-health .module-icon {
      background: rgba(16, 185, 129, 0.15);
      color: #34d399;
      border: 1px solid rgba(16, 185, 129, 0.3);
    }

    .card-sales .module-icon {
      background: rgba(245, 158, 11, 0.15);
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.3);
    }

    .module-card:hover .module-icon {
      transform: scale(1.08);
    }

    .tag-badge {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.05em;
      padding: 4px 10px;
      border-radius: 6px;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
    }

    .card-sales .tag-badge {
      background: rgba(245, 158, 11, 0.1);
      color: var(--gold);
      border-color: rgba(245, 158, 11, 0.25);
    }

    .module-info h3 {
      font-size: 20px;
      font-weight: 700;
      color: var(--text-main);
      margin-bottom: 8px;
    }

    .module-info p {
      font-size: 13.5px;
      color: var(--text-muted);
      line-height: 1.5;
    }

    .module-action {
      margin-top: 24px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13.5px;
      font-weight: 700;
      color: var(--text-muted);
      transition: color 0.2s ease, gap 0.2s ease;
    }

    .module-card:hover .module-action {
      color: var(--text-main);
      gap: 12px;
    }

    .card-students:hover .module-action { color: #818cf8; }
    .card-health:hover .module-action { color: #34d399; }
    .card-sales:hover .module-action { color: var(--gold); }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 32px 16px;
      }
      .welcome-banner h1 {
        font-size: 24px;
      }
      .modules-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <!-- Barra de Navegación Superior -->
  <header class="app-header">
    <a href="#" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-shield-halved"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-REDSPORT</span></span>
    </a>

    <div class="header-actions">
      <div class="status-badge">
        <span class="status-dot"></span>
        <span>Administrador</span>
      </div>
      <a href="inicio.php" class="btn-exit">
        <i class="fas fa-arrow-right-from-bracket"></i>
        <span>Cerrar Sesión</span>
      </a>
    </div>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="welcome-banner">
      <div class="admin-badge">
        <i class="fas fa-lock"></i> Dirección General &bull;
      </div>
      <h1>Panel de Control Docente y Administrativo</h1>
      <p>Supervisa el registro de matrícula, expediente clínico de atletas, inventario y balance de caja.</p>
    </div>

    <div class="modules-grid">
      <!-- 1. Gestión de Alumnos -->
      <a href="modulos_admin.php" class="module-card card-students">
        <div class="module-header">
          <div class="module-icon">
            <i class="fas fa-users-gear"></i>
          </div>
          <span class="tag-badge">MATRÍCULA</span>
        </div>
        <div class="module-info">
          <h3>Gestión de Alumnos</h3>
          <p>Altas, modificaciones, listas de atletas, asignación de horarios, turnos de entrenamiento y control de torneos.</p>
        </div>
        <div class="module-action">
          <span>Administrar alumnos</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- 2. Gestión de Salud y Progreso -->
      <a href="modulos_adminII.php" class="module-card card-health">
        <div class="module-header">
          <div class="module-icon">
            <i class="fas fa-heart-pulse"></i>
          </div>
          <span class="tag-badge">BIOMETRÍA</span>
        </div>
        <div class="module-info">
          <h3>Salud y Progreso</h3>
          <p>Registro de evaluaciones antropométricas (peso, estatura, IMC), antecedentes médicos y grados de cinta.</p>
        </div>
        <div class="module-action">
          <span>Gestionar historial médico</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- 3. Gestión de Ventas (E-Commerce y Finanzas) -->
      <a href="modulos_adminIII.php" class="module-card card-sales">
        <div class="module-header">
          <div class="module-icon">
            <i class="fas fa-chart-line"></i>
          </div>
          <span class="tag-badge">FINANZAS & STOCK</span>
        </div>
        <div class="module-info">
          <h3>Gestión de Ventas</h3>
          <p>Inventario de productos oficiales, altas de artículos, precios, ventas realizadas y asignación de membresías.</p>
        </div>
        <div class="module-action">
          <span>Abrir consola comercial</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de administración central &bull; 
  </footer>

</body>
</html>