<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Portal Atletas</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 24px;
      color: var(--text-main);
    }

    .auth-container {
      background: var(--card-bg);
      width: 100%;
      max-width: 460px;
      border-radius: 24px;
      padding: 38px 30px;
      border: 1px solid var(--border-subtle);
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
      position: relative;
    }

    .brand-top {
      text-align: center;
      margin-bottom: 24px;
    }

    .brand-icon {
      width: 52px;
      height: 52px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 16px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      margin-bottom: 12px;
      box-shadow: 0 0 20px rgba(56, 189, 248, 0.2);
    }

    .brand-name {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: var(--text-main);
      margin-bottom: 6px;
    }

    .brand-name .highlight {
      color: var(--accent);
    }

    .portal-badge {
      display: inline-block;
      background: rgba(99, 102, 241, 0.15);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.1em;
      padding: 3px 10px;
      border-radius: 9999px;
      margin-bottom: 8px;
    }

    .brand-top p {
      font-size: 13.5px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    /* Pestañas tipo SaaS */
    .tab-switch {
      display: flex;
      background: var(--input-bg);
      padding: 4px;
      border-radius: 14px;
      border: 1px solid var(--border-subtle);
      margin-bottom: 24px;
    }

    .tab-btn {
      flex: 1;
      padding: 10px;
      border: none;
      background: transparent;
      color: var(--text-muted);
      font-size: 13.5px;
      font-weight: 600;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .tab-btn.active {
      background: var(--card-inner);
      color: var(--text-main);
      border: 1px solid var(--border-subtle);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }

    /* Formularios */
    .form-pane {
      display: none;
      animation: fadeIn 0.25s ease-in-out forwards;
    }

    .form-pane.active {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .input-field {
      position: relative;
    }

    .input-field i {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748b;
      font-size: 14px;
      pointer-events: none;
    }

    .input-field input, 
    .input-field select {
      width: 100%;
      background: var(--input-bg);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 13px 16px 13px 44px;
      border-radius: 12px;
      font-size: 14px;
      outline: none;
      transition: all 0.2s ease;
    }

    .input-field select {
      appearance: none;
      cursor: pointer;
    }

    .input-field input:focus, 
    .input-field select:focus {
      border-color: var(--border-focus);
      box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
    }

    .input-field input[readonly] {
      background: rgba(15, 23, 42, 0.6);
      color: #94a3b8;
      cursor: not-allowed;
      border-style: dashed;
    }

    .notice-box {
      background: rgba(99, 102, 241, 0.08);
      border: 1px solid rgba(99, 102, 241, 0.2);
      border-radius: 10px;
      padding: 10px 14px;
      font-size: 12px;
      color: var(--text-muted);
      display: flex;
      gap: 10px;
      align-items: flex-start;
      line-height: 1.4;
    }

    .notice-box i {
      color: var(--accent);
      margin-top: 2px;
    }

    .btn-submit {
      width: 100%;
      background: var(--primary);
      color: #ffffff;
      border: none;
      padding: 14px;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--primary-glow);
    }

    .btn-submit:hover {
      background: var(--primary-hover);
      transform: translateY(-1px);
    }

    /* Enlace volver */
    .btn-back {
      margin-top: 22px;
      text-align: center;
    }

    .btn-back a {
      color: var(--text-muted);
      font-size: 13px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: color 0.2s ease;
    }

    .btn-back a:hover {
      color: var(--accent);
    }
  </style>
</head>
<body>

  <div class="auth-container">
    <div class="brand-top">
      <div class="brand-icon">
        <i class="fas fa-bolt"></i>
      </div>
      <div class="app-branding">
        <h1 class="brand-name">SVG<span class="highlight">-REDSPORT</span></h1>
        <span class="portal-badge">ATLETAS</span>
      </div>
      <p>Accede a tu informacion y acerca de tu organizacion.</p>
    </div>

    <!-- Pestañas de cambio -->
    <div class="tab-switch">
      <button class="tab-btn active" id="tab-login" onclick="cambiarPestana('login')">
        <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
      </button>
      <button class="tab-btn" id="tab-register" onclick="cambiarPestana('register')">
        <i class="fas fa-user-plus"></i> Registrarse
      </button>
    </div>

    <!-- Formulario de Iniciar Sesión -->
    <form action="php/login_alumno_be.php" method="POST" class="form-pane active" id="form-login">
      <div class="input-field">
        <i class="fas fa-envelope"></i>
        <input type="text" placeholder="Correo Electrónico" name="correo" required>
      </div>

      <div class="input-field">
        <i class="fas fa-lock"></i>
        <input type="password" placeholder="Contraseña" name="contrasena" required>
      </div>

      <button type="submit" class="btn-submit">
        <span>Entrar a Entrenar</span>
        <i class="fas fa-arrow-right"></i>
      </button>
    </form>

    <!-- Formulario de Registro -->
    <form action="php/registro_alumno_be.php" method="POST" class="form-pane" id="form-register">
      <div class="notice-box">
        <i class="fas fa-circle-info"></i>
        <span>Si tu correo no aparece en la lista, solicita al entrenador o administrador que te dé de alta.</span>
      </div>

      <div class="input-field">
        <i class="fas fa-list-ul"></i>
        <select name="correo" id="correo" required>
          <option value="">Selecciona tu correo asignado</option>
          <?php
            include 'php/conexion_be.php';
            $query = "SELECT id, nombreA, correoA FROM estudiantes";
            $result = mysqli_query($conexion, $query);
            while ($row = mysqli_fetch_assoc($result)) {
              echo '<option value="' . $row['correoA'] . '" data-nombre="' . htmlspecialchars($row['nombreA']) . '" data-id="' . $row['id'] . '">' . $row['correoA'] . ' — ' . $row['nombreA'] . '</option>';
            }
          ?>
        </select>
      </div>

      <div class="input-field">
        <i class="fas fa-id-card"></i>
        <input type="text" name="nombre" id="nombre" placeholder="Nombre completo" readonly required>
      </div>

      <input type="hidden" name="id_estudiante" id="id_estudiante">

      <div class="input-field">
        <i class="fas fa-user"></i>
        <input type="text" placeholder="Nombre de usuario" name="usuario" required>
      </div>

      <div class="input-field">
        <i class="fas fa-lock"></i>
        <input type="password" placeholder="Crea una contraseña" name="contrasena" required>
      </div>

      <button type="submit" class="btn-submit">
        <span>Completar Registro</span>
        <i class="fas fa-check-circle"></i>
      </button>
    </form>

    <div class="btn-back">
      <a href="index.php">
        <i class="fas fa-chevron-left"></i> Cambiar tipo de acceso
      </a>
    </div>
  </div>

  <script>
    function cambiarPestana(modo) {
      const formLogin = document.getElementById('form-login');
      const formRegister = document.getElementById('form-register');
      const tabLogin = document.getElementById('tab-login');
      const tabRegister = document.getElementById('tab-register');

      if (modo === 'login') {
        formLogin.classList.add('active');
        formRegister.classList.remove('active');
        tabLogin.classList.add('active');
        tabRegister.classList.remove('active');
      } else {
        formRegister.classList.add('active');
        formLogin.classList.remove('active');
        tabRegister.classList.add('active');
        tabLogin.classList.remove('active');
      }
    }

    document.getElementById('correo').addEventListener('change', function () {
      let selected = this.options[this.selectedIndex];
      let nombre = selected.getAttribute('data-nombre');
      let id = selected.getAttribute('data-id');

      document.getElementById('nombre').value = nombre || '';
      document.getElementById('id_estudiante').value = id || '';
    });
  </script>
</body>
</html>