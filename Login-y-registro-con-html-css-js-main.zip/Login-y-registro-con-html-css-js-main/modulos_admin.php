<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Control de Alumnos y Matrícula</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --gold: #f59e0b;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #6366f1;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.15) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Barra Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(56, 189, 248, 0.2));
      color: var(--primary);
      border: 1px solid rgba(99, 102, 241, 0.4);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--primary-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-return:hover {
      background: rgba(99, 102, 241, 0.15);
      color: var(--primary);
      border-color: var(--primary);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1140px;
      margin: 0 auto;
      padding: 44px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--accent);
    }

    .header-banner h1 {
      font-size: 30px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .header-banner p {
      font-size: 14.5px;
      color: var(--text-muted);
      margin-top: 6px;
      margin-bottom: 36px;
    }

    /* Grid de Herramientas */
    .cards-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 24px;
    }

    .card-item {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 32px 26px;
      text-decoration: none;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 235px;
      transition: all 0.25s ease;
      position: relative;
    }

    .card-item:hover {
      transform: translateY(-4px);
      border-color: var(--border-focus);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.7);
    }

    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 20px;
    }

    .card-icon {
      width: 52px;
      height: 52px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      transition: transform 0.2s ease;
    }

    .card-students .card-icon {
      background: rgba(99, 102, 241, 0.15);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
    }

    .card-schedules .card-icon {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .card-tournaments .card-icon {
      background: rgba(245, 158, 11, 0.15);
      color: var(--gold);
      border: 1px solid rgba(245, 158, 11, 0.3);
    }

    .card-item:hover .card-icon {
      transform: scale(1.08);
    }

    .status-tag {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.05em;
      padding: 4px 10px;
      border-radius: 6px;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
    }

    .card-content h3 {
      font-size: 18px;
      font-weight: 700;
      color: var(--text-main);
      margin-bottom: 8px;
    }

    .card-content p {
      font-size: 13.5px;
      color: var(--text-muted);
      line-height: 1.5;
    }

    .card-action {
      margin-top: 24px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      font-weight: 600;
      color: var(--text-muted);
      transition: all 0.2s ease;
    }

    .card-item:hover .card-action {
      color: var(--primary);
      gap: 12px;
    }

    .card-schedules:hover .card-action {
      color: var(--accent);
    }

    .card-tournaments:hover .card-action {
      color: var(--gold);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 30px 16px;
      }
      .header-banner h1 {
        font-size: 24px;
      }
      .cards-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="bienvenida.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-shield-halved"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <a href="bienvenida.php" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver al Panel</span>
    </a>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="bienvenida.php">Panel Administrador</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Gestión de Alumnos</span>
    </div>

    <div class="header-banner">
      <h1>Control Académico y Operativo</h1>
      <p>Administra expedientes de matrícula, asignación de turnos y convocatorias a torneos oficiales.</p>
    </div>

    <div class="cards-grid">
      <!-- 1. Información de Alumnos -->
      <a href="estudiante.php" class="card-item card-students">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-user-group"></i>
          </div>
          <span class="status-tag">PADRÓN</span>
        </div>
        <div class="card-content">
          <h3>Información de Alumnos</h3>
          <p>Consulta el directorio completo de atletas, alta de nuevos ingresos, modificación y bajas de matrícula.</p>
        </div>
        <div class="card-action">
          <span>Gestionar padrón</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- 2. Horarios -->
      <a href="horarios.php" class="card-item card-schedules">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-clock"></i>
          </div>
          <span class="status-tag">TURNOS</span>
        </div>
        <div class="card-content">
          <h3>Gestión de Horarios</h3>
          <p>Configuración de turnos matutinos y vespertinos, franjas horarias de entrenamiento y asignación de dojo.</p>
        </div>
        <div class="card-action">
          <span>Gestionar turnos</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- 3. Torneos -->
      <a href="torneos.php" class="card-item card-tournaments">
        <div class="card-top">
          <div class="card-icon">
            <i class="fas fa-trophy"></i>
          </div>
          <span class="status-tag">COMPETICIÓN</span>
        </div>
        <div class="card-content">
          <h3>Gestión de Torneos</h3>
          <p>Publicación de convocatorias, fechas de pesaje, sedes, horarios de competencia y registro de eventos.</p>
        </div>
        <div class="card-action">
          <span>Administrar torneos</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Consola de gestión académica y operativa &bull; 
  </footer>

</body>
</html>