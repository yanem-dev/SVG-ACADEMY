<?php
include("php/conexion_be.php");
session_start();

if (!isset($_SESSION['id_estudiante'])) {
    http_response_code(401);
    echo "No has iniciado sesión.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SVG-SPORTS | Panel del Atleta</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --emerald: #10b981;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #38bdf8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Top Navigation Bar */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--accent);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .status-badge {
      display: flex;
      align-items: center;
      gap: 8px;
      background: rgba(16, 185, 129, 0.1);
      border: 1px solid rgba(16, 185, 129, 0.25);
      color: #34d399;
      font-size: 12px;
      font-weight: 600;
      padding: 6px 12px;
      border-radius: 9999px;
    }

    .status-dot {
      width: 8px;
      height: 8px;
      background: #10b981;
      border-radius: 50%;
      box-shadow: 0 0 8px #10b981;
    }

    .btn-exit {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 16px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-exit:hover {
      background: rgba(239, 68, 68, 0.15);
      color: #f87171;
      border-color: rgba(239, 68, 68, 0.3);
    }

    /* Main Dashboard Layout */
    .dashboard-container {
      width: 100%;
      max-width: 1180px;
      margin: 0 auto;
      padding: 48px 24px;
      flex: 1;
    }

    .welcome-banner {
      margin-bottom: 40px;
    }

    .team-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(99, 102, 241, 0.12);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 12px;
    }

    .welcome-banner h1 {
      font-size: 32px;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
    }

    .welcome-banner p {
      font-size: 15px;
      color: var(--text-muted);
      margin-top: 6px;
    }

    /* Grid de Módulos */
    .modules-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 24px;
    }

    .module-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 32px 28px;
      text-decoration: none;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 240px;
      transition: all 0.28s ease;
      position: relative;
      overflow: hidden;
    }

    .module-card::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: transparent;
      transition: background 0.3s ease;
    }

    .module-card:hover {
      transform: translateY(-4px);
      border-color: var(--border-focus);
      box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.6);
    }

    /* Variantes por módulo */
    .card-training:hover::before {
      background: var(--primary);
    }
    .card-health:hover::before {
      background: var(--emerald);
    }
    .card-store:hover::before {
      background: var(--accent);
    }

    .module-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 20px;
    }

    .module-icon {
      width: 54px;
      height: 54px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      transition: all 0.25s ease;
    }

    .card-training .module-icon {
      background: rgba(99, 102, 241, 0.15);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
    }

    .card-health .module-icon {
      background: rgba(16, 185, 129, 0.15);
      color: #34d399;
      border: 1px solid rgba(16, 185, 129, 0.3);
    }

    .card-store .module-icon {
      background: rgba(56, 189, 248, 0.15);
      color: var(--accent);
      border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .module-card:hover .module-icon {
      transform: scale(1.08);
    }

    .tag-badge {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.05em;
      padding: 4px 10px;
      border-radius: 6px;
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
    }

    .card-store .tag-badge {
      background: rgba(56, 189, 248, 0.1);
      color: var(--accent);
      border-color: rgba(56, 189, 248, 0.25);
    }

    .module-info h3 {
      font-size: 19px;
      font-weight: 700;
      color: var(--text-main);
      margin-bottom: 8px;
    }

    .module-info p {
      font-size: 13.5px;
      color: var(--text-muted);
      line-height: 1.5;
    }

    .module-action {
      margin-top: 24px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13.5px;
      font-weight: 600;
      color: var(--text-muted);
      transition: color 0.2s ease, gap 0.2s ease;
    }

    .module-card:hover .module-action {
      color: var(--text-main);
      gap: 12px;
    }

    .card-store:hover .module-action {
      color: var(--accent);
    }

    /* Footer */
    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 32px 16px;
      }
      .welcome-banner h1 {
        font-size: 24px;
      }
      .modules-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <!-- Barra de Navegación Superior -->
  <header class="app-header">
    <a href="#" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-bolt"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-REDSPORT</span></span>
    </a>

    <div class="header-actions">
      <div class="status-badge">
        <span class="status-dot"></span>
        <span>Atleta Activo</span>
      </div>
      <a href="index.php" class="btn-exit">
        <i class="fas fa-arrow-right-from-bracket"></i>
        <span>Salir</span>
      </a>
    </div>
  </header>

  <!-- Contenido Central del Dashboard -->
  <main class="dashboard-container">
    <div class="welcome-banner">
      <div class="team-badge">
        <i class="fas fa-shield-halved"></i> ARTICULOS DEPORTIVOS
      </div>
      <h1>Consola de Control del Atleta</h1>
      <p>Selecciona una sección para gestionar tu entrenamiento, métricas o tienda oficial.</p>
    </div>

    <div class="modules-grid">
      <!-- Módulo 1: Alumnos / Entrenamientos -->
      <a href="modulos_alumno.php" class="module-card card-training">
        <div class="module-header">
          <div class="module-icon">
            <i class="fas fa-dumbbell"></i>
          </div>
          <span class="tag-badge">ACADÉMICO</span>
        </div>
        <div class="module-info">
          <h3>Módulo de Alumnos</h3>
          <p>Consulta tus asistencias, horarios de sesiones, instructores y estado de matrícula.</p>
        </div>
        <div class="module-action">
          <span>Abrir sección</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- Módulo 2: Salud y Rendimiento -->
      <a href="modulos_alumnoII.php" class="module-card card-health">
        <div class="module-header">
          <div class="module-icon">
            <i class="fas fa-heart-pulse"></i>
          </div>
          <span class="tag-badge">BIENESTAR</span>
        </div>
        <div class="module-info">
          <h3>Salud y Progreso</h3>
          <p>Métricas antropométricas, registros de peso, evolución física y rendimiento deportivo.</p>
        </div>
        <div class="module-action">
          <span>Ver mi evolución</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>

      <!-- Módulo 3: Tienda y Ventas (Enfoque Comercial) -->
      <a href="modulos_alumnosIII.php" class="module-card card-store">
        <div class="module-header">
          <div class="module-icon">
            <i class="fas fa-bag-shopping"></i>
          </div>
          <span class="tag-badge">TIENDA OFICIAL</span>
        </div>
        <div class="module-info">
          <h3>Módulo de Ventas</h3>
          <p>Adquiere uniformes, equipamiento técnico, suplementos y renueva tus membresías activas.</p>
        </div>
        <div class="module-action">
          <span>Explorar catálogo</span>
          <i class="fas fa-arrow-right"></i>
        </div>
      </a>
    </div>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Plataforma integral desarrollada para el control y rendimiento de Team Dharius.
  </footer>

</body>
</html>