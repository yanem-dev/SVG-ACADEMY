<?php
include("../php/conexion_be.php");

if (isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];

    $sql = "SELECT estudiantes.id, estudiantes.nombreA, salud.peso, salud.estatura, salud.alergias, salud.grupoSan, salud.padecimientos
            FROM estudiantes
            INNER JOIN salud ON estudiantes.id = salud.id_estudiante
            WHERE estudiantes.nombreA LIKE '%$nombre%'";  

    $resultado = mysqli_query($conexion, $sql);

    
    if (mysqli_num_rows($resultado) > 0) {
        echo '<table>';
        echo '<thead><tr><th>ID Estudiante</th><th>Nombre del Alumno</th><th>Peso (kg)</th><th>Estatura (m)</th><th>Alergias</th><th>Grupo Sanguíneo</th><th>Padecimientos</th></tr></thead>';
        echo '<tbody>';

      
        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo "<tr>";
            echo "<td>" . $fila['id'] . "</td>";
            echo "<td>" . $fila['nombreA'] . "</td>";
            echo "<td>" . $fila['peso'] . "</td>";
            echo "<td>" . $fila['estatura'] . "</td>";
            echo "<td>" . $fila['alergias'] . "</td>";
            echo "<td>" . $fila['grupoSan'] . "</td>";
            echo "<td>" . $fila['padecimientos'] . "</td>";
            echo "</tr>";
        }

        echo '</tbody>';
        echo '</table>';
    } else {
        echo "<p class='no-results'>No se encontraron resultados.</p>";
    }

    mysqli_close($conexion);
}
?>
