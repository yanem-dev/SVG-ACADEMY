<?php
include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_estudiante = $_POST['id_estudiante'];
    $peso = $_POST['peso'];
    $estatura = $_POST['estatura']; // En centímetros
    $alergias = $_POST['alergias'];
    $grupoSan = $_POST['grupoSan'];
    $padecimientos = $_POST['padecimientos'];

    $estatura_metros = $estatura / 100;
    $imc = ($estatura_metros > 0) ? ($peso / ($estatura_metros * $estatura_metros)) : 0;
    $imc = round($imc, 2); 

    $verificar_sql = "SELECT estudiantes.nombreA FROM salud 
                      INNER JOIN estudiantes ON salud.id_estudiante = estudiantes.id
                      WHERE salud.id_estudiante = '$id_estudiante'";
    $resultado = mysqli_query($conexion, $verificar_sql);

    if (mysqli_num_rows($resultado) > 0) {
        $fila = mysqli_fetch_assoc($resultado);
        $nombre_estudiante = $fila['nombreA'];

        echo '
        <script>
            alert("El estudiante ' . $nombre_estudiante . ' ya tiene un registro de salud.");
            window.location = "../salud.php";
        </script>
        ';
    } else {
        $sql = "INSERT INTO salud (id_estudiante, peso, estatura, alergias, grupoSan, padecimientos, imc) 
                VALUES ('$id_estudiante', '$peso', '$estatura', '$alergias', '$grupoSan', '$padecimientos', '$imc')";

        if (mysqli_query($conexion, $sql)) {
            echo '
            <script>
                alert("Registro exitoso con IMC: ' . $imc . '");
                window.location = "../salud.php";
            </script>
            ';
        } else {
            echo '
            <script>
                alert("No se pudo registrar la información");
                window.location = "registrarsalud.php";
            </script>
            ';
        }
    }

   
    mysqli_close($conexion);
}
?>
