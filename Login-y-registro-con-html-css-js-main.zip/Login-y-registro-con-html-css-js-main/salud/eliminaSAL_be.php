<?php
include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_estudiante = $_POST['id_estudiante'];

    $sql = "DELETE FROM salud WHERE id_estudiante = '$id_estudiante'";

    if (mysqli_query($conexion, $sql)) {
        echo '
        <script>
            alert("Registro de salud eliminado correctamente.");
            window.location = "../salud.php";
        </script>
        ';
    } else {
        echo '
        <script>
            alert("Error al eliminar el registro.");
            window.location = "eliminarsalud.php";
        </script>
        ';
    }

    mysqli_close($conexion);
}
?>
