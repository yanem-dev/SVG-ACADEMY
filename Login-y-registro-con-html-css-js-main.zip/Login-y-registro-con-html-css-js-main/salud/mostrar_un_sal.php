<?php
include("../php/conexion_be.php");
session_start();

if (!isset($_SESSION['id_estudiante'])) {
    echo "Debes iniciar sesión.";
    exit;
}

$id_estudiante = $_SESSION['id_estudiante'];

$sql = "SELECT estudiantes.id, estudiantes.nombreA, salud.peso, salud.estatura, salud.alergias, salud.grupoSan, salud.padecimientos, salud.imc
        FROM salud
        INNER JOIN estudiantes ON salud.id_estudiante = estudiantes.id
        WHERE estudiantes.id = '$id_estudiante'";
$resultado = mysqli_query($conexion, $sql);
$salud = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-SPORTS | Ficha Médica y Biométrica</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --emerald: #10b981;
      --emerald-glow: rgba(16, 185, 129, 0.25);
      --warning: #f59e0b;
      --danger: #ef4444;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #10b981;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(16, 185, 129, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
    }

    /* Header Superior */
    .app-header {
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-subtle);
      padding: 16px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
    }

    .brand-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(56, 189, 248, 0.2));
      color: var(--emerald);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      box-shadow: 0 0 15px var(--emerald-glow);
    }

    .brand-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.04em;
      color: var(--text-main);
    }

    .brand-title .highlight {
      color: var(--emerald);
    }

    .btn-return {
      background: var(--card-inner);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-return:hover {
      background: rgba(16, 185, 129, 0.15);
      color: var(--emerald);
      border-color: var(--emerald);
    }

    /* Layout Central */
    .dashboard-container {
      width: 100%;
      max-width: 1000px;
      margin: 0 auto;
      padding: 40px 24px;
      flex: 1;
    }

    .page-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 12px;
    }

    .page-indicator a {
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .page-indicator a:hover {
      color: var(--emerald);
    }

    .top-actions-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 30px;
    }

    .top-actions-bar h1 {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .btn-pdf {
      background: var(--emerald);
      color: #062817;
      border: none;
      padding: 10px 20px;
      border-radius: 12px;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--emerald-glow);
      transition: all 0.2s ease;
    }

    .btn-pdf:hover {
      background: #059669;
      color: #ffffff;
      transform: translateY(-2px);
    }

    /* Ficha Médica */
    .health-card {
      background: var(--card-bg);
      border: 1px solid var(--border-subtle);
      border-radius: 24px;
      padding: 32px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
    }

    .patient-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      padding-bottom: 24px;
      border-bottom: 1px solid var(--border-subtle);
      margin-bottom: 28px;
    }

    .patient-info {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .patient-avatar {
      width: 58px;
      height: 58px;
      border-radius: 16px;
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid rgba(16, 185, 129, 0.3);
      color: var(--emerald);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
    }

    .patient-names h2 {
      font-size: 22px;
      font-weight: 800;
      color: var(--text-main);
    }

    .patient-names p {
      font-size: 13px;
      color: var(--text-muted);
      margin-top: 2px;
    }

    .blood-badge {
      background: rgba(239, 68, 68, 0.12);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #f87171;
      padding: 6px 14px;
      border-radius: 9999px;
      font-size: 13px;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    /* Métricas Clave (KPIs) */
    .metrics-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-bottom: 28px;
    }

    .metric-card {
      background: var(--card-inner);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
      padding: 20px;
      position: relative;
    }

    .metric-title {
      font-size: 12px;
      font-weight: 600;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 8px;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .metric-value {
      font-size: 28px;
      font-weight: 800;
      color: var(--text-main);
      display: flex;
      align-items: baseline;
      gap: 4px;
    }

    .metric-unit {
      font-size: 14px;
      font-weight: 600;
      color: var(--text-muted);
    }

    /* Badges de IMC */
    .imc-badge-status {
      display: inline-block;
      margin-top: 6px;
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
    }

    .imc-bajo { background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); }
    .imc-normal { background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
    .imc-sobrepeso { background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }
    .imc-obesidad { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }

    /* Observaciones Médicas */
    .medical-section-title {
      font-size: 13px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--emerald);
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .notes-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 16px;
    }

    .note-box {
      background: var(--card-inner);
      border: 1px solid var(--border-subtle);
      border-radius: 14px;
      padding: 18px;
    }

    .note-label {
      font-size: 12.5px;
      font-weight: 700;
      color: var(--text-muted);
      margin-bottom: 6px;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .note-content {
      font-size: 14px;
      line-height: 1.5;
      color: var(--text-main);
    }

    .app-footer {
      border-top: 1px solid var(--border-subtle);
      padding: 24px;
      text-align: center;
      font-size: 12.5px;
      color: var(--text-muted);
      background: var(--bg-dark);
    }

    /* Tabla invisible para preservar jsPDF */
    #tablaSalud {
      display: none;
    }

    @media (max-width: 640px) {
      .app-header {
        padding: 16px;
      }
      .dashboard-container {
        padding: 24px 16px;
      }
      .patient-header {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  </style>
</head>
<body>

  <!-- Barra Superior -->
  <header class="app-header">
    <a href="../modulos_alumnoII.php" class="brand-logo">
      <div class="brand-icon">
        <i class="fas fa-heart-pulse"></i>
      </div>
      <span class="brand-title">SVG<span class="highlight">-SPORTS</span></span>
    </a>

    <button onclick="window.history.back();" class="btn-return">
      <i class="fas fa-chevron-left"></i>
      <span>Volver</span>
    </button>
  </header>

  <!-- Área Central -->
  <main class="dashboard-container">
    <div class="page-indicator">
      <a href="../bienvenidaAlumnos.php">Panel Atleta</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <a href="../modulos_alumnoII.php">Salud y Progreso</a>
      <i class="fas fa-chevron-right" style="font-size: 10px;"></i>
      <span>Ficha Médica</span>
    </div>

    <div class="top-actions-bar">
      <div>
        <h1>Ficha Médica y Biométrica</h1>
        <p style="color: var(--text-muted); font-size: 14px; margin-top: 4px;">Monitoreo de condición física, composición corporal y alertas para el entrenamiento.</p>
      </div>
      <button onclick="exportarPDF()" class="btn-pdf">
        <i class="fas fa-file-pdf"></i>
        <span>Descargar Ficha PDF</span>
      </button>
    </div>

    <?php if ($salud): ?>
      <div class="health-card">
        <!-- Cabecera del Atleta -->
        <div class="patient-header">
          <div class="patient-info">
            <div class="patient-avatar">
              <i class="fas fa-shield-heart"></i>
            </div>
            <div class="patient-names">
              <h2><?php echo htmlspecialchars($salud['nombreA']); ?></h2>
              <p>ID Atleta: #<?php echo htmlspecialchars($salud['id']); ?> &bull; Team Dharius</p>
            </div>
          </div>
          <div class="blood-badge">
            <i class="fas fa-droplet"></i>
            <span>Tipo Sangre: <strong><?php echo htmlspecialchars($salud['grupoSan'] ?: 'Sin registrar'); ?></strong></span>
          </div>
        </div>

        <!-- Tarjetas Biométrica / KPIs -->
        <div class="medical-section-title">
          <i class="fas fa-chart-simple"></i> Métricas Antropométricas
        </div>

        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-title"><i class="fas fa-weight-scale"></i> Peso Corporal</div>
            <div class="metric-value">
              <span id="pesoVal"><?php echo htmlspecialchars($salud['peso']); ?></span>
              <span class="metric-unit">kg</span>
            </div>
          </div>

          <div class="metric-card">
            <div class="metric-title"><i class="fas fa-ruler-vertical"></i> Estatura</div>
            <div class="metric-value">
              <span id="estaturaVal"><?php echo htmlspecialchars($salud['estatura']); ?></span>
              <span class="metric-unit">cm</span>
            </div>
          </div>

          <div class="metric-card">
            <div class="metric-title"><i class="fas fa-calculator"></i> Índice Masa Corporal (IMC)</div>
            <div class="metric-value" id="imcDisplay">---</div>
            <span id="imcStatusTag" class="imc-badge-status">Calculando...</span>
          </div>
        </div>

        <!-- Padecimientos y Alergias -->
        <div class="medical-section-title">
          <i class="fas fa-triangle-exclamation"></i> Antecedentes y Observaciones
        </div>

        <div class="notes-grid">
          <div class="note-box">
            <div class="note-label"><i class="fas fa-wheat-awn-circle-exclamation" style="color: #f59e0b;"></i> Alergias Registradas</div>
            <div class="note-content">
              <?php echo !empty($salud['alergias']) ? nl2br(htmlspecialchars($salud['alergias'])) : '<span style="color: var(--text-muted);">Sin alergias registradas</span>'; ?>
            </div>
          </div>

          <div class="note-box">
            <div class="note-label"><i class="fas fa-notes-medical" style="color: #ef4444;"></i> Padecimientos o Lesiones</div>
            <div class="note-content">
              <?php echo !empty($salud['padecimientos']) ? nl2br(htmlspecialchars($salud['padecimientos'])) : '<span style="color: var(--text-muted);">Sin padecimientos crónicos declarados</span>'; ?>
            </div>
          </div>
        </div>
      </div>
    <?php else: ?>
      <div class="health-card" style="text-align: center; padding: 48px;">
        <i class="fas fa-heart-crack" style="font-size: 40px; color: #f87171; margin-bottom: 12px;"></i>
        <h2>No se encontró un registro médico asignado</h2>
        <p style="color: var(--text-muted); margin-top: 6px;">Comunícate con el instructor o médico de la academia para tu evaluación inicial.</p>
      </div>
    <?php endif; ?>

    <!-- Tabla invisible para que jsPDF siga funcionando sin romper nada -->
    <table id="tablaSalud">
      <thead>
        <tr>
          <th>ID Estudiante</th>
          <th>Nombre</th>
          <th>Peso (kg)</th>
          <th>Estatura (cm)</th>
          <th>Alergias</th>
          <th>Grupo Sanguíneo</th>
          <th>Padecimientos</th>
          <th>IMC</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($salud): ?>
          <tr>
            <td><?php echo $salud['id']; ?></td>
            <td><?php echo $salud['nombreA']; ?></td>
            <td><?php echo $salud['peso']; ?></td>
            <td><?php echo $salud['estatura']; ?></td>
            <td><?php echo $salud['alergias']; ?></td>
            <td><?php echo $salud['grupoSan']; ?></td>
            <td><?php echo $salud['padecimientos']; ?></td>
            <td><?php echo $salud['imc']; ?></td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </main>

  <footer class="app-footer">
    SVG-SPORTS &bull; Monitoreo médico y biometría atlética &bull; Team Dharius.
  </footer>

  <!-- jsPDF y autoTable -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>

  <script>
    window.onload = function () {
      const rows = document.querySelectorAll("#tablaSalud tbody tr");
      if (rows.length > 0) {
        const row = rows[0];
        const peso = parseFloat(row.cells[2].textContent); 
        const estatura = parseFloat(row.cells[3].textContent); 
        const imcCell = row.cells[7];
        const estaturaMetros = estatura / 100;

        const imc = (estaturaMetros > 0) ? (peso / (estaturaMetros * estaturaMetros)) : 0;
        let imcClass = '';
        let imcLabel = 'N/A';
        let imcText = '---';

        if (imc > 0) {
          imcText = imc.toFixed(2);
          if (imc < 18.5) {
            imcClass = 'imc-bajo';
            imcLabel = 'Bajo Peso';
          } else if (imc < 25) {
            imcClass = 'imc-normal';
            imcLabel = 'Normal / Óptimo';
          } else if (imc < 30) {
            imcClass = 'imc-sobrepeso';
            imcLabel = 'Sobrepeso';
          } else {
            imcClass = 'imc-obesidad';
            imcLabel = 'Obesidad';
          }
        }

        // Sincronizar celda para el PDF
        imcCell.textContent = imcText;

        // Actualizar UI del Dashboard
        const imcDisplay = document.getElementById("imcDisplay");
        const imcStatusTag = document.getElementById("imcStatusTag");

        if (imcDisplay && imcStatusTag) {
          imcDisplay.textContent = imcText;
          imcStatusTag.textContent = imcLabel;
          imcStatusTag.className = "imc-badge-status " + imcClass;
        }
      }
    };

    async function exportarPDF() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF('l', 'pt', 'a4'); 

      doc.setFontSize(16);
      doc.setTextColor(40);
      doc.text("SVG-SPORTS - Ficha Médica y Biométrica (Team Dharius)", 40, 40);
      doc.setFontSize(11);
      doc.text("Fecha: " + new Date().toLocaleDateString(), 40, 60);

      doc.autoTable({
        html: '#tablaSalud',
        startY: 80,
        theme: 'grid',
        styles: {
          cellPadding: 6,
          fontSize: 9
        },
        headStyles: {
          fillColor: [16, 185, 129],
          textColor: 255
        },
        margin: { top: 80, left: 40, right: 40 },
        pageBreak: 'auto'
      });

      doc.save("Reporte_Salud_SVG_SPORTS.pdf");
    }
  </script>
</body>
</html>
<?php mysqli_close($conexion); ?>