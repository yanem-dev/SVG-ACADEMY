<?php
include("../php/conexion_be.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_estudiante = $_POST['id_estudiante'];
    $peso = $_POST['peso'];
    $estatura = $_POST['estatura']; 
    $alergias = $_POST['alergias'];
    $grupoSan = $_POST['grupoSan'];
    $padecimientos = $_POST['padecimientos'];

    $estatura_metros = $estatura / 100;

    // Calcular IMC
    $imc = ($estatura_metros > 0) ? ($peso / ($estatura_metros * $estatura_metros)) : 0;
    $imc = round($imc, 2);  
   
    $sql = "UPDATE salud SET peso='$peso', estatura='$estatura', alergias='$alergias', grupoSan='$grupoSan', padecimientos='$padecimientos', imc='$imc' WHERE id_estudiante='$id_estudiante'";

    if (mysqli_query($conexion, $sql)) {
        echo '
        <script>
            alert("Registro actualizado con IMC: ' . $imc . '");
            window.location = "../salud.php"; // Redirige a donde desees después de la actualización
        </script>
        ';
    } else {
        echo '
        <script>
            alert("No se pudo actualizar la información");
            window.location = "modificarsalud.php"; // Regresa al formulario en caso de error
        </script>
        ';
    }

  
    mysqli_close($conexion);
}
?>
