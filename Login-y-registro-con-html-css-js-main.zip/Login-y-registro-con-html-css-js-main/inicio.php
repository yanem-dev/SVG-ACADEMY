<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SVG-REDSPORT </title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-inner: #1a2234;
      --input-bg: #0f172a;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.2);
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --border-subtle: #1e293b;
      --border-focus: #6366f1;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    body {
      min-height: 100vh;
      background-color: var(--bg-dark);
      background-image: 
        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.15) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(56, 189, 248, 0.08) 0px, transparent 50%);
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 24px;
      color: var(--text-main);
    }

    .auth-container {
      background: var(--card-bg);
      width: 100%;
      max-width: 460px;
      border-radius: 24px;
      padding: 38px 30px;
      border: 1px solid var(--border-subtle);
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
      position: relative;
    }

    .brand-top {
      text-align: center;
      margin-bottom: 24px;
    }

    .brand-icon {
      width: 52px;
      height: 52px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(56, 189, 248, 0.2));
      color: var(--primary);
      border: 1px solid rgba(99, 102, 241, 0.4);
      border-radius: 16px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      margin-bottom: 12px;
      box-shadow: 0 0 20px var(--primary-glow);
    }

    .brand-name {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: var(--text-main);
      margin-bottom: 6px;
    }

    .brand-name .highlight {
      color: var(--accent);
    }

    .portal-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(99, 102, 241, 0.15);
      color: #818cf8;
      border: 1px solid rgba(99, 102, 241, 0.3);
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      padding: 3px 12px;
      border-radius: 9999px;
      margin-bottom: 8px;
      text-transform: uppercase;
    }

    .brand-top p {
      font-size: 13.5px;
      color: var(--text-muted);
      margin-top: 4px;
    }

    /* Pestañas de Navegación */
    .tab-switch {
      display: flex;
      background: var(--input-bg);
      padding: 4px;
      border-radius: 14px;
      border: 1px solid var(--border-subtle);
      margin-bottom: 24px;
    }

    .tab-btn {
      flex: 1;
      padding: 10px;
      border: none;
      background: transparent;
      color: var(--text-muted);
      font-size: 13.5px;
      font-weight: 600;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .tab-btn.active {
      background: var(--card-inner);
      color: var(--text-main);
      border: 1px solid var(--border-subtle);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }

    /* Paneles de Contenido */
    .form-pane {
      display: none;
      animation: fadeIn 0.25s ease-in-out forwards;
    }

    .form-pane.active {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .input-field {
      position: relative;
    }

    .input-field i {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748b;
      font-size: 14px;
      pointer-events: none;
    }

    .input-field input {
      width: 100%;
      background: var(--input-bg);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 13px 16px 13px 44px;
      border-radius: 12px;
      font-size: 14px;
      outline: none;
      transition: all 0.2s ease;
    }

    .input-field input:focus {
      border-color: var(--border-focus);
      box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
    }

    .btn-submit {
      width: 100%;
      background: var(--primary);
      color: #ffffff;
      border: none;
      padding: 14px;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 14px var(--primary-glow);
    }

    .btn-submit:hover {
      background: var(--primary-hover);
      transform: translateY(-1px);
    }

    /* Panel de Solicitud de Registro / Security Gate */
    .security-notice {
      background: var(--card-inner);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
      padding: 24px 20px;
      text-align: center;
    }

    .security-notice i.shield-icon {
      font-size: 32px;
      color: var(--accent);
      margin-bottom: 12px;
      display: inline-block;
    }

    .security-notice h3 {
      font-size: 16px;
      font-weight: 700;
      color: var(--text-main);
      margin-bottom: 8px;
    }

    .security-notice p {
      font-size: 13px;
      color: var(--text-muted);
      line-height: 1.5;
      margin-bottom: 16px;
    }

    .email-chip {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(56, 189, 248, 0.1);
      border: 1px solid rgba(56, 189, 248, 0.3);
      color: var(--accent);
      padding: 8px 14px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 700;
      text-decoration: none;
      transition: all 0.2s ease;
    }

    .email-chip:hover {
      background: rgba(56, 189, 248, 0.2);
      transform: translateY(-1px);
    }

    /* Enlace Volver */
    .btn-back {
      margin-top: 22px;
      text-align: center;
    }

    .btn-back a {
      color: var(--text-muted);
      font-size: 13px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: color 0.2s ease;
    }

    .btn-back a:hover {
      color: var(--accent);
    }
  </style>
</head>
<body>

  <div class="auth-container">
    <div class="brand-top">
      <div class="brand-icon">
        <i class="fas fa-shield-halved"></i>
      </div>
      <div class="app-branding">
        <h1 class="brand-name">SVG<span class="highlight">-REDSPORT</span></h1>
        <span class="portal-badge"><i class="fas fa-lock"></i> Operadores/Administracion</span>
      </div>
      <p>GESTION</p>
    </div>

    <!-- Pestañas de selección -->
    <div class="tab-switch">
      <button class="tab-btn active" id="tab-login" onclick="cambiarPestana('login')">
        <i class="fas fa-key"></i> Iniciar Sesión
      </button>
      <button class="tab-btn" id="tab-register" onclick="cambiarPestana('register')">
        <i class="fas fa-user-shield"></i> Solicitar Acceso
      </button>
    </div>

    <!-- Formulario de Inicio de Sesión -->
    <form action="php/login_usuario_be.php" method="POST" class="form-pane active" id="form-login">
      <div class="input-field">
        <i class="fas fa-envelope"></i>
        <input type="text" placeholder="Correo Electrónico" name="correo" required>
      </div>

      <div class="input-field">
        <i class="fas fa-lock"></i>
        <input type="password" placeholder="Contraseña de Administrador" name="contrasena" required>
      </div>

      <button type="submit" class="btn-submit">
        <span>Ingresar al Panel de Control</span>
        <i class="fas fa-arrow-right"></i>
      </button>
    </form>

    <!-- Información de Acceso Restringido -->
    <div class="form-pane" id="form-register">
      <div class="security-notice">
        <i class="fas fa-id-badge shield-icon"></i>
        <h3>Acceso Restringido</h3>
        <p>El registro de administradores está protegido por políticas de seguridad interna. Para solicitar credenciales o dar de alta una cuenta docente, contacta a la dirección técnica:</p>
        
        <a href="mailto:221251@mail.unacar.mx?subject=Solicitud de Acceso Administrador - SVG SPORTS" class="email-chip">
          <i class="fas fa-envelope"></i>
          <span>221251@mail.unacar.mx</span>
        </a>
      </div>
    </div>

    <div class="btn-back">
      <a href="index.php">
        <i class="fas fa-chevron-left"></i> Cambiar tipo de acceso
      </a>
    </div>
  </div>

  <script>
    function cambiarPestana(modo) {
      const formLogin = document.getElementById('form-login');
      const formRegister = document.getElementById('form-register');
      const tabLogin = document.getElementById('tab-login');
      const tabRegister = document.getElementById('tab-register');

      if (modo === 'login') {
        formLogin.classList.add('active');
        formRegister.classList.remove('active');
        tabLogin.classList.add('active');
        tabRegister.classList.remove('active');
      } else {
        formRegister.classList.add('active');
        formLogin.classList.remove('active');
        tabRegister.classList.add('active');
        tabLogin.classList.remove('active');
      }
    }
  </script>
</body>
</html>